# Online learning platform — init prompt

Build a full-stack TypeScript application that serves online training: course creators schedule sessions, students join a LiveKit-based video stream live, and watch the recording afterward.

## Tech stack (required)

- **TanStack Start** (full-stack React meta-framework, based on Vite, with SSR)
- **TypeScript** throughout, in strict mode
- **Local email/password authentication** (no hosted auth provider): SQLite-backed users, **argon2** or **bcrypt** for `passwordHash`, **HttpOnly** session cookies (opaque session IDs stored server-side). No Clerk, Auth0, or similar — demos must run with zero external auth dashboard setup.
- **Tailwind CSS v4** (CSS-first config, `@import "tailwindcss"`, no `tailwind.config.js`)
- **shadcn/ui** components (Radix-based, fetch them with the CLI)
- **SQLite** database with **Drizzle ORM** (migrations via `drizzle-kit`)
- **tRPC v11** for the API, with TanStack Query integration
- **Zod** for all input validation
- **LiveKit** server + client SDK (`livekit-server-sdk`, `@livekit/components-react`). **Do not rely on incoming webhooks** (no `/api/.../webhook` routes to configure in LiveKit Cloud or elsewhere). Use the LiveKit server SDK only from your app to create rooms, start/stop egress, **poll egress status** until the recording is ready, and read the resulting file URL.
- **Resend** for transactional emails
- **Bun** as the package manager (`bun install`, `bun add`, `bun run`), but the dev server is **Vite** (under TanStack Start)

## Authentication (demo-friendly, local only)

- **Sign-up / sign-in**: `/register` and `/login` pages; passwords hashed with argon2 or bcrypt; sessions in DB (`authSessions` table) with random opaque `sessionId` in an HttpOnly cookie (e.g. `session` or `sid`). Logout clears cookie and deletes server session row.
- **Roles**: stored only in the local DB on `users.role` (`creator` / `student` / `admin`). Registration flow may default new users to `student` unless you add a small admin-only invite path — for demo purposes, prefer **seeded users** for all three roles (see below).
- **Protected routes and tRPC**: resolve the current user from the session cookie in server middleware / tRPC `createContext`; `protectedProcedure` requires a logged-in user.
- **Secret**: use a single `AUTH_SECRET` or `SESSION_SECRET` (env) to sign or derive cookie handling if needed; no third-party OAuth for this prompt.

### Seeded demo accounts (required)

After migrations, run a **seed script** (e.g. `bun run db:seed`) that creates three users so every coding agent can demo the same credentials without configuration:

| Email | Password | Role |
|------|----------|------|
| `creator@example.com` | `demo1234` | `creator` |
| `student@example.com` | `demo1234` | `student` |
| `admin@example.com` | `demo1234` | `admin` |

Document these in README and optionally show a hint on the login page (“Demo: use seeded accounts”). All four parallel app versions should use **the same** seed emails and password so comparison stays trivial.

## Domain model

Three user roles: `creator` / `student` / `admin`, stored in the local DB only (`users.role`).

### Entities

- **User** — `id` (opaque string, e.g. nanoid/ulid), `email` (unique), `name`, `passwordHash`, `role`, `createdAt`
- **AuthSession** — `id`, `userId` (FK), `expiresAt`, `createdAt`; optional `tokenHash` if you store only a hash of the cookie value
- **Course** — `id`, `title`, `description` (markdown), `createdAt`, `createdBy` (User FK)
- **CourseOwnership** — join table `courseId` + `userId` + `role` (`admin` or `co_host`). `createdBy` automatically gets `admin` ownership.
- **CourseEnrollment** — `courseId` + `userId` + `invitedEmail` + `status` (`pending` / `active`). If the email does not yet exist as a user, `userId` is null and `status` = `pending`; when that email completes local registration, activate matching pending rows (match on normalized email).
- **Session** (course session) — `id`, `courseId`, `title`, `description`, `scheduledStart`, `scheduledEnd`, `livekitRoomName` (unique, generated: `session-{nanoid}`), `livekitEgressId` (nullable; set when recording starts, used to poll egress status — no webhooks), `status` (`scheduled` / `live` / `ended`), `recordingUrl` (nullable)
- **SessionPresenter** — extra presenters can be added to a session (guests) who are not course owners. `sessionId` + `userId`.

### Permissions

| Operation | Who can do it |
|---|---|
| Create course | `creator` or `admin` role |
| Edit course, add ownership | Course `admin` owner |
| Add co-host to course | Course `admin` owner |
| Create / edit session | Any owner of the course |
| Add session presenter (guest) | Any owner of the course |
| Invite student by email | Any owner of the course |
| **Publish** in live stream (camera/mic) | Session presenter or course owner |
| **Subscribe** in live stream (watching, reading chat) | Student with active enrollment + owners + presenters |
| View recording | Same as subscribe |

Map this in tRPC middleware as `protectedProcedure` + custom `courseOwnerProcedure` / `sessionParticipantProcedure`.

## LiveKit integration

### Backend (in tRPC mutations)

- `session.start` — only an owner can call it. Creates the LiveKit room with `RoomServiceClient`, starts egress recording (`EgressClient.startRoomCompositeEgress`) to **Azure Blob Storage** (configurable via env). Persist the returned **egress id** on the session row (`livekitEgressId`). Session `status` → `live`.
- `session.end` — stop egress via the SDK (`EgressClient` stop/list as appropriate), set `status` → `ended`, then **poll** the egress status with the stored `livekitEgressId` (retry with backoff until the egress is complete or failed, or until a reasonable timeout) and persist the **publicly readable** recording URL into `recordingUrl` from the egress result (e.g. Azure blob URL or path your app can serve). No webhooks — all of this happens inside the mutation or a small in-process loop after stop.
- `session.getAccessToken` — generates a token for the calling user with the proper grants:
  - Owner / presenter: `canPublish: true`, `canPublishData: true`, `canSubscribe: true`
  - Student: `canPublish: false`, `canPublishData: true` (because of chat), `canSubscribe: true`
  - Verifies that the user is authorized (ownership or active enrollment). Token TTL: 2 hours.

### Frontend

- `/sessions/:id/live` route — with a LiveKit `<LiveKitRoom>` wrapper. Owners use `<VideoConference>`, students use a custom view: one main video tile (the active presenter) + a side chat panel.
- Chat runs over the LiveKit **data channel** (not DB-backed in v1). Send and receive via the `useDataChannel()` hook, keeping the message list in local state. Students can only read (input disabled in the UI).
- `/sessions/:id/recording` route — plain HTML5 `<video>` tag, source is `recordingUrl`.

### Recording URL without webhooks

Do **not** implement a LiveKit webhook receiver. Rely on `session.end` (and egress polling as above). If `recordingUrl` is not ready before the UI navigates to the recording page, expose a tRPC query such as `session.getRecordingStatus` that returns `{ status, recordingUrl? }` so the client can refetch until the URL is available.

## Invitation system (Resend)

Sending mail uses **Resend’s HTTP API only** (API key in env). You do **not** need Resend inbound webhooks or DNS beyond what Resend needs to send — no extra receivers to configure for this prompt.

- `enrollment.inviteStudents` tRPC mutation — input: `courseId` + `emails: string[]`. For each email:
  - If a user with that email already exists → create an active enrollment directly.
  - If not → create a `pending` enrollment and send a Resend email with a link to **your app’s** registration page, e.g. `${APP_URL}/register?redirect_url=/courses/{courseId}` (or include a short invite token in the query string if you prefer). When the user completes local sign-up with that email, match and activate all `pending` enrollments for that normalized email.
- Email template with a React Email component (`@react-email/components`).
- Env: `RESEND_API_KEY`, `RESEND_FROM_EMAIL`.

## Landing page variants (6 total, for comparison)

On the `/` and `/1` .. `/5` routes, create 6 landing pages with **radically different** designs so I can compare them. Do not make them mere color variations — they should have completely different mood, layout, typography, and illustration style.

Each landing page should contain the same content (e.g. hero + headline + sub + CTA, 3-4 feature blocks, a "how it works" section, CTA footer, though you may diverge from these as you like), but the visual language should be distinctly different. Adjust the base content as well so it matches the service.

Come up with the 6 different directions creatively yourself. Each variant can be a separate route file (e.g. `src/routes/index.tsx`, `src/routes/1.tsx`, ... `src/routes/5.tsx`), and each should have its own component under `src/components/landing/Variant{N}.tsx`.

### Variant switcher

In a fixed position (e.g. bottom-center or top-right corner), place a small floating pill containing 6 buttons: `◯ Default`, `1`, `2`, `3`, `4`, `5`. On click, it routes to the corresponding landing page. The active variant should be highlighted. This switcher should appear only on the landing routes, not on the dashboard or other routes.

### Important

- Each variant must be a **complete, production-quality design**, not a placeholder. If one cannot be 100%, ask instead, but do not ship a low-quality version.
- Use Tailwind v4, feel free to use shadcn components, but **do not use the same ones for every variant** — for example, the brutalist variant should not use the same rounded shadcn buttons as the minimalist one. Customize them or write your own where needed.
- Take inspiration from real websites, but do not copy them.

## Proposed route structure (TanStack Start)

```
/                              — landing (default / minimalist variant)
/1, /2, /3, /4, /5             — additional landing variants
/login                         — email/password sign-in
/register                      — email/password sign-up (honor redirect_url query from invites)
/logout                        — POST (or server action) to clear session
/dashboard                     — role-based: creator sees their courses, student sees their enrollments
/courses/new                   — creator/admin
/courses/:id                   — course main page, session list, owner functions
/courses/:id/students          — enrollment management (owner)
/courses/:id/settings          — owner management, co-host invite (admin)
/sessions/:id/live             — live stream
/sessions/:id/recording        — recording
/api/trpc/$                    — tRPC handler
```

## Proposed project structure

```
src/
  routes/                      — TanStack Start file-based routing
  components/
    ui/                        — shadcn components
    course/                    — domain-specific
    session/
    live/                      — LiveKit wrapper components
  server/
    db/
      schema.ts                — Drizzle schema (users, authSessions, …)
      index.ts                 — db client
      seed.ts                  — seeded demo users (creator/student/admin + demo1234)
    trpc/
      router.ts
      routers/
        course.ts
        session.ts
        enrollment.ts
        auth.ts                — optional: register, me, logout mutations/queries
      context.ts               — session from cookie → user + role
      procedures.ts            — protectedProcedure, courseOwnerProcedure, etc.
    auth/
      password.ts              — hash / verify
      session.ts               — create / destroy session, cookie helpers
    livekit/
      client.ts                — RoomServiceClient, EgressClient
      tokens.ts                — token generation logic
    email/
      client.ts                — Resend
      templates/
        InviteStudent.tsx
  lib/
    auth.ts                    — client-safe auth helpers if any (e.g. redirect to login)
    permissions.ts             — permission check functions
  styles/
    globals.css                — Tailwind @import
drizzle/                       — migrations
```

## Environment variables (`.env.example` required)

```
# Auth (local sessions)
AUTH_SECRET=jC30yVia2v7ppOo7raIo2azkcn0yMigr  # long random string for signing/session use (this is local session only)
SESSION_COOKIE_NAME=lumora    # optional; default name for HttpOnly cookie

# Database
DATABASE_URL=file:./local.db

# LiveKit
LIVEKIT_API_KEY=
LIVEKIT_API_SECRET=
LIVEKIT_URL=wss://your-project.livekit.cloud

# LiveKit egress target (Azure Blob Storage)
LIVEKIT_EGRESS_AZURE_ACCOUNT_NAME=
LIVEKIT_EGRESS_AZURE_ACCOUNT_KEY=
LIVEKIT_EGRESS_AZURE_CONTAINER_NAME=

# Resend
RESEND_API_KEY=
RESEND_FROM_EMAIL=

# App use port 3010 for Vite!
APP_URL=http://localhost:3010
```

## First steps to run

1. `bun create` with the TanStack Start project scaffold, then `bun install` for dependencies. The dev server runs on Vite (`bun run dev`).
2. Initialize shadcn/ui, and fetch: `button`, `input`, `textarea`, `dialog`, `dropdown-menu`, `form`, `table`, `card`, `badge`, `sonner`.
3. Write the Drizzle schema (including `users`, `authSessions`), create the first migration, export `db.ts`, implement local login/register/logout and session cookie handling, add **`bun run db:seed`** for seeded demo accounts (`creator@example.com`, `student@example.com`, `admin@example.com` / `demo1234`).
4. Implement `/login` and `/register`, protect app routes (redirect unauthenticated users to `/login`).
5. Set up tRPC (`createContext` resolves user from session cookie + DB).
6. Base pages: `/dashboard` + `/courses/new` + course detail + student invite form. **It should be testable end-to-end even without LiveKit.**
7. **6 landing variants** on the `/` and `/1`..`/5` routes + variant switcher component.
8. LiveKit room creation + token generation + live page + simple `<LiveKitRoom>` render.
9. Start egress on session start (store `livekitEgressId`); on session end, stop egress and **poll** until `recordingUrl` can be set — recording page (optional: `session.getRecordingStatus` poll on the client if URL is still pending).
10. Resend integration and invite email flow (registration links point to this app’s `/register`, not a third party).

## Coding principles

- **Server/client boundary is explicit**: never import code under `server/` from the client side. Everything should go through tRPC (except form POSTs to login/register if you use server handlers for cookie setting).
- **Zod schemas from the DB schema**: use `drizzle-zod` for select/insert schemas, do not duplicate them.
- **Permission checks always on the server**, the UI only hides/shows. Never trust client state.
- **Small commits**, commit to git after each larger step.
- **Do not add the next feature until the previous one has been tested manually**. Ask if you get stuck at any step or if I need to make a decision.

Before you begin, confirm in a few sentences that you understand the domain model and local auth flow, and ask questions if anything is not completely clear.
