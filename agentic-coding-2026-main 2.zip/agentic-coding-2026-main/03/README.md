# Lecture 3: Agentic Code Tooling Landscape

## Topics Covered

* Using chat interfaces – ChatGPT, Claude, Gemini, etc.: how they code and why they're limited
* IDE integrations and code editors – VS Code extensions and "AI IDEs": Copilot, Cline, Kilo Code, Cursor, Windsurf – their advantages and differences
* CLI-based systems – developing from the command line with AI: Claude Code, Codex CLI, Gemini CLI, Qwen Code, Open Code
* Vibe coding: What makes it different, when is it worth using? Platforms: Replit, V0, Bolt, Lovable, etc.
* Demo – install Claude Code and start coding

## Learning Objectives

By the end of this lecture, you will understand:
- The different ways AI can assist in coding
- The strengths and limitations of various AI coding tools
- How to choose the right tool for your workflow
- What "vibe coding" means and when it's appropriate
- How to effectively leverage AI in your development process

## Resources

### Where to track model coding capabilities

These benchmarks/leaderboards help you sanity-check “coding model hype” and compare strengths across problem types (agentic tasks vs. short snippets vs. webdev), and in some cases across programming languages too.

- **Artificial Analysis (leaderboards)**: [https://artificialanalysis.ai/](https://artificialanalysis.ai/)
- **SWE-bench (real GitHub issues as evals)**: [https://www.swebench.com/](https://www.swebench.com/)
- **LM Arena – WebDev leaderboard**: [https://lmarena.ai/hu/leaderboard/webdev](https://lmarena.ai/hu/leaderboard/webdev)

Very useful research on which languages different models tend to perform best in (even if the study is a bit outdated now):
- **AutoCodeBenchmark**: [https://github.com/Tencent-Hunyuan/AutoCodeBenchmark](https://github.com/Tencent-Hunyuan/AutoCodeBenchmark)

### General-purpose chat interfaces (great for scripts, limited for full projects)

These are excellent for **scaffolding small scripts**, explaining unfamiliar code, writing one-off transforms, and brainstorming. They are much weaker at **multi-file refactors**, **keeping long-term context**, and **applying changes reliably** across an entire repo without help from an IDE/agent workflow.

- [ChatGPT](https://chatgpt.com/)
- [Claude](https://claude.ai/)
- [Gemini](https://gemini.google.com/)
- [Mistral Chat](https://chat.mistral.ai/)
- [Grok](https://grok.com/)
- [DeepSeek Chat](https://chat.deepseek.com/)
- [Qwen Chat](https://chat.qwen.ai/)
- [Z.ai Chat](https://chat.z.ai/)

**Old-school “pack the repo into text” approach (still useful sometimes):**

- **repomix**: [https://github.com/yamadashy/repomix](https://github.com/yamadashy/repomix)  
  Handy when you want to ask “where is the bug?” with full context, but for real work you’ll usually get better results from IDE tools that select the *right* context automatically.

### Copy‑paste prompts (Excel example: `arfolyam-letoltes.xlsx`)

Use the file `arfolyam-letoltes.xlsx` (exchange rates). The sheet looks like:

- Header row: `Dátum/ISO, HUF, EUR, AUD, ...`
- Unit row: `Egység, 1, 1, 1, ...`
- Data rows (example):
  - `2025. 01. 02., (HUF empty), 411,51, 247,18, ...`
  - `2025. 01. 03., (HUF empty), 414,81, 250,47, ...`

#### Prompt 1 — Monthly averages of **HUF/EUR**

Paste this into a chat model, and attach the Excel file when asked:

```
You are a senior Python data engineer. Write a single Python script that reads `arfolyam-letoltes.xlsx` and computes **monthly averages** of the **HUF/EUR exchange rate** (HUF per 1 EUR).  
  
Constraints / details:  
- The first column is `Dátum/ISO` (Hungarian date like `2025. 01. 03.`). Parse it robustly.  
- There is a second row `Egység` that is NOT data; skip it.  
- The `HUF` column may be empty; ignore it. Use the `EUR` column for the exchange rate values.  
- Values use a comma as decimal separator (e.g. `411,51`). Convert to floats.  
- Ignore all currencies except `EUR`.  
- Output: a CSV file `huf_eur_monthly_avg.csv` with columns: `year_month` (YYYY-MM), `avg_huf_per_eur`, `n_days`. Sort ascending by month.  
- Also print the first 10 rows to stdout.  
  
Requirements:  
- Use only standard libs + `pandas` (ok).  
- Include clear comments and basic error handling (file not found, missing columns).  
- Make the script runnable as: `python monthly_avg.py`.
```

#### Prompt 2 — Build a Streamlit app (select currencies, plot chart)

Paste this into a chat model, and attach the Excel file when asked:

```
You are a senior Python developer. Build a **Streamlit** app that loads `arfolyam-letoltes.xlsx` and lets the user explore exchange rates over time.  
  
App requirements:  
- Read the Excel, skip the `Egység` row, parse the `Dátum/ISO` column as dates.  
- Detect currency columns from the header row (everything except `Dátum/ISO`).  
- Handle decimal commas (e.g. `411,51`) and missing values.  
- UI: multiselect to choose currencies (default: `EUR`), date range filter, and a toggle for **daily values vs. monthly average**.  
- Chart: line chart of selected currencies over time.  
- Show a small data preview table under the chart.  
- Provide `requirements.txt` and instructions to run: `streamlit run app.py`.  
  
Engineering constraints:  
- Keep the code in a single `app.py` file.  
- Add caching (`st.cache_data`) so reloads are fast.  
- Include friendly error messages if the file/columns are missing.
```

### VS Code extensions (project-aware coding assistants)

These are usually better than plain chat for real repos because they can **index a project**, pick **relevant context**, apply **multi-file changes**, and run checks. This is also where “enterprise constraints” matter: open-source tools can be configured to use only approved endpoints/models.

- **GitHub Copilot (the big catalyst)**: [https://code.visualstudio.com/docs/copilot/overview](https://code.visualstudio.com/docs/copilot/overview)
- **Cline**: [https://cline.bot/](https://cline.bot/) (open source: [https://github.com/cline/cline](https://github.com/cline/cline))
- **Kilo Code**: [https://kilo.ai/](https://kilo.ai/) (open source: [https://github.com/Kilo-Org/kilocode](https://github.com/Kilo-Org/kilocode))
- **Roo Code**: [https://roocode.com/](https://roocode.com/) (open source: [https://github.com/RooCodeInc/Roo-Code](https://github.com/RooCodeInc/Roo-Code))

### “Agentic IDEs” (VS Code forks built around AI workflows)

- **Cursor**: [https://cursor.com/](https://cursor.com/)
- **Windsurf**: [https://windsurf.com/](https://windsurf.com/)
- **AntiGravity (Google)**: [https://antigravity.google/](https://antigravity.google/)
- **Kiro (AWS)**: [https://kiro.dev/](https://kiro.dev/)
- **Trae (ByteDance / TikTok)**: [https://www.trae.ai/](https://www.trae.ai/)

### Coding CLIs (agentic coding from the terminal)

These are exploding in popularity because they fit well into dev workflows (git, scripts, CI/CD, SSH, servers) and can be paired with an IDE.

- **Claude Code**: [https://claude.com/product/claude-code](https://claude.com/product/claude-code)
- **Codex CLI**: [https://developers.openai.com/codex/cli/](https://developers.openai.com/codex/cli/)
- **OpenCode**: [https://opencode.ai/](https://opencode.ai/)
- **Gemini CLI**: [https://github.com/google-gemini/gemini-cli](https://github.com/google-gemini/gemini-cli)
- **Qwen Code**: [https://github.com/QwenLM/qwen-code](https://github.com/QwenLM/qwen-code)
- **Pi Coding Agent**: [https://github.com/badlogic/pi-mono/](https://github.com/badlogic/pi-mono/tree/main/packages/coding-agent)
- **Aider**: [https://github.com/Aider-AI/aider](https://github.com/Aider-AI/aider)
- **Mistral CLI**: [https://github.com/mistralai/mistral-vibe](https://github.com/mistralai/mistral-vibe)

### “Vibe coding” platforms (web-based, export code at the end)

Often best for **rapid product exploration**, **UI mockups**, and getting to a clickable prototype fast. For production work, a common workflow is: prototype here → **export** → continue in an IDE/CLI tool with proper repo discipline.

- **Lovable**: [https://lovable.dev/](https://lovable.dev/)
- **Replit**: [https://replit.com/](https://replit.com/)
- **Bolt**: [https://bolt.new/](https://bolt.new/)
- **v0 (Vercel)**: [https://v0.app/](https://v0.app/)

### Why first-party subscriptions matter

Before getting into `Claude Code`, it is worth calling out the economics.

One reason `Codex` and `Claude Code` feel unusually powerful is that OpenAI and Anthropic each sell both:

- the **consumer subscription**
- and the **underlying API**

That means their paid products are **not** the same thing as "here are `$20` of API credits." They are bundled products with rate limits, pooled usage, and separate API pricing. In practice, this means the first-party subscriptions often feel **heavily subsidized relative to raw API pricing**, even if the vendors do not publish a simple "$20 equals $X in tokens" conversion.

The official docs make this distinction explicit:

- OpenAI includes `Codex` in ChatGPT plans, but API-key usage is billed separately at API token rates: [ChatGPT pricing](https://openai.com/ChatGPT/pricing), [Codex pricing](https://developers.openai.com/codex/pricing/), [OpenAI API pricing](https://openai.com/api/pricing/)
- Anthropic includes `Claude Code` in `Claude Pro`, but API usage is separate and billed independently: [Claude Pro help article](https://support.claude.com/en/articles/8325606-what-is-the-pro-plan), [Anthropic pricing](https://www.anthropic.com/pricing), [Claude API pricing](https://docs.anthropic.com/en/about-claude/pricing)

For teaching, the practical mental model is:

- a first-party `$20/month` subscription can give **far more practical coding usage** than `$20` of raw API credits
- there is **no official fixed conversion** from "one month of Plus/Pro" to "X dollars of API"
- community measurements regularly suggest that active users can extract **hundreds of dollars of API-equivalent value** before hitting rate limits

Some useful community references:

- `ccusage` is an open-source tool that estimates API-equivalent costs from local `Claude Code` and `Codex` logs: [https://ccusage.com/guide/](https://ccusage.com/guide/)
- one public `Codex` writeup using `@ccusage/codex` showed a month estimated at `$563.02`, and `$941.71` total across the sample period: [Beyond the Usage Bar: Estimating Codex Tokens with ccusage](https://zhengtxecon.github.io/blog/estimating-codex-tokens-with-ccusage.html)
- one public `Claude Code` writeup estimated `~$15,000+` of API-equivalent usage over eight months, versus `~$800` paid on subscription plans, with one month alone estimated at `$5,623`: [Claude Code Pricing Guide: Which Plan Saves You Money](https://ksred.com/claude-code-pricing-guide-which-plan-actually-saves-you-money/)

This is also why similarly priced third-party tools usually cannot be as generous on frontier models:

- `Cursor Pro` is explicitly priced much closer to pass-through usage: `$20/month` includes `$20` of API usage, and premium routing is billed at the selected model's API rate: [Cursor pricing](https://cursor.com/help/account-and-billing/pricing), [Cursor models and pricing](https://cursor.com/docs/models-and-pricing)
- `GitHub Copilot Pro` and `Pro+` meter advanced usage through premium request quotas and model multipliers, with extra premium requests billed separately: [Copilot plans](https://docs.github.com/en/copilot/get-started/plans), [Copilot premium requests](https://docs.github.com/copilot/concepts/billing/copilot-requests)

So if you are comparing a first-party subscription from OpenAI or Anthropic with a third-party IDE subscription, the important takeaway is:

- first-party subscriptions are often **much more generous for heavy direct use**
- third-party tools usually expose the underlying model cost structure more directly
- this is why a `$20` first-party subscription can sometimes feel closer to "a few hundred dollars of API-equivalent usage" than to "`$20` of tokens"

### Claude Code basics

For this lecture, keep the goal simple: **install it, start it in a repo, learn a few control commands, and understand where it fits in a developer workflow**.

Claude Code is a **CLI-first coding agent**: you run it inside a project folder, give it tasks in natural language, and it can inspect files, edit code, run commands, and help with real repo workflows.

**Install options:**

- **Windows (PowerShell):**
  ```powershell
  irm https://claude.ai/install.ps1 | iex
  ```
- **macOS / Linux:**
  ```bash
  curl -fsSL https://claude.ai/install.sh | bash
  ```
- **npm (works well if Node.js is already installed):**
  ```bash
  npm install -g @anthropic-ai/claude-code
  ```

**Start it in a project:**

```bash
cd your-project
claude
```

**Useful first commands:**

```bash
claude update
```

- `claude` starts an interactive coding session in the current repo
- `claude update` updates the CLI to the latest version

#### Keyboard shortcuts

These are the only shortcuts most beginners need on day 1:

| Shortcut | What it does | Why it matters |
|---|---|---|
| `@` | Reference files or folders | Add precise context without copy-pasting |
| `!` | Run a shell command inline | Great for quick git / test / build steps |
| `Esc` | Interrupt Claude | Stop a long or wrong action |
| `Esc` + `Esc` | Open rewind menu | Undo recent Claude-driven changes |
| `Ctrl+R` | Show full output / context | Useful when output is truncated |
| `Shift+Tab` | Auto-accept mode | Faster flow when you trust the agent |
| `Shift+Tab` twice | Plan mode | Ask for a plan before edits |

#### Configuration

Claude Code supports **global**, **project**, and **personal local** settings.

**Common settings locations:**

- `~/.claude/settings.json` - your user-wide defaults
- `.claude/settings.json` - shared project settings
- `.claude/settings.local.json` - local personal overrides for one project

**Basic config commands:**

```bash
claude config list
claude config get <key>
claude config set <key> <value>
```

Use configuration to control things like:

- default behavior and preferences
- permissions and allowed tools
- project-specific defaults for a team

For teaching purposes, the main idea is: **put shared rules in the repo, and personal overrides in local config**.

#### Checkpointing

One of Claude Code's most beginner-friendly features is **rewind / checkpointing**.

- Claude automatically creates checkpoints during the session
- you can go back if an edit went in the wrong direction
- this is faster than fixing a bad change manually

**Open rewind:**

```text
Esc + Esc
```

or:

```text
/rewind
```

**Important limitation:** checkpoints are **not a replacement for Git**.

- good for quick recovery during a live session
- not a substitute for commits, branches, and PR review
- shell operations like `rm`, `mv`, or external edits may not be fully reversible

#### Slash commands

Slash commands are the fastest way to control the session without writing a long prompt.

**Most useful starter commands:**

| Command | Use |
|---|---|
| `/help` | show available commands |
| `/init` | initialize project guidance / memory |
| `/clear` | clear the current conversation |
| `/compact` | compress conversation context |
| `/config` | inspect or change configuration |
| `/model` | switch model |
| `/permissions` | inspect or change tool permissions |
| `/review` | ask Claude to review code |
| `/rewind` | restore a previous checkpoint |
| `/mcp` | manage MCP connections |

Two important teaching points:

- slash commands are **interactive session controls**
- they are different from normal prompts because they change how the tool behaves, not just what it answers

#### Headless mode

Claude Code can also run **non-interactively**, which is useful in scripts, automation, CI, and agent pipelines.

**Basic examples:**

```bash
claude -p "summarize this repository"
claude -p --output-format json "review the staged changes"
echo "explain this error log" | claude -p
```

**Why this matters:**

- interactive mode is best for local development
- headless mode is best for automation
- this is what makes CLI agents fit naturally into devops and CI/CD workflows

**Useful options:**

- `-p` runs in print/non-interactive mode
- `--output-format json` makes the output machine-readable
- `--max-turns 3` limits how long the agent can continue autonomously

#### Minimal mental model for students

If students remember only this, that is enough for an intro lecture:

1. Start Claude Code inside a repo with `claude`
2. Use Plan Mode with `shift+tab`
3. Give it context with `@files`
4. Use slash commands like `/help`, `/init`, and `/rewind`
5. Use rewind/checkpoints as a safety net
6. Use headless mode later when moving from local coding to automation

### 8 Levels of Working with Coding Agents

This image is a useful mental model for how teams typically move from traditional IDE work toward more autonomous, orchestrated agent workflows.

![8 levels of working with coding agents](./img/8levels.jfif)

The basic progression is:

- `L1-L2`: the IDE is still primary, and the human stays in tight control
- `L3-L5`: trust increases and the workflow becomes more agent-first
- `L6-L8`: multiple agents and orchestration become part of the development model

### Tools in Coding CLIs

Finally, let's inspect the tools used by `OpenCode`: [link](https://github.com/anomalyco/opencode/tree/dev/packages/opencode/src/tool).

You can also find some prompts [here](https://github.com/anomalyco/opencode/tree/dev/packages/opencode/src/agent/prompt).

A similar (but less clear) list can be found in the `Codex` GitHub repo: [link](https://github.com/openai/codex/tree/main/codex-rs/tools/src).
