# Lecture 8: Autonomous Coding Systems and Production Governance

## Overview

This lecture focuses on running coding agents in production-like environments, including CI/CD, governance, security, and controlled automation pipelines.

## Focus Areas

- headless agent execution and CI/CD integration with GitHub Actions
- continuous agent loops
- agent sandboxing
- security risks such as prompt injection, tool misuse, and over-permission
- building an issue-to-planning-to-coding-to-review-to-PR pipeline

## Planned Materials

- lecture notes
- governance checklists
- pipeline examples
- exercises and further reading

## Status

This is a boilerplate lecture page and will be expanded with detailed materials later.
