# Lecture 1: From LLMs to Agentic Thinking

## Topics Covered

* What is a Large Language Model (LLM)?
* Language processing: The problem with traditional neural networks
* The heart of LLMs: The Transformer architecture
* The magical element: The Self-attention mechanism (Q, K, V)
* How LLMs understand text: Tokens and Embeddings
* The LLM training lifecycle: Pre-training, Fine-Tuning (SFT), and Alignment (RLHF)
* The probabilistic nature of LLMs and why they "hallucinate"
* Base models vs instruct models vs reasoning models
* Prompt engineering vs context engineering
* Frontier labs vs the open-weight ecosystem
* Model selection trade-offs for coding: quality, latency, context window, and price
* Why coding workflows often need tools around the model

## Learning Objectives

By the end of this lecture, you will understand:
- What makes LLMs different from traditional neural networks
- The Transformer architecture and its key components
- How self-attention mechanisms work
- The complete lifecycle of training an LLM
- Why LLMs sometimes produce incorrect or nonsensical outputs
- The difference between base, instruct, and reasoning models
- How to identify the major frontier labs and open-weight labs
- How to compare models using capability, latency, price, and deployment constraints
- Where to discover, benchmark, and run models for coding tasks
- When a poor result is caused by prompting, context, or model choice

## Resources

### 0. Earlier Breakthroughs in the Field of AI
- [1988 - Yann LeCun - LeNet](https://en.wikipedia.org/wiki/LeNet)
- [2012 - Alex Krizhevsky and Ilya Sutskever - AlexNet](https://en.wikipedia.org/wiki/AlexNet)
- [2016 - Google Deepmind - AlphaGo](https://en.wikipedia.org/wiki/AlphaGo)


### 1. When All Changed: Attention is All You Need

The foundational paper that introduced the Transformer architecture:
- [Attention is All You Need (2017)](https://arxiv.org/pdf/1706.03762)

### 2. How Models Turn Text to Tokens

Interactive tools to understand tokenization:
- [TikTokenizer](https://tiktokenizer.vercel.app/)
- [OpenAI Tokenizer](https://platform.openai.com/tokenizer)

### 3. Embedding Words (Tokens) into a Vector Space

Visualizations of how tokens are mapped to high-dimensional vectors:
- [3D Embedding Visualization](https://helboukkouri.github.io/embedding-visualization/)
- [UMAP Projection](https://github.com/lmcinnes/umap)

### 4. Visualizing Self-Attention / Transformers

Interactive tools to understand how Transformers work:
- [Complete Architecture Visualization](https://bbycroft.net/llm)
- [What Happens with Words](https://poloclub.github.io/transformer-explainer/)
- [Visualize Attention](https://github.com/jessevig/bertviz)

### 5. Model Sizes / Architectures

Comparison of major LLM architectures:

| Model | GPT-3 | DeepSeek V3 | Kimi K2 | Qwen3 | Llama 3 |
|-------|-------|-------------|---------|-------|---------|
| Variant | Davinci (Base) | V3 Base | K2 Thinking | 235B-Instruct | 405B-Instruct |
| Architecture | Dense | MoE | MoE | MoE | Dense |
| Total Params | 175B | 671B | 1T | 235B | 405B |
| Active Params | 175B | 37B | 32B | 22B | 405B |
| Layers | 96 | 61 | 61 | 94 | 126 |
| Hidden Dim | 12,288 | 7,168 | 7,168 | 10,240 | 16,384 |
| Attention Heads | 96 | 128 | 64 | 64 | 128 |
| Vocab Size | 50,257 | ~129K | 160K | ~152K | 128K |
| Context | 2,048 (2K) | 128K | 256K | 128K | 128K |

**Note:** BERT models use bidirectional attention, unlike autoregressive models:
- [BERT: Pre-training of Deep Bidirectional Transformers for Language Understanding (arXiv)](https://arxiv.org/abs/1810.04805)

### 6. About Non-Determinism of LLM Outputs

Understanding why LLM outputs can vary:
- [Defeating Non-Determinism in LLM Inference](https://thinkingmachines.ai/blog/defeating-nondeterminism-in-llm-inference/)

### 7. KV Cache in LLMs

How Key-Value caching optimizes inference:
- [KV Caching Blog Post](https://huggingface.co/blog/not-lain/kv-caching)
- [DeepSeek KV Cache Optimization (Video)](https://www.youtube.com/watch?v=0VLAoVGf_74)

### 8. Datasets for Pretraining

Large-scale datasets used to train base models:
- [FineWeb](https://huggingface.co/datasets/HuggingFaceFW/fineweb)
- [CommonCrawl](https://commoncrawl.org/)
- [Wikipedia](https://huggingface.co/datasets/wikimedia/wikipedia)
- [Dolma 3 by AllanAI](https://huggingface.co/datasets/allenai/dolma3)

Link to the original scaling laws paper:
- [Scaling Laws of LLMs (arXiv)](https://arxiv.org/pdf/2001.08361)

### 9. Datasets for Instruct Training

Datasets used for supervised fine-tuning and instruction following:
- [Open Assistant Dataset](https://huggingface.co/datasets/OpenAssistant/oasst1)
- [Stanford Alpaca](https://github.com/tatsu-lab/stanford_alpaca)
- [Dolci by AllanAI](https://huggingface.co/datasets/allenai/Dolci-Instruct-SFT)
- [Scale AI](https://scale.com/) - Proprietary data labeling provider

### 10. From Instruct Models to Tool Use

Instruction-tuned models were a major step forward because they learned to respond more reliably in the format and style users expected. But many real tasks require more than a well-written text response.

If a user asks for current weather, a database lookup, a web search, or file access, the model cannot solve the task from training data alone. In these situations, the model can return a structured tool call instead of a final answer. The application executes the tool, provides the result back to the model, and the model then produces the final response.

This is an important capability shift: the model is no longer limited to only generating text from its internal knowledge and prompt context, but can also participate in workflows that depend on external systems.

Detailed cURL and Python examples:
- [Tool Calling Demo](tool-calling-demo.md)

### 11. Reasoning Models and Test-Time Compute

This section introduces the shift from instruction-following models to reasoning models. These systems are designed to spend more effort at inference time on hard problems, which can improve performance on tasks such as coding, math, and multi-step problem solving.

Earlier prompting techniques such as chain-of-thought showed that models often perform better when they generate intermediate reasoning steps. Reasoning models and test-time compute build on this idea more systematically. OpenAI popularized this category commercially with `o1`, and `DeepSeek-R1` was a major open-weight milestone that made reasoning-style behavior much more visible to the broader community.

**Why this approach works:**
- [Learning to Reason with LLMs](https://openai.com/index/learning-to-reason-with-llms/)


**Open-weight milestone:**
- [DeepSeek-R1](https://github.com/deepseek-ai/DeepSeek-R1)

### 12. How LLMs "Think"

- [Tracing the thoughts of a large language model](https://www.anthropic.com/research/tracing-thoughts-language-model)
- [Mapping the Mind of a Large Language Model](https://www.anthropic.com/research/mapping-mind-language-model)

### 13. Models of Frontier Labs

Use these pages to show how the major labs position their flagship models and product lines:

- **OpenAI**: [Model Documentation](https://platform.openai.com/docs/models/)
- **Anthropic**: [Claude Models Overview](https://docs.anthropic.com/en/docs/about-claude/models/all-models)
- **Google**: [Gemini API Models](https://ai.google.dev/gemini-api/docs/models)
- **xAI**: [Model Documentation](https://docs.x.ai/developers/rest-api-reference/inference/models)

### 14. Consumer Applications and API Platforms

This is a useful way to explain the difference between the consumer chat product and the developer platform/API:

| Company | Consumer App | Platform Link |
|---------|--------------|---------------|
| OpenAI | [ChatGPT](https://chatgpt.com/) | [API Platform](https://platform.openai.com/) |
| Anthropic | [Claude.ai](https://claude.ai/) | [API Platform](https://platform.claude.com/) |
| Google | [Gemini](https://gemini.google.com/) | [AI Studio](https://aistudio.google.com/) |
| xAI | [Grok](https://grok.com/) | [xAI API](https://x.ai/api) |

Example chat applications that can access multiple models:

- [T3 Chat](https://t3.chat/)
- [ChatLLM by Abacus.AI](https://chatllm.abacus.ai/)
- [LibreChat](https://www.librechat.ai/)

You Can Find Leaked Prompts from these Services:
- [Repo 1](https://github.com/x1xhlol/system-prompts-and-models-of-ai-tools/)
- [Repo 2](https://github.com/elder-plinius/CL4R1T4S)
- [Repo 3](https://github.com/asgeirtj/system_prompts_leaks)
- [Grok Prompts](https://github.com/xai-org/grok-prompts)

### 15. The Open-Weight Ecosystem

These links help map the open model ecosystem that sits outside the frontier labs:

- [Hugging Face](https://huggingface.co/) - the central discovery hub for models, datasets, and community resources

Open-weight labs:

- **Meta Llama**: [Hugging Face](https://huggingface.co/meta-llama)
- **DeepSeek**: [Hugging Face](https://huggingface.co/deepseek-ai)
- **Qwen**: [Hugging Face](https://huggingface.co/Qwen)
- **Moonshot AI**: [Hugging Face](https://huggingface.co/moonshotai)
- **Z.ai**: [Hugging Face](https://huggingface.co/zai-org)
- **MiniMax AI**: [Hugging Face](https://huggingface.co/MiniMaxAI)

More open and research-oriented projects:

- **Allen AI Olmo**: [Website](https://allenai.org/olmo)
- **Swiss AI Apertus**: [Website](https://www.swiss-ai.org/apertus)
- **Stanford Marin**: [GitHub](https://github.com/marin-community/marin)
- **NanoChat by Andrej Karpathy**: [GitHub](https://github.com/karpathy/nanochat)

### 16. How to Run Open-Weight Models

Useful options for showing the path from a model repository to an actual runnable system:

Runtimes:

- **llama.cpp**: [GitHub](https://github.com/ggml-org/llama.cpp)
- **vLLM**: [GitHub](https://github.com/vllm-project/vllm)
- **SGLang**: [GitHub](https://github.com/sgl-project/sglang)

Applications over local runtimes:

- **LM Studio**: [Website](https://lmstudio.ai/)
- **Ollama**: [Website](https://ollama.com/)

Model distribution hubs for different hardware:

- **Unsloth AI**: [Hugging Face](https://huggingface.co/unsloth)
- **Bartowski**: [Hugging Face](https://huggingface.co/bartowski)
- **MLX Community**: [Hugging Face](https://huggingface.co/mlx-community)

### 17. Model Benchmarks and Comparison

These are helpful for discussing model selection, but worth presenting as directional signals rather than absolute truth:

- **Artificial Analysis**: [Website](https://artificialanalysis.ai/)
- **LM Arena**: [Leaderboard](https://lmarena.ai/leaderboard)
- **OpenRouter Rankings**: [Website](https://openrouter.ai/rankings)
- **SWE-bench**: [Website](https://www.swebench.com/)

### 18. Where to Run Models

These links help explain the deployment landscape: managed enterprise platforms, inference clouds, and self-managed infrastructure.

Cloud providers:

- **Azure AI Foundry**: [Website](https://ai.azure.com/)
- **Google Vertex AI**: [Website](https://cloud.google.com/vertex-ai)
- **AWS Bedrock**: [Website](https://aws.amazon.com/bedrock/)

Inference clouds for open-weight models:

- **Groq**: [Website](https://groq.com/)
- **Cerebras**: [Website](https://www.cerebras.ai/)
- **Fireworks AI**: [Website](https://fireworks.ai/)
- **Together AI**: [Website](https://www.together.ai/)
- **Hyperbolic**: [Website](https://www.hyperbolic.ai/)

Rent your own GPU:

- [GPU Price Comparison](https://getdeploying.com/reference/cloud-gpu)

### 19. Prompting and Context

Useful reference for discussing prompting patterns before later lectures go deeper into context engineering:

- [Prompt Master GitHub Repo](https://github.com/nidhinjs/prompt-master/)
- [Prompt Engineering Guide](https://www.promptingguide.ai/)
- [Superpowers](https://github.com/obra/superpowers)

### 20. More Videos to Watch

- [Short History of LLMs](https://www.youtube.com/watch?v=JZLZQVmfGn8)
- [LLMs by 3Blue1Brown](https://www.youtube.com/watch?v=LPZh9BOjkQs&list=PLZHQObOWTQDNU6R1_67000Dx_ZCJB-3pi&index=5)
- [How DeepSeek Optimized the Transformer Architecture by Welch Labs](https://www.youtube.com/watch?v=0VLAoVGf_74)
- [How Andrej Karpathy Uses LLMs](https://www.youtube.com/watch?v=7xTGNNLPyMI)
