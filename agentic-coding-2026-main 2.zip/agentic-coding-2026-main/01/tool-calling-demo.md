# Tool Calling Demo

This companion note expands on the short "From Instruct Models to Tool Use" section from Lecture 1. The goal is to show the difference between:

- a normal model call that returns text
- a custom function call that returns a structured tool request
- a built-in tool that the platform executes automatically

These examples are intentionally simple. They are useful for classroom demonstration, not as production-ready code.

## Demo 1: Regular LLM Call vs Function Call (`curl`)

### 1. Normal chat completion

In a plain chat completion, the model answers in natural language. There is no tool schema and no tool call.

```bash
curl https://api.openai.com/v1/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $OPENAI_API_KEY" \
  -d '{
    "model": "gpt-5.3-chat-latest",
    "messages": [
      {
        "role": "user",
        "content": "What is the weather like in Paris today?"
      }
    ]
  }'
```

Expected result: a natural-language answer such as "I don't have access to real-time weather data..."

### 2. Function-enabled completion

Here we provide a function schema and ask a question where the model should decide to call that function.

```bash
curl https://api.openai.com/v1/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $OPENAI_API_KEY" \
  -d '{
    "model": "gpt-5.3-chat-latest",
    "messages": [
      {
        "role": "user",
        "content": "What is the weather like in Paris today?"
      }
    ],
    "tools": [
      {
        "type": "function",
        "function": {
          "name": "get_weather",
          "description": "Get the current weather in a given location",
          "parameters": {
            "type": "object",
            "properties": {
              "location": {
                "type": "string",
                "description": "The city and state, e.g. San Francisco, CA"
              },
              "unit": {
                "type": "string",
                "enum": ["celsius", "fahrenheit"],
                "description": "The unit for temperature"
              }
            },
            "required": ["location"]
          }
        }
      }
    ],
    "tool_choice": "auto"
  }'
```

Expected result: instead of a final answer, the model returns a structured tool call.

```json
{
  "choices": [{
    "message": {
      "role": "assistant",
      "content": null,
      "tool_calls": [{
        "id": "call_abc123",
        "type": "function",
        "function": {
          "name": "get_weather",
          "arguments": "{\"location\": \"Paris, France\", \"unit\": \"celsius\"}"
        }
      }]
    }
  }]
}
```

### 3. Send the tool result back for the final answer

Custom functions require a second model call. The application executes the function, then sends the tool result back to the model.

```bash
curl https://api.openai.com/v1/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $OPENAI_API_KEY" \
  -d '{
    "model": "gpt-5.3-chat-latest",
    "messages": [
      {
        "role": "user",
        "content": "What is the weather like in Paris today?"
      },
      {
        "role": "assistant",
        "content": null,
        "tool_calls": [{
          "id": "call_abc123",
          "type": "function",
          "function": {
            "name": "get_weather",
            "arguments": "{\"location\": \"Paris, France\", \"unit\": \"celsius\"}"
          }
        }]
      },
      {
        "role": "tool",
        "tool_call_id": "call_abc123",
        "name": "get_weather",
        "content": "{\"temperature\": 15, \"condition\": \"Partly cloudy\", \"humidity\": 65}"
      }
    ],
    "tools": [
      {
        "type": "function",
        "function": {
          "name": "get_weather",
          "description": "Get the current weather in a given location",
          "parameters": {
            "type": "object",
            "properties": {
              "location": {
                "type": "string",
                "description": "The city and state, e.g. San Francisco, CA"
              },
              "unit": {
                "type": "string",
                "enum": ["celsius", "fahrenheit"],
                "description": "The unit for temperature"
              }
            },
            "required": ["location"]
          }
        }
      }
    ]
  }'
```

Expected result: the final answer is now based on the tool output.

```json
{
  "choices": [{
    "message": {
      "role": "assistant",
      "content": "The weather in Paris today is partly cloudy with a temperature of 15°C and humidity at 65%."
    }
  }]
}
```

Documentation:
- [OpenAI Function Calling](https://platform.openai.com/docs/guides/function-calling)
- [Gemini Function Calling](https://ai.google.dev/gemini-api/docs/function-calling?example=meeting)

## Demo 2: Built-In Tools (`curl`) - Web Search

This demo shows built-in tools that can be enabled without defining a custom function schema. Unlike Demo 1, the tool is already provided by the platform.

What this shows:
- how to enable a built-in tool with a simple declaration
- that no custom schema is needed
- that the platform can execute the tool automatically

```bash
curl https://api.openai.com/v1/responses \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $OPENAI_API_KEY" \
  -d '{
    "model": "gpt-5.3-chat-latest",
    "tools": [{"type": "web_search"}],
    "input": "What is the weather like in Paris today?"
  }'
```

Expected result: the model uses web search and returns a complete answer in one call.

```json
{
  "id": "resp_abc123",
  "object": "response",
  "created": 1700000000,
  "model": "gpt-5.3-chat-latest",
  "output_text": "Today, researchers announced a breakthrough in renewable energy technology that could significantly reduce solar panel costs. Scientists developed a new material that increases solar efficiency by 40% while cutting manufacturing costs in half. This innovation could accelerate the global transition to clean energy. [Sources: example-news.com, tech-advancements.org]",
  "usage": {
    "input_tokens": 12,
    "output_tokens": 85,
    "total_tokens": 97
  }
}
```

### Key Differences

| Demo 1: Custom Function | Demo 2: Built-In Tool |
|---|---|
| Uses `Chat Completions` (`/v1/chat/completions`) | Uses `Responses` (`/v1/responses`) |
| You define the function schema | No schema needed |
| You execute the function yourself | The platform executes it |
| Typically requires two calls | Often returns the final answer in one call |
| More control | Less setup |

### Why Different APIs?

- `Chat Completions` is a natural fit for custom functions and explicit tool-call loops.
- `Responses` is the recommended API for built-in tools such as `web_search`, `file_search`, and `computer_use`.

The important teaching point is not the endpoint name itself, but the operating model:

- with custom tools, your application usually executes the tool
- with built-in tools, the platform can execute the tool for you

Documentation:
- [OpenAI Tools](https://platform.openai.com/docs/guides/tools)
- [Gemini Tools](https://ai.google.dev/gemini-api/docs/tools)
- [Claude Tool Use](https://platform.claude.com/docs/en/agents-and-tools/tool-use/overview)

## Demo 3: Function Call with the OpenAI Python Library

Goal: repeat the same custom-function pattern in Python, where the workflow is easier to read than raw HTTP calls.

What this shows:
- how to use the OpenAI Python library for function calling
- how to define a custom weather function in Python
- how to handle the two-step flow: tool request first, final answer second

Suggested walkthrough:

1. Define a simple `get_weather(location)` function that returns mock data.
2. Initialize the OpenAI client and define the tool schema.
3. Ask for the weather in Paris and inspect the returned tool call.
4. Execute the function with the model-provided arguments.
5. Send the tool result back to the model and print the final answer.

Why this matters: Python makes the control flow much easier to explain than a long JSON payload in `curl`, while still teaching the same underlying pattern.

Run the examples:

```bash
python 01a_custom_function_call.py
python 01b_built_in_tool.py
```

## Teaching Notes

If you present these demos live, a good sequence is:

1. Show the plain text-only limitation first.
2. Show a custom function call where the model returns structured arguments.
3. Show that the application must execute the function and send the result back.
4. Contrast that with a built-in tool where the platform handles the execution.
5. Repeat the same idea in Python for readability.

This keeps the conceptual lesson simple: text generation, structured tool request, external execution, and final response.
