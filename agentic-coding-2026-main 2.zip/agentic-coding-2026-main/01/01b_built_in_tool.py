"""
Demo 3b: Built-In Tool with OpenAI Responses API

This script demonstrates how to use OpenAI's built-in tools (like web_search)
using the Responses API. This is much simpler than custom functions because:
- No need to define function schemas
- No need to execute functions yourself
- OpenAI handles everything automatically
- Single API call returns the final answer

This mirrors Demo 2 (cURL) but uses Python.
"""

from dotenv import load_dotenv
from openai import OpenAI

# Load environment variables from .env file
load_dotenv()

# Initialize the OpenAI client
# Make sure you have OPENAI_API_KEY set in your environment or .env file
client = OpenAI()


def main():
    """Main function demonstrating the built-in tool workflow."""
    
    print("Using OpenAI's built-in web_search tool...")
    print("-" * 60)
    print("Question: What is the weather like today in Paris?")
    print("-" * 60)
    
    # Make a single API call with the built-in web_search tool
    # The Responses API handles everything automatically:
    # 1. Model decides to use web_search
    # 2. OpenAI executes the search
    # 3. Model generates final answer with search results
    # All in one call!
    
    response = client.responses.create(
        model="gpt-5.3-chat-latest",
        tools=[{"type": "web_search"}],
        input="What is the weather like today in Paris?"
    )
    
    print("\nFinal Answer:")
    print("-" * 60)
    print(response.output_text)
    print("-" * 60)
    
    # Show usage information if available
    if hasattr(response, 'usage'):
        print(f"\nToken usage: {response.usage}")
    
    print("\nKey difference from custom functions:")
    print("- Single API call (vs. two calls for custom functions)")
    print("- No function schema needed")
    print("- OpenAI executes the tool automatically")
    print("- Simpler, but less control over the tool execution")


if __name__ == "__main__":
    main()

