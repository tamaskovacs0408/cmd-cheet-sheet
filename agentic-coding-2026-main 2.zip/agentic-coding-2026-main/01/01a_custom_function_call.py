"""
Demo 3a: Custom Function Call with OpenAI Python Library

This script demonstrates how to use the OpenAI Python library to:
1. Ask the model a question that requires a function call
2. Handle the tool call response
3. Execute your custom function
4. Send the result back to get a final natural-language answer

This mirrors Demo 1 (cURL) but uses Python for a cleaner workflow.
"""

import json
from dotenv import load_dotenv
from openai import OpenAI

# Load environment variables from .env file
load_dotenv()

# Initialize the OpenAI client
# Make sure you have OPENAI_API_KEY set in your environment or .env file
client = OpenAI()


def get_weather(location: str, unit: str = "celsius") -> dict:
    """
    Custom weather function that returns mock weather data.
    
    In a real application, this would call an actual weather API.
    For this demo, we're just returning the same text/data structure
    to keep it simple and clear.
    
    Args:
        location: The city name (e.g., "Paris, France")
        unit: Temperature unit ("celsius" (default) or "fahrenheit")
    
    Returns:
        Dictionary with weather information
    """
    # Mock weather data - in reality, you'd call a real weather API here
    return {
        "temperature": 15,
        "condition": "Partly cloudy",
        "humidity": 65,
        "location": location,
        "unit": unit
    }


def main():
    """Main function demonstrating the custom function call workflow."""
    
    # Step 1: Define the function schema for the model
    tools = [
        {
            "type": "function",
            "function": {
                "name": "get_weather",
                "description": "Get the current weather in a given location",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "location": {
                            "type": "string",
                            "description": "The city and state, e.g. San Francisco, CA"
                        },
                        "unit": {
                            "type": "string",
                            "enum": ["celsius", "fahrenheit"],
                            "description": "The unit for temperature, the default is Celsius"
                        }
                    },
                    "required": ["location"]
                }
            }
        }
    ]
    
    # Step 2: Make the first API call - ask about weather in Paris
    print("Step 1: Asking the model about weather in Paris...")
    print("-" * 60)
    
    response = client.chat.completions.create(
        model="gpt-5.3-chat-latest",
        messages=[
            {
                "role": "user",
                "content": "What is the weather like in Paris today?"
            }
        ],
        tools=tools,
        tool_choice="auto"
    )
    
    message = response.choices[0].message
    print(f"Model response: {message.content}")
    print(f"Tool calls: {len(message.tool_calls) if message.tool_calls else 0}")
    
    # Print token usage for the first API call
    if response.usage:
        print(f"\nToken usage (first call):")
        print(f"  Input tokens: {response.usage.prompt_tokens}")
        print(f"  Output tokens: {response.usage.completion_tokens}")
        print(f"  Total tokens: {response.usage.total_tokens}")
    
    # Step 3: Check if the model wants to call a function
    if message.tool_calls:
        print("\nStep 2: Model requested a function call!")
        print("-" * 60)
        
        # Extract the tool call information
        tool_call = message.tool_calls[0]
        function_name = tool_call.function.name
        function_args = json.loads(tool_call.function.arguments)
        
        print(f"Function to call: {function_name}")
        print(f"Arguments: {function_args}")
        
        # Step 4: Execute the function
        print("\nStep 3: Executing the custom function...")
        print("-" * 60)
        
        function_result = get_weather(
            location=function_args.get("location"),
            unit=function_args.get("unit", "celsius")
        )
        
        print(f"Function returned: {function_result}")
        
        # Step 5: Send the function result back to get the final answer
        print("\nStep 4: Sending function result back to model for final answer...")
        print("-" * 60)
        
        # Build the conversation history including the tool call and result
        messages = [
            {
                "role": "user",
                "content": "What is the weather like in Paris today?"
            },
            {
                "role": "assistant",
                "content": None,
                "tool_calls": [
                    {
                        "id": tool_call.id,
                        "type": "function",
                        "function": {
                            "name": function_name,
                            "arguments": tool_call.function.arguments
                        }
                    }
                ]
            },
            {
                "role": "tool",
                "tool_call_id": tool_call.id,
                "name": function_name,
                "content": json.dumps(function_result)
            }
        ]
        
        final_response = client.chat.completions.create(
            model="gpt-5.3-chat-latest",
            messages=messages,
            tools=tools
        )
        
        final_answer = final_response.choices[0].message.content
        print(f"\nFinal Answer: {final_answer}")
        print("-" * 60)
        
        # Print token usage for the second API call
        if final_response.usage:
            print(f"\nToken usage (second call):")
            print(f"  Input tokens: {final_response.usage.prompt_tokens}")
            print(f"  Output tokens: {final_response.usage.completion_tokens}")
            print(f"  Total tokens: {final_response.usage.total_tokens}")
            
            # Calculate total tokens across both calls
            if response.usage:
                total_input = response.usage.prompt_tokens + final_response.usage.prompt_tokens
                total_output = response.usage.completion_tokens + final_response.usage.completion_tokens
                total_all = response.usage.total_tokens + final_response.usage.total_tokens
                print(f"\nTotal token usage (both calls):")
                print(f"  Total input tokens: {total_input}")
                print(f"  Total output tokens: {total_output}")
                print(f"  Grand total tokens: {total_all}")
        print("-" * 60)
    else:
        print("Model did not request a function call.")


if __name__ == "__main__":
    main()

