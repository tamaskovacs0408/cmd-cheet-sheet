Take the current conversation context, the codebase facts you discovered, and the final agreed plan from planning mode. Create a Product Requirements Document in a new file called PRD.md.

Do not interview me again unless there is a hard blocker that makes the PRD impossible to write. If a detail is still unknown, write the recommended assumption explicitly in the PRD.

Before writing PRD.md:
- Briefly re-read the relevant code if needed so the PRD reflects the actual repository.
- Separate product decisions from implementation decisions.
- Prefer clear, testable requirements over broad statements.
- Keep the PRD useful for a coding agent that will implement this later.
- Treat the planning-mode output as the source of truth, unless the codebase clearly contradicts it.

Write PRD.md using this structure:

# PRD: <Feature Name>

## Problem Statement

Explain the problem from the user's perspective.

## Goals

List the concrete outcomes this feature must achieve.

## Non-Goals

List what is intentionally out of scope for this change.

## Actors

List the relevant users, roles, systems, or external services involved in the feature.

## User Stories

Write a numbered list of user stories. Use this format:
1. As a <role>, I want <capability>, so that <benefit>.

## Functional Requirements

Write requirements as testable statements. Use MUST / SHOULD / MAY.

## UX Requirements

Describe the visible user experience, including empty states, loading states, success states, and error states where relevant.

## Permission and Access Requirements

Describe who or what is allowed to perform each important action. If permissions are not relevant, state that explicitly.

## State and Data Requirements

Describe what state must be tracked, persisted, derived, or migrated. Include recommended assumptions if the existing codebase does not already answer something.

## Integration and Side-Effect Requirements

Describe any external systems, background jobs, notifications, analytics events, file outputs, API calls, or other side effects. If none are relevant, state that explicitly.

## Implementation Notes

Summarize the likely modules or interfaces that need to change, based on the current codebase. Do not include large code snippets.

## Testing Requirements

Describe behavior-focused tests that should be written. Tests should verify observable behavior through public interfaces, not private implementation details.

## Acceptance Criteria

Write a checklist of concrete acceptance criteria.

## Open Questions and Recommended Answers

List any remaining open questions. For each one, include your recommended answer.

After writing PRD.md, stop. Do not implement the feature yet.
