Implement Phase <PHASE_NUMBER> from IMPLEMENTATION_PLAN.md using red-green test-driven development.

Read these files first:
- PRD.md
- IMPLEMENTATION_PLAN.md
- Any existing project instruction file such as AGENTS.md or CLAUDE.md
- The relevant source and test files for this phase

Important workflow rules:
- Implement only Phase <PHASE_NUMBER>.
- Do not jump ahead to later phases.
- Do not rewrite the whole feature in one pass.
- Use vertical red-green cycles: one behavior test, minimal implementation, repeat.
- Tests must verify observable behavior through public interfaces.
- Avoid tests that depend on private helper functions or implementation details.
- Prefer existing test patterns in the repository.

Process:

1. Restate the phase goal and acceptance criteria in your own words.

2. Identify the first behavior to test.
   Choose the smallest meaningful behavior for this phase.

3. RED:
   Write exactly one failing test for that behavior.
   Run the narrowest relevant test command.
   Confirm that the test fails for the expected reason.

4. GREEN:
   Write the minimal implementation needed to pass that test.
   Run the same test again.
   Confirm that it passes.

5. Repeat:
   Continue with the next behavior in the phase.
   Keep each cycle small.

6. Refactor:
   Only after the tests are green, clean up duplication or awkward design.
   Run tests again after refactoring.

7. Final verification:
   Run the relevant test, lint, typecheck, or build commands listed in the project instructions or package scripts.

8. Stop:
   Summarize:
   - what changed
   - which tests were added or updated
   - which commands passed
   - any commands that could not be run
   - whether Phase <PHASE_NUMBER> is complete
   - what the next phase should be

Do not commit changes unless I explicitly ask you to commit.