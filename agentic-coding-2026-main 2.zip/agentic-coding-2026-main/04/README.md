# Lecture 4: First Agentic Coding Session

## Goal

In lecture 03 you installed the tools and looked at the tooling landscape. In this lecture you will start using them on a real repository.

The goal is not to make the model code as fast as possible. The goal is to practice the first professional workflow:

- clone an unfamiliar app
- give the coding agent durable project context
- use a planning-only session before touching code
- compare a weak first prompt with a stronger requirements-discovery prompt
- review the agent's plan before letting it edit files

You can do the exercise with Claude Code, Codex, or both. Claude Code still centers project memory around `CLAUDE.md`. Codex and many newer tools center it around `AGENTS.md`.

## Exercise Repository

Use the example app repository:

```bash
git clone -b start-here https://github.com/Megzo/lumora.git
cd lumora
bun install
# create and seed the DB
bun --bun run db:migrate
bun --bun run db:seed
# run the app
bun run dev
```

This branch intentionally starts without a `CLAUDE.md`. That makes it a good first example for project memory setup.

Run the app once before starting the agent workflow. This gives you a quick smoke test that the project starts, and it installs `node_modules`. Having dependencies locally available can also help coding agents inspect installed package types, source files, and function signatures instead of guessing how a dependency works.

Start with a clean baseline:

```bash
git status
```

Notice that the repo has normal human-facing documentation, but no agent-facing instruction file yet.

## Human Docs vs Agent Docs

`README.md` is mainly for humans. It explains what the project is, how to run it, and how to contribute.

`AGENTS.md` or `CLAUDE.md` is for coding agents. It should contain the project facts and working agreements the agent should always know before it starts:

- app architecture and important directories
- setup, run, lint, typecheck, and test commands
- coding style and framework conventions
- common pitfalls and project-specific constraints
- what "done" means before the agent should stop

These files are not magic. They are plain Markdown loaded into context. If they are vague, stale, or too long, the agent will still make bad assumptions. Keep them short, accurate, and practical.

## `AGENTS.md` and `CLAUDE.md`

The ecosystem is converging on `AGENTS.md` as a general, tool-neutral instruction file for coding agents. The official [AGENTS.md](https://agents.md/) site describes it as a README for agents: a predictable place for build steps, tests, conventions, and project-specific instructions.

OpenAI Codex documents `AGENTS.md` as the custom instruction file it reads before doing work. Codex can load global guidance and project guidance, then combine them into the session context.

Claude Code uses `CLAUDE.md` for the same basic purpose. Claude Code loads `CLAUDE.md` files at the start of the session as project memory. Its `/init` command creates a starter `CLAUDE.md` for the current project.

If your team uses multiple agents, the best practice is to keep one canonical file and symlink the other name to it.

If Claude creates `CLAUDE.md` first:

```bash
ln -s CLAUDE.md AGENTS.md
```

If the team standard is `AGENTS.md` first:

```bash
ln -s AGENTS.md CLAUDE.md
```

If symlinks are not available in your environment, use one canonical file and make the other file a tiny pointer that tells the agent to read the canonical file.

## Global and Project Instructions

There are usually two useful layers:

- global personal instructions: how you like the agent to communicate and work across all projects; these live outside the repo and should not be committed
- project instructions: facts and commands that belong to this repository and should usually be committed

For Claude Code, the documented global user memory location is:

```text
~/.claude/CLAUDE.md
```

For project-level Claude instructions, use either:

```text
./CLAUDE.md
./.claude/CLAUDE.md
```

For Codex, the documented global instruction location is:

```text
~/.codex/AGENTS.md
```

For project-level Codex instructions, use:

```text
./AGENTS.md
```

Some agent ecosystems also use `.agents/` for shared agent assets and skills. If you want a repo-local `.agents/AGENTS.md`, verify that your tool auto-loads it or configure it as a fallback instruction filename. Do not assume every agent reads hidden instruction paths by default.

Use global instructions for personal environment facts that are true for you but not necessarily true for the rest of the team. For example, if you work in WSL, this can make sense in your global file:

```md
# Personal Agent Instructions

- You are running in WSL.
- Prefer Linux shell commands.
```

That sentence should not go into the committed project file because it is not true for everyone on the team.

Do not put secrets, private URLs, API keys, or machine-specific credentials into committed instruction files.

## Step 1: Claude Code `/init`

In the `lumora` repo, start Claude Code:

```bash
claude
```

Then run:

```text
/init
```

While it runs, keep these points in mind:

- `/init` asks Claude Code to inspect the repository and create a starter `CLAUDE.md`.
- The generated file is a first draft, not an authority.
- It may infer framework details correctly, but it cannot know team decisions, business rules, or future workflow preferences unless you add them.
- Review it like code before committing it.

After `/init`, inspect the generated file. Ask yourself:

- Did it find the correct package manager?
- Did it list the real dev, build, lint, and test commands?
- Did it identify the important app directories?
- Did it invent anything?
- Is anything too vague to be useful?

Then add the compatibility symlink:

```bash
ln -s CLAUDE.md AGENTS.md
```

Now both Claude-style and AGENTS-style tools have a project instruction entry point.

## Step 1b: Codex `/init`

You can do the same setup from the Codex side.

In the `lumora` repo, start Codex:

```bash
codex
```

Then run:

```text
/init
```

Codex documents `/init` as the command that generates an `AGENTS.md` scaffold in the current directory. The workflow is the same as with Claude:

- scaffold the file quickly
- review the generated content carefully
- remove vague or invented guidance
- add the commands and project rules that actually matter
- commit the project-level instruction file so future sessions inherit it

If Codex creates `AGENTS.md` first and you also want Claude Code compatibility, add:

```bash
ln -s AGENTS.md CLAUDE.md
```

## What Belongs in the First Version?

Start small. A useful first `CLAUDE.md` or `AGENTS.md` should usually include:

```md
# Project Instructions

## Commands

- Install dependencies: ...
- Start dev server: ...
- Run tests: ...
- Run lint/typecheck: ...

## Architecture

- ...

## Conventions

- ...

## Verification

- Before finishing, run ...
- If checks cannot be run, explain why.
```

Avoid turning the file into a second README. The agent does not need a marketing overview. It needs operational context.

## Step 2: Plan Mode

Before asking for a real feature, switch into planning mode.

Claude Code's documented mode cycle is:

```text
Shift+Tab
```

This cycles through modes such as default, accept edits, and plan mode. On some terminal setups, `Shift+Tab` may not reach plan mode correctly; `Alt+M` can be used as a fallback. You can also enter planning explicitly with:

```text
/plan
```

Plan mode is useful because the agent can explore the codebase and propose a design without editing files. This gives you a pause point where you can check assumptions, correct requirements, and decide whether the implementation is worth approving.

Good plan mode behavior:

- the agent reads relevant files instead of guessing
- the plan names affected areas of the codebase
- the plan calls out unknowns and tradeoffs
- the plan explains verification steps
- you iterate on the plan before allowing edits

## Important Warning: Models Are Eager

Coding agents are trained to be helpful, and "helpful" often means they quickly produce a plausible plan and then start implementing.

That is dangerous on real features.

The first plan is often confident, but not necessarily correct. It may miss product intent, edge cases, permissions, data migration concerns, naming rules, or operational constraints. Treat the plan as a design review artifact, not as a formality.

Spend time on the plan. Ask the agent to justify choices. Ask what files it inspected. Ask what alternatives it rejected. Ask what could break. If the task is ambiguous, force the agent to interview you before implementation.

## Prompt 1: Basic Plan Prompt

Use this first prompt without explicitly instructing the model to slow down and interview you.

```text
Currently the recording does not work in LiveKit. But I also realized that the current way of doing the recording is not good: currently the recording is started automatically when a session starts.

I need this to be started by hand, by one of the lecturers, and they can also stop the recording with another button. This is to avoid having a lot of idle time at the beginning of the session while waiting for users to join.

Also, we can have breaks during the sessions, so we might stop the recording and start a new one after the break. We have to make sure that a new recording file is generated in this case with appropriate numbering, e.g. the first video is called session-name_1, the second session-name_2, etc.
```

What to observe:

- Does the agent ask enough questions?
- Does it inspect the relevant code paths before designing?
- Does it clarify who is allowed to use the feature?
- Does it clarify where important state lives?
- Does it clarify naming, identifiers, or data ownership?
- Does it define what should happen after failures, retries, or repeated actions?

Most models will produce a plan quickly. The plan may look reasonable, but it will probably hide unresolved product decisions.

## Prompt 2: Interview-First Plan Prompt

Now run a new planning session with the same task, but add the following section.

```text
Currently the recording does not work in LiveKit. But I also realized that the current way of doing the recording is not good: currently the recording is started automatically when a session starts.

I need this to be started by hand, by one of the lecturers, and they can also stop the recording with another button. This is to avoid having a lot of idle time at the beginning of the session while waiting for users to join.

Also, we can have breaks during the sessions, so we might stop the recording and start a new one after the break. We have to make sure that a new recording file is generated in this case with appropriate numbering, e.g. the first video is called session-name_1, the second session-name_2, etc.

Interview me relentlessly about every aspect of this plan until we reach a shared understanding. Walk down each branch of the design tree, resolving dependencies between decisions one-by-one. For each question, provide your recommended answer.

Ask the questions one at a time.

If a question can be answered by exploring the codebase, explore the codebase instead.
```

What should change:

- The agent should separate codebase facts from product decisions.
- It should inspect the repo for existing domain concepts, permissions, state, and integration points.
- It should ask one unresolved question at a time.
- It should recommend an answer instead of making you design everything from scratch.
- The final plan should be more grounded and easier to review.

## What This Shows

The important lesson is not that prompt 2 is longer. The important lesson is that it changes the workflow.

Prompt 1 invites the agent to solve.

Prompt 2 first asks the agent to discover, clarify, and converge.

For small edits, prompt 1 may be enough. For product behavior, permissions, state machines, payments, authentication, migrations, integrations, or anything user-facing, prompt 2 is much safer.

## Letting the Agent Implement Once

After you have a plan that looks reasonable, you can let the agent implement it once.

This is intentionally not the final workflow yet. It is useful because it shows what happens when the agent goes from plan to code in a long session:

- it may do impressive work quickly
- it may also lose track of earlier assumptions
- it may implement too much in one pass
- it may write tests after the fact instead of using them to drive design
- the conversation context may become noisy

## Context Management

Long agent sessions are not free. The model keeps using the conversation, tool outputs, file snippets, plans, errors, and corrections as context. That context can help, but it can also become stale or distracting.

It is crucial to know where you are in the context window. Unfortunately, Claude Code and Codex do not show this by default. Other tools, such as OpenCode and Cursor, make context usage visible in the interface, which is one reason they can feel easier to manage during long sessions.

For Claude Code, you can add a status line to your personal config at `~/.claude/settings.json`. This example shows the model name and current context usage. The permission settings are personal workflow choices; adjust them to your own safety preferences.

```json
{
  "statusLine": {
    "type": "command",
    "command": "jq -r '\"[\\(.model.display_name)] \\(.context_window.used_percentage // 0)% context (\\(((((.context_window.current_usage.input_tokens // 0) + (.context_window.current_usage.cache_creation_input_tokens // 0) + (.context_window.current_usage.cache_read_input_tokens // 0)) / 100) | floor) / 10)k)\"'"
  }
}
```

For Codex, you can add a status line to `~/.codex/config.toml`:

```toml
[tui]
status_line = ["model-with-reasoning", "current-dir", "context-used", "context-window-size"]
```

Use a fresh session when:

- the task has changed
- the previous plan was wrong
- the conversation contains many dead ends
- you want the agent to re-read the repo instead of relying on old assumptions

Use compaction when:

- the task is still the same
- the session is getting long
- you want to preserve decisions but remove low-value detail

For Claude Code, useful commands are:

```text
/compact
/clear
```

The practical rule is simple: if the old context still represents the current truth, compact it. If the old context is misleading, clear it and restart from durable artifacts.

Durable artifacts are files such as:

- `CLAUDE.md` or `AGENTS.md`
- `PRD.md`
- `IMPLEMENTATION_PLAN.md`
- tests
- code

These are better than hoping the model remembers an important decision from 80 messages ago.

## From Plan to PRD

A plan is useful for deciding whether the agent understands the work. A PRD is useful for preserving that understanding outside the chat.

After the interview-first planning step, ask the agent to turn the agreed plan into a local `PRD.md`. Use the raw copy-paste prompt in:

[`prd-prompt.md`](./prd-prompt.md)

For this lecture, keep this as a raw prompt. Do not turn it into a reusable skill yet. The point is to see the prompting pattern directly:

- summarize the product problem
- define goals and non-goals
- capture user stories
- capture permission and state decisions
- write acceptance criteria
- preserve open questions and recommended answers

After the agent writes `PRD.md`, read it before continuing. A bad PRD will produce a bad implementation plan.

## From PRD to Multi-Phase Plan

Next, turn `PRD.md` into `IMPLEMENTATION_PLAN.md`. Use:

[`multi-phase-plan.md`](./multi-phase-plan.md)

The important idea is vertical slicing.

A bad plan often uses horizontal phases:

- build all backend
- build all frontend
- add all tests
- clean up

A better plan uses vertical slices:

- establish the safest baseline and prove existing behavior still works
- add the smallest user-visible path for the first behavior
- add the next narrow behavior through the same public interfaces
- add important edge cases or repeated state transitions
- polish UI states, errors, permissions, and operational concerns

Each phase should be small enough to test and verify on its own.

## Execute with Red-Green TDD

Finally, implement one phase at a time using red-green TDD. Use:

[`implement-with-tdd.md`](./implement-with-tdd.md)

The important constraint is: do not ask the agent to write all tests first and then all code. That is another horizontal slice.

Instead, make the agent repeat this loop:

```text
RED: write one failing behavior test
GREEN: write the smallest implementation that passes
REPEAT: move to the next behavior
REFACTOR: only after tests are green
```

This keeps the implementation grounded in behavior. It also gives you more checkpoints where you can stop, inspect the diff, run tests, and correct the direction before the agent builds too much.

In the next lecture, this raw prompt workflow can become reusable skills. For now, keep the prompts visible and copy-pasteable so you can understand what instructions the agent is actually following.

## Your Exercise Flow

1. Clone `lumora` on branch `start-here`.
2. Start Claude Code in the repo.
3. Run `/init`.
4. Review the generated `CLAUDE.md`.
5. Add the `AGENTS.md` compatibility symlink.
6. Optionally repeat the same setup from Codex with `/init` and compare `AGENTS.md`.
7. Enter plan mode with `Shift+Tab`, `Alt+M`, or `/plan`.
8. Run prompt 1 and critique the plan.
9. Clear or start a fresh planning session.
10. Run prompt 2 and compare the interaction.
11. Optionally let the agent implement once from the plan and observe what happens.
12. Use [`prd-prompt.md`](./prd-prompt.md) to create `PRD.md`.
13. Use [`multi-phase-plan.md`](./multi-phase-plan.md) to create `IMPLEMENTATION_PLAN.md`.
14. Use [`implement-with-tdd.md`](./implement-with-tdd.md) to implement one phase with red-green TDD.
15. Stop after one phase and review the diff, tests, and remaining plan.

## References

- [Claude Code commands](https://code.claude.com/docs/en/commands)
- [Claude Code memory](https://code.claude.com/docs/en/memory)
- [Claude Code permission modes](https://code.claude.com/docs/en/permission-modes)
- [Codex slash commands](https://developers.openai.com/codex/cli/slash-commands/)
- [Codex custom instructions with AGENTS.md](https://developers.openai.com/codex/guides/agents-md)
- [AGENTS.md open format](https://agents.md/)
