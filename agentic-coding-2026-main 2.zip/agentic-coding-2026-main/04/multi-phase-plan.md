Based on PRD.md and the relevant codebase context. Create a multi-phase implementation plan in a new file called IMPLEMENTATION_PLAN.md.

Do not implement anything yet.

The plan should break the feature into vertical slices, also called tracer bullets. A vertical slice is a small end-to-end change that can be tested and verified on its own. Avoid horizontal slices like "build all backend first", "build all UI last", or "write all tests at the end".

Before writing the plan:
- Re-read PRD.md.
- Re-read the relevant source files if needed.
- Identify the public interfaces that should be tested.
- Identify any existing test patterns that should be followed.
- Prefer small phases that reduce risk and keep the app working.
- Keep the planning-mode decisions and PRD requirements aligned.

Each phase must include:
- Goal: what user-visible or externally observable behavior this phase delivers.
- Scope: what is included.
- Out of scope: what must not be done yet.
- Likely code areas: files, modules, or interfaces that may need to change.
- Tests first: the behavior-focused tests to write before implementation.
- Implementation notes: the smallest implementation that should satisfy the tests.
- Verification: exact checks the agent should run.
- Dependencies: which earlier phases must be complete.

Use this structure:

# Implementation Plan: <Feature Name>

## Strategy

Explain the overall implementation strategy in a few paragraphs. Emphasize vertical slices, red-green TDD, and frequent verification checkpoints.

## Phase 1: <Smallest Safe Baseline or First User-Visible Slice>

Create the smallest useful change that reduces risk, establishes the baseline, or proves the first observable behavior.

## Phase 2: <Next Observable Behavior>

Add the next narrow end-to-end behavior. Keep the app working and verify the behavior through public interfaces.

## Phase 3: <Next Observable Behavior>

Continue with the next smallest behavior needed by the PRD.

## Additional Phases

Add as many phases as the feature needs, but keep each phase independently reviewable and testable. Prefer fewer, sharper phases over broad buckets.

## Final Verification

List all commands and manual checks that should pass before considering the feature done.

If you think the phases should be different after reading the codebase, adjust them. Keep the result practical for this repository and this feature.

After writing IMPLEMENTATION_PLAN.md, stop and summarize the phases. Do not implement the feature yet.