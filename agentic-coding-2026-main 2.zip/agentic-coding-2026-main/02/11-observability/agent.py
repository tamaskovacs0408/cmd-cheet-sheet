"""
Topic 11: the same agent, now with OTEL traces going to the local collector.

Pydantic-ai emits OTEL spans that follow the GenAI semantic conventions
(gen_ai.request.model, gen_ai.usage.input_tokens, ...) plus its own
agent-run / model-request / tool-call hierarchy. We configure a plain
OpenTelemetry SDK that ships traces to whatever `OTEL_EXPORTER_OTLP_ENDPOINT`
points at. In this lecture, that's the collector from ../compose.yaml
which fans traces out to Phoenix (on :6006) and Tempo (via Grafana on :3001).

Run it:
    (cd .. && docker compose up -d)
    uv run python agent.py "How many python files are under /tmp?"
    # then open http://localhost:6006 (Phoenix) or http://localhost:3001 (Grafana)

The waterfall you will see is the same loop from ../07-agent-loop/agent.py
and ../10-frameworks/agent.py. The framework hid the loop; OTEL puts it
back in view.
"""

from __future__ import annotations

import subprocess
import sys

from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from pydantic_ai import Agent

# OTLPSpanExporter reads OTEL_EXPORTER_OTLP_ENDPOINT from the environment.
# Default: http://localhost:4318 (the collector from ../compose.yaml).
provider = TracerProvider(
    resource=Resource.create({"service.name": "session-02-agent"})
)
provider.add_span_processor(BatchSpanProcessor(OTLPSpanExporter()))
trace.set_tracer_provider(provider)

tracer = trace.get_tracer(__name__)

agent = Agent(
    "anthropic:claude-sonnet-4-6",
    instructions=(
        "You are a terminal assistant. Use run_bash to investigate the filesystem "
        "and answer the user's question. Be concise. Stop as soon as you have the answer."
    ),
    instrument=True,  # emit OTEL spans with GenAI semconv attributes
)


@agent.tool_plain
def run_bash(command: str) -> str:
    """Run a bash command and return stdout, stderr, and exit code."""
    result = subprocess.run(
        command, shell=True, capture_output=True, text=True, timeout=15
    )
    return (
        f"exit_code: {result.returncode}\n"
        f"stdout:\n{result.stdout}\n"
        f"stderr:\n{result.stderr}"
    )


if __name__ == "__main__":
    prompt = (
        sys.argv[1] if len(sys.argv) > 1 else "How many python files are under /home?"
    )
    with tracer.start_as_current_span("session_02_demo", attributes={"prompt": prompt}):
        result = agent.run_sync(prompt)
    print(result.output)
    # Flush spans before exit so short runs don't lose them.
    provider.force_flush()
