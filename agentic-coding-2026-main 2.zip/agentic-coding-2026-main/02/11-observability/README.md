# 11. Observability

[Topic 10](../10-frameworks/) hid the loop inside a framework. Topic 11 puts it back in view as an OpenTelemetry waterfall.

This matters for two reasons:

1. **Debugging.** When an agent does something unexpected (wrong tool call, stuck in a loop, wasted tokens on a useless retry) the trace tells you exactly where it went wrong.
2. **Standards.** The OpenTelemetry community has agreed on a set of attributes for LLM and agent telemetry (`gen_ai.request.model`, `gen_ai.usage.input_tokens`, ...). Once your agent emits these, *any* OTel-compatible backend can ingest the data: Logfire, Phoenix, Langfuse, Braintrust, Datadog, Honeycomb, Grafana, SigNoz.

## Demo

Same pydantic-ai agent as topic 10, plus a plain OpenTelemetry SDK wired up to the local collector. The relevant lines are these:

```python
from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor

provider = TracerProvider(resource=Resource.create({"service.name": "session-02-agent"}))
provider.add_span_processor(BatchSpanProcessor(OTLPSpanExporter()))
trace.set_tracer_provider(provider)

agent = Agent("anthropic:claude-sonnet-4-6", instrument=True, ...)
```

`instrument=True` tells pydantic-ai to emit its own spans with GenAI semconv attributes. `OTLPSpanExporter()` reads `OTEL_EXPORTER_OTLP_ENDPOINT` from the environment (default: `http://localhost:4318`), which is where the collector defined in [`../compose.yaml`](../compose.yaml) listens.

Run it:

```sh
# 1. Bring up the collector + backends. One-time until you `docker compose down`.
(cd .. && docker compose up -d)

# 2. Run the agent.
uv sync
uv run python agent.py "How many markdown files are under /tmp?"
```

Then open one of:

- **Phoenix**: http://localhost:6006 for agent-flavored views of LLM calls, tokens, tool spans.
- **Grafana → Tempo**: http://localhost:3001 → Explore → Tempo for the generic distributed-trace waterfall.

Either way you will see the loop reappear:

```
session_02_demo
└── agent.run
    ├── model.request          (LLM call #1)   input_tokens=412, output_tokens=89
    ├── tool.run run_bash      (host execution)
    ├── model.request          (LLM call #2)   input_tokens=523, output_tokens=42
    └── ...                    (until end_turn)
```

That nested structure *is* the loop from topic 07. The framework executed it; OTEL made it visible.

## Two semantic conventions

Pydantic-ai emits spans that conform to two overlapping vocabularies. Both are OTEL-compatible; both serialize to the same wire format. They differ in how much detail they capture.

- **[GenAI semantic conventions](https://opentelemetry.io/docs/specs/semconv/gen-ai/)**: the OTEL-official set. Attributes like `gen_ai.system`, `gen_ai.request.model`, `gen_ai.usage.input_tokens`, `gen_ai.response.finish_reasons`. Stable, vendor-neutral, spec-driven.
- **[OpenInference](https://github.com/Arize-ai/openinference)**: Arize's richer, agent-oriented alternative. More detail on tools, retrievers, and agent-specific spans. Phoenix uses it natively, which is why Phoenix renders the trace more richly than a generic Tempo/Grafana view.

Your collector doesn't care. Pick a backend based on which view you want, not on which convention you emit.

## The portability point

The same agent code, unchanged, could feed:

- A self-hosted stack like the one defined in [`../compose.yaml`](../compose.yaml) (Phoenix + Tempo).
- A hosted product like Logfire, Langfuse, Braintrust, Datadog, Honeycomb.
- A generic trace backend like Jaeger or SigNoz.

You change the `OTEL_EXPORTER_OTLP_ENDPOINT` (and auth header if applicable). The code stays the same.

## What you can do once you have traces

- **Cost analysis.** Sum `gen_ai.usage.output_tokens × price_per_token` across spans. Per-trace, per-tool, per-user.
- **Latency hotspots.** Find the one tool call that's eating 40% of total wall time.
- **Catching runaway loops.** Alert when span counts per trace exceed a threshold.
- **Eval dataset harvesting.** Replay real production traces as eval cases. (Forward reference: a later session covers evals in depth.)
- **Comparing agents.** Same spans across two model versions or two prompts → direct comparison of cost, latency, and behavior.
- **CI and production monitoring.** Same instrumentation, different `service_name`. Your dev agent and your prod agent emit the same shape.

## Why this matters

Observability is what lets you say true things about an agent. Without it, you have a black box that occasionally produces good outputs and occasionally costs you $50 in tokens for no apparent reason. With it, you can reason about behavior, latency, cost, and failure modes, and you can compare two agents the way you compare two services.

The next topic uses exactly this technique on Claude Code itself.

## Resources

- [OpenTelemetry GenAI Semantic Conventions](https://opentelemetry.io/docs/specs/semconv/gen-ai/)
- [OpenInference](https://github.com/Arize-ai/openinference)
- [Logfire](https://logfire.pydantic.dev/)
- [pydantic-ai + Logfire integration](https://ai.pydantic.dev/logfire/)
- [Phoenix](https://phoenix.arize.com/): open-source Arize alternative
