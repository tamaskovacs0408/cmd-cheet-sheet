# 8. Agent Control Flow

[Topic 07](../07-agent-loop/) showed the loop mechanically: `while True`, check `stop_reason`, execute tool calls, append results. Now we put names on what is happening inside it, and look at how it goes wrong.

## What the loop is actually doing

Every iteration of the loop runs three phases, borrowed from the [ReAct paper](https://arxiv.org/abs/2210.03629) (Yao et al., 2022):

- **Reason.** The model reads the conversation so far (the goal, prior tool results, its own prior thoughts) and decides what to do next. In the Messages API this is whatever `text` the model emits before or alongside a `tool_use` block.
- **Act.** The model emits a `tool_use` block naming a tool and its arguments. Your application executes it.
- **Observe.** The tool's return value goes back into `messages` as a `tool_result`. The model sees it on the next turn.

Then the model reasons again. That is the whole cycle. It repeats until the model emits `end_turn` or your `max_turns` fires.

You will also see this written as **Reason → Plan → Act → Observe**. "Plan" is a specialization of reasoning where the model produces a multi-step sketch before acting on any of it. Some agent frameworks split this out into a dedicated planning call:

- **Interleaved (default Claude Code, pydantic-ai, most toy agents):** one model call per loop iteration; reasoning and acting are mixed in the same response.
- **Plan-then-execute:** one model call produces a plan as structured output ([topic 06](../06-structured-output/)); subsequent calls execute each step. Useful when the task is long, when plans need human approval before anything runs, or when planning and execution use different models ("big model plans, cheap model executes").

Neither is universally better. Interleaved is simpler and adapts to surprises. Plan-then-execute is auditable and cheaper to gate.

## Failure modes

The loop is a simple state machine. It has a small number of recurring failure modes. You will see all of them in [topic 11's](../11-observability/) traces.

### Runaway loop

The model keeps calling tools and never emits `end_turn`. Every turn adds to `messages`, so context grows, cost grows, and eventually either the context window fills up or the model gets confused enough to call the same tool with the same arguments forever.

Defense: `max_turns`. Always. Even on a toy.

### Wrong tool for the job

The model picks a tool that can't answer the question (`Grep` when it needed `Glob`, `read_file` when it needed `list_dir`). It sees the useless result, picks another tool, and eventually converges, but it spent turns and tokens getting there.

Defense: tight tool descriptions, disjoint tool sets ("the right one is obvious"), and fewer tools. Adding a tool almost always degrades tool selection. Ten tools is a lot.

### Hallucinated tool or argument

The model calls a tool that doesn't exist, or passes an argument that violates the schema. The Messages API rejects schema-violating arguments before they reach your code, but semantic violations (`command: "git push --force"` when your schema accepts any string) are on you.

Defense: validate at the boundary. Your tool implementation should reject inputs it won't execute, not trust the model. The `tool_result` carries the rejection back to the model, which will usually try again with better arguments.

### Silent success, wrong answer

A tool that returns `exit_code: 0` with empty output is one of the easiest ways for an agent to lie to you. The model issued a command that does not crash, gets nothing back, and concludes there was nothing to do.

The usual cause is cross-platform drift. `sed -i` takes different arguments on BSD and GNU. `grep -P` is missing on busybox. And on macOS, `/tmp` is a symlink to `/private/tmp`, and BSD `find` does not traverse symlinks at the starting point by default:

```
find /tmp -type f -name "*.tmp"         # macOS: empty, even if /tmp/asd.tmp exists
find -L /tmp -type f -name "*.tmp"      # macOS: /tmp/asd.tmp (as expected)
find /tmp -type f -name "*.tmp"         # Linux: /tmp/asd.tmp (as expected)
```

Run the HITL demo in [topic 09](../09-human-in-the-loop/) on macOS and you will see this live: the agent "cleans" `/tmp/*.tmp`, reports success, and leaves every file in place.

Defense: distrust "zero matches, exit 0" for commands whose job is to *find* something. Return structured results from tools (`{"matches": N, "paths": [...]}`) instead of raw stdout where you can, so an empty response is unambiguous. And record the host platform in the system prompt so the model at least has a chance to pick the right dialect.

### Infinite retry on a transient error

A tool fails (network blip, rate limit, file not found). The model retries. The tool fails again. The model retries. Forever.

Defense: return structured errors from tools. `exit_code: 2, stderr: "ENOENT"` is more useful to the model than a Python exception. And if the failure is permanent, say so: `{"error": "PERMANENT", "reason": "file does not exist"}`. The model usually stops retrying when told retry won't help.

### Stuck tool call

The tool itself hangs. `curl` to a dead URL, a shell command waiting for stdin, a database query with no timeout.

Defense: timeouts on every tool. The host, not the model, enforces them. The 50-line agent in [topic 07](../07-agent-loop/) uses `timeout=15` on `subprocess.run`. That is the right pattern.

## Error handling as control flow

A production agent's error handling is four decisions, repeated for every tool:

1. **Retry.** Transient failures (timeout, 5xx, rate limit). Exponential backoff with a cap.
2. **Fallback.** Swap to an alternative tool when the primary is unavailable or returns nothing useful.
3. **Escalate.** Hand control back to the human. Covered in [topic 09](../09-human-in-the-loop/).
4. **Fail gracefully.** Return a clear error to the model so it can either try a different approach or give up cleanly.

Which one fires depends on the tool, the error, and the task. There is no universal policy. The shape of the decision is worth internalizing even if the details are case-by-case.

## Subtask decomposition

For long tasks, the model benefits from breaking the work down before acting. Two patterns:

- **Explicit plan step.** Use [structured output](../06-structured-output/) to make the model emit `{"steps": [...]}` as its first turn. The loop then walks the steps. Claude Code's Plan Mode is a version of this.
- **Implicit decomposition.** The system prompt encourages step-by-step reasoning ("Before running any tool, describe your approach."). The model produces prose that happens to list the steps, then executes them itself in the same loop.

Explicit is auditable and gateable. Implicit is cheaper and more flexible. Pick per task.

## Why this matters

The loop in [topic 07](../07-agent-loop/) is trivial to write. Making it *work reliably* on real tasks is where engineering effort goes, and it almost all comes down to:

- Naming the failure modes so you can spot them.
- Defending every tool with timeouts, schemas, and structured errors.
- Deciding where retries, fallbacks, and escalations sit.
- Putting a `max_turns` on everything.

The rest of this lecture gives you the tools to do this work: human-in-the-loop gates ([topic 09](../09-human-in-the-loop/)) for escalation, frameworks ([topic 10](../10-frameworks/)) that provide retry and error handling out of the box, and observability ([topic 11](../11-observability/)) that shows you which failure mode is firing in production.

## Resources

- [ReAct: Synergizing Reasoning and Acting in Language Models (Yao et al., 2022)](https://arxiv.org/abs/2210.03629)
- [Anthropic: Building effective agents](https://www.anthropic.com/research/building-effective-agents): the canonical catalog of agent design patterns
- [Anthropic Cookbook: error handling in tool use](https://github.com/anthropics/anthropic-cookbook/tree/main/tool_use)
