"""
Topic 10: The same agent, written in pydantic-ai.

Functionally identical to topic 07's agent.py, but the explicit loop,
the message accumulation, and the tool dispatch are all hidden behind
the framework. Compare side-by-side to see what an "agent framework"
actually abstracts away.

Run it:
  uv run python agent.py "count the markdown files under /home"
"""

from __future__ import annotations

import subprocess
import sys

from pydantic_ai import Agent

agent = Agent(
    "anthropic:claude-sonnet-4-6",
    instructions=(
        "You are a terminal assistant. Use run_bash to investigate the filesystem "
        "and answer the user's question. Be concise. Stop as soon as you have the answer."
    ),
)


@agent.tool_plain
def run_bash(command: str) -> str:
    """Run a bash command and return stdout, stderr, and exit code."""
    result = subprocess.run(
        command, shell=True, capture_output=True, text=True, timeout=15
    )
    return (
        f"exit_code: {result.returncode}\n"
        f"stdout:\n{result.stdout}\n"
        f"stderr:\n{result.stderr}"
    )


if __name__ == "__main__":
    prompt = (
        sys.argv[1] if len(sys.argv) > 1 else "How many python files are under /home?"
    )
    result = agent.run_sync(prompt)
    print(result.output)
