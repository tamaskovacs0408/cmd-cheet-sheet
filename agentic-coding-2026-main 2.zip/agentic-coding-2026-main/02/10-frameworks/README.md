# 10. Frameworks

The same agent from [topic 07](../07-agent-loop/), written in [pydantic-ai](https://ai.pydantic.dev/), is about ten lines:

```python
agent = Agent("anthropic:claude-sonnet-4-6", instructions="...")

@agent.tool_plain
def run_bash(command: str) -> str:
    ...

result = agent.run_sync("How many markdown files are under /tmp?")
print(result.output)
```

The `while` loop, the `messages` list, the `stop_reason` checks, the `tool_use` / `tool_result` plumbing: all hidden inside `agent.run_sync`.

## Demo

```sh
uv run python agent.py "How many markdown files are under /tmp?"
```

Same prompt, same model, same tool, same answer as topic 07. Just less code, and less visibility into what's happening.

## The tradeoff

| | By hand (topic 07) | Framework |
|---|---|---|
| Lines of code | ~50 | ~10 |
| What you see | every turn, every tool call | the final answer |
| What you control | everything | what the framework exposes |
| What goes wrong | obvious from the print statements | not obvious |
| Onboarding cost | read the loop | learn the framework's abstractions |

Frameworks are a real productivity win. They are also the reason most engineers describe agents as "magic": the loop is real, but they have never seen it.

[Topic 11](../11-observability/) fixes that by reattaching observability so the framework's hidden loop reappears as a trace.

## The framework landscape

A non-exhaustive map of agent frameworks worth knowing about:

| Framework | Language | Notes |
|---|---|---|
| [pydantic-ai](https://ai.pydantic.dev/) | Python | Type-driven, model-agnostic, integrates with Logfire |
| [OpenAI Agents SDK](https://openai.github.io/openai-agents-python/) | Python | Successor to OpenAI's deprecated Assistants API; tight OpenAI integration |
| [LangGraph](https://langchain-ai.github.io/langgraph/) | Python / TS | Graph-based; explicit state machines for complex multi-agent workflows |
| [Mastra](https://mastra.ai/) | TypeScript | TS-native; agents, tools, workflows, memory in one package |
| [Vercel AI SDK](https://sdk.vercel.ai/) | TypeScript | Streaming-first; common in Next.js apps |

All of them implement the same loop you wrote in topic 07. Pick one based on language, ecosystem, and how much abstraction suits your project.

## Why this matters

A framework hides the loop, but the loop is still there. When you debug a framework-built agent (wrong tool call, runaway loop, hallucinated tool name, mysterious cost) you are debugging the loop. If you have only ever seen the framework's `agent.run_sync(...)` API, you have no mental model of what to look at.

That is why this lecture builds the loop by hand first and *then* introduces frameworks. The order matters.

## Resources

- [pydantic-ai documentation](https://ai.pydantic.dev/)
- [Anthropic: Building effective agents](https://www.anthropic.com/research/building-effective-agents): patterns and pitfalls common to all framework choices
