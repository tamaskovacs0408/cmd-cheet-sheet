# 2. The Chat API

Chat is just completion with structure: a `messages` array of role-tagged turns instead of a single `prompt` string. The provider applies a chat template (the `<|im_start|>...` markers from [topic 01](../01-text-completion/)) before calling the same next-token machinery.

Both Anthropic and OpenAI converged on this shape. The fields differ slightly; the idea is identical.

## OpenAI

The request body has two fields that do the real work: `model` and `messages`.

`messages` is an ordered list of turns. Each turn has a `role` (`system`, `user`, `assistant`, or `tool`) and a `content` string. The provider concatenates them into the chat template from [topic 01](../01-text-completion/) before calling the model. Everything the model "sees" on a given call is in this array.

The first turn, with `role: "system"`, is the **system prompt**: a top-of-conversation instruction that sets persona, format, constraints, or policy. It's not a special field. It's a regular message that happens to sit at the top of the rendered template, which is why the model tends to follow it more reliably than anything that appears later in the conversation.

```sh
curl -s https://api.openai.com/v1/chat/completions \
  -H "Authorization: Bearer $OPENAI_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gpt-4o-mini",
    "messages": [
      {"role": "system", "content": "You are a terse assistant. One sentence only."},
      {"role": "user", "content": "What is the capital of Hungary?"}
    ]
  }' | jq
```

### OpenAI API History

OpenAI's API has gone through three generations:

| Endpoint | Shipped | What it added |
|---|---|---|
| `/v1/completions` | 2020 (GPT-3) | Pure text completion. The primitive from [topic 01](../01-text-completion/). Now Legacy. |
| `/v1/chat/completions` | March 2023 (GPT-3.5-turbo) | The `messages` array with role-tagged turns. Function calling added June 2023; renamed and extended to tool calling ([topic 05](../05-tool-calling/)) in November 2023. Still stateless. |
| `/v1/responses` | March 2025 | Server-side state ([topic 04](../04-conversation-history/)) via `previous_response_id` instead of replaying history; built-in tools (web search, file search, code interpreter); first-class support for reasoning models. |

## Anthropic

```sh
curl -s https://api.anthropic.com/v1/messages \
  -H "x-api-key: $ANTHROPIC_API_KEY" \
  -H "anthropic-version: 2023-06-01" \
  -H "content-type: application/json" \
  -d '{
    "model": "claude-sonnet-4-6",
    "max_tokens": 256,
    "system": "You are a terse assistant. One sentence only.",
    "messages": [
      {"role": "user", "content": "What is the capital of Hungary?"}
    ]
  }' | jq
```

### Anthropic API History

Anthropic's evolution is flatter: `/v1/messages` shipped in 2023 already chat-shaped, and Anthropic has added tools, prompt caching, extended thinking, and so on in-place rather than spinning up new endpoints.

## What's the same, what's different

Both APIs converged on the same core shape. Once you've written against one, the other is a day of field renaming, not a week of rearchitecting.

**Common across both:**

- A `model` identifier in the request.
- A `messages` array of role-tagged turns (`user`, `assistant`).
- A response object that carries generated content and a stop signal.
- A `usage` accounting block itemizing input and output tokens so you can predict the bill. Prompt caching ([topic 04](../04-conversation-history/)) reduces the input charge for repeated prefixes on both providers.

**Where they differ:**

| | Anthropic | OpenAI |
|---|---|---|
| System prompt | top-level `system` field | first `messages` entry with `role: "system"` |
| Response payload | `content[]` of typed blocks (`text`, `tool_use`, ...) | `choices[].message.content` (string) |
| Stop signal | `stop_reason` | `finish_reason` |
| Token accounting | `usage.input_tokens` / `output_tokens` | `usage.prompt_tokens` / `completion_tokens` |

The most consequential difference is the response payload. Anthropic's `content` is an array of *typed* blocks. Today it holds one `text` block. From [topic 05](../05-tool-calling/) onward it will also carry `tool_use` blocks. OpenAI keeps `content` as a plain string and puts tool calls on a sibling `tool_calls` field. Same capability, different shape.

The rest is surface-level. If you understand one, you understand both.

## Resources

- [Anthropic Messages API reference](https://docs.claude.com/en/api/messages)
- [OpenAI Chat Completions reference](https://platform.openai.com/docs/api-reference/chat)
- [Anthropic system prompts](https://docs.claude.com/en/docs/build-with-claude/prompt-engineering/system-prompts)
