# Observability stack

Local OpenTelemetry collector + two trace backends (Phoenix, Tempo via Grafana). Used by [topic 11](../11-observability/) (the pydantic-ai agent) and [topic 12](../12-real-coding-agents/) (Claude Code).

One collector listens on OTLP HTTP `4318` and OTLP gRPC `4317`. Everything you run on your host points at it. The collector fans each incoming trace out to both backends. Metrics and logs are accepted too (Claude Code emits them) but printed to the collector's stdout for now.

## Start

The compose file lives one level up at [`../compose.yaml`](../compose.yaml) (project name `agentic-coding-lecture-02`). Run from that directory:

```sh
cd ..            # into 02/
docker compose up -d
```

Then, depending on what you want to see:

| UI | URL | What it's good for |
|---|---|---|
| Phoenix | http://localhost:6006 | Agent-flavored views: LLM call details, token counts per span, nested retriever/tool spans. |
| Grafana (Tempo) | http://localhost:3001 → Explore → Tempo | Generic distributed-trace waterfall. No LLM opinions. |

## Point your client at the collector

Either use the env vars directly, or let a config file do it.

**Pydantic-ai agent** ([topic 11](../11-observability/)): the agent.py reads `OTEL_EXPORTER_OTLP_ENDPOINT`. Either it's already set in your shell, or set it inline:

```sh
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4318 \
  uv run python ../11-observability/agent.py "How many python files are under /tmp?"
```

**Claude Code** ([topic 12](../12-real-coding-agents/)): the `.claude/settings.json` in that topic's directory sets every env var Claude Code needs. Just `cd 12-real-coding-agents && claude`.

## Stop

From `02/`:

```sh
docker compose down              # keep data
docker compose down -v           # wipe phoenix + tempo volumes
```

## How to tell if it's working

```sh
docker compose logs -f otel-collector
```

You should see lines like `TracesExporter ... #spans: N` once a trace arrives. If traces flow but Phoenix shows nothing, open the Phoenix URL and check the *Projects* tab; traces land under `service.name`.

## Layout

- `../compose.yaml`: four services: collector, phoenix, tempo, grafana. Project name `agentic-coding-lecture-02`.
- `otel-collector.yaml`: receivers (OTLP grpc/http) and two trace exporters (otlphttp → phoenix, otlp → tempo).
- `tempo.yaml`: minimal local-storage Tempo config.
- `grafana-datasources.yaml`: provisions Tempo as Grafana's default datasource.
