# Lecture 2: From Text Completion to Agents

## Overview

If all an LLM does is complete text, how does Claude Code edit files, ChatGPT browse the web, or Cursor run your tests?

This lecture answers that question from the bottom up: the raw completion call, the chat shape on top of it, tool calling and structured output, the agent loop and how it fails, a framework that hides the loop, and OpenTelemetry traces that put it back in view. The closing topic runs the same tracing on Claude Code itself to show that nothing magical happens at any step.

## Learning Objectives

By the end of this lecture, you will be able to:

- Use common LLM completion APIs (Anthropic Messages, OpenAI Chat Completions) and explain how streaming and conversation history work on top of them
- Explain where state lives in an LLM-based application and why every chat turn replays the full history
- Use tool calling and structured output to move typed data in and out of a model
- Implement a minimal agent loop from scratch and name the failure modes it is prone to
- Insert a human-in-the-loop permission gate without breaking the loop
- Distinguish what an agent framework abstracts away from what is actually happening underneath
- Read an OpenTelemetry trace of a coding agent and identify every span, including on a real tool like Claude Code

## Topics

### 1. [Text Completion](./01-text-completion/)

What does an LLM actually do under the hood? Is "predicting the next token" really the whole story?

### 2. [The Chat API](./02-chat-api/)

What does a real API request to Claude or GPT look like? What goes in, what comes back, and where do Anthropic and OpenAI differ?

### 3. [Streaming](./03-streaming/)

Why does ChatGPT type its response word-by-word? Does streaming make the model faster, or just feel faster?

### 4. [Conversation History](./04-conversation-history/)

How does a chatbot "remember" the conversation? Where is the chat history actually stored, and who pays for it?

### 5. [Tool Calling](./05-tool-calling/)

How does Claude Code actually edit a file or run your tests? When an LLM "uses a tool," what is really happening between the model and your machine?

### 6. [Structured Output](./06-structured-output/)

How do you get typed data out of a model that only emits text? And why is this the same primitive as tool calling, just without the round trip?

### 7. [The Agent Loop](./07-agent-loop/)

What *is* an "agent," really? And how much code does it take to build one from scratch?

### 8. [Agent Control Flow](./08-agent-control-flow/)

What is the loop actually *doing* inside each iteration? Where does it go wrong, and how do you keep it from spiralling?

### 9. [Human-in-the-Loop](./09-human-in-the-loop/)

Where does the human fit once the model is driving? How do you insert a permission gate without breaking the loop?

### 10. [Frameworks](./10-frameworks/)

What does an agent framework do for you? What does it hide, and is that a problem?

### 11. [Observability](./11-observability/)

How do you debug an agent that took 30 turns when it should have taken 3? How do you reason about its cost, latency, and mistakes?

### 12. [Reading a Real Coding Agent](./12-real-coding-agents/)

Is Claude Code doing anything fundamentally different from the toy you just built? What's inside the black box?

## Further Reading

Cross-cutting references that span multiple topics. Topic-specific links live in each topic's own README.

API reference:

- [Anthropic Messages API](https://docs.claude.com/en/api/messages)
- [OpenAI Chat Completions](https://platform.openai.com/docs/api-reference/chat)

Agent framework landscape:

- [pydantic-ai](https://ai.pydantic.dev/)
- [OpenAI Agents SDK](https://openai.github.io/openai-agents-python/)
- [LangGraph](https://langchain-ai.github.io/langgraph/)
- [Mastra](https://mastra.ai/)
- [Vercel AI SDK](https://sdk.vercel.ai/)

Observability:

- [OpenTelemetry GenAI Semantic Conventions](https://opentelemetry.io/docs/specs/semconv/gen-ai/)
- [OpenInference](https://github.com/Arize-ai/openinference)

Tracing backends (the course uses the first two; the rest are named for reference):

- [Phoenix](https://phoenix.arize.com/): self-host; used in the local stack.
- [Tempo](https://grafana.com/oss/tempo/) + [Grafana](https://grafana.com/oss/grafana/): self-host; used in the local stack for generic waterfall views.
- [Logfire](https://logfire.pydantic.dev/): hosted; pydantic-native.
- [Langfuse](https://langfuse.com/): self-host or hosted; strong for prompt/eval workflows.
- [Braintrust](https://www.braintrust.dev/): hosted; eval-first.

Further reading on agent design:

- [Anthropic: Building effective agents](https://www.anthropic.com/research/building-effective-agents)
