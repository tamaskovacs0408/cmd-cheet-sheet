# 1. Text Completion

An LLM is a next-token predictor. Given a sequence of tokens, it returns a probability distribution over the next token, samples one, appends it, and repeats.

Nothing else.

Everything in this lecture (chat, tool calls, agents, IDE integrations) is built on top of this single primitive.

## Demo

OpenAI's older `gpt-3.5-turbo-instruct` model is served on the `/v1/completions` endpoint. The endpoint is literally called *completions*.

```sh
curl -s https://api.openai.com/v1/completions \
  -H "Authorization: Bearer $OPENAI_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gpt-3.5-turbo-instruct",
    "prompt": "To be, or not to be, that is the question:\nWhether tis nobler in the mind to suffer\n",
    "max_tokens": 10,
    "temperature": 0
  }' | jq
```

Response (abbreviated):

```json
{
  "choices": [
    {
      "text": "The slings and arrows of outrageous fortune,\nOr"
    }
  ],
  "usage": { "prompt_tokens": 24, "completion_tokens": 10, "total_tokens": 34 }
}
```

The model finished the phrase. That is *all* it did.

> [!NOTE]
> `/v1/completions` is OpenAI's original API, shipped in 2020 with GPT-3.
>
> It only ever did pure text completion: no roles, no tools, no chat.
>
> Today it is marked **Legacy** in OpenAI's docs, with only a handful of models still served on it.
> Frontier models are exclusively on `/v1/chat/completions` and `/v1/responses`, both covered in [topic 02](../02-chat-api/).

Let's try another one:

```sh
curl -s https://api.openai.com/v1/completions \
  -H "Authorization: Bearer $OPENAI_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gpt-3.5-turbo-instruct",
    "prompt": "The quick brown fox",
    "max_tokens": 10,
    "temperature": 0
  }' | jq
```

## Try it on a true base model (Ollama)

The `gpt-3.5-turbo-instruct` model in the demo above is instruction-tuned, even though we hit it through the completions endpoint. To see how a *true* base model behaves, run one locally with [Ollama](https://ollama.com/).

```sh
ollama pull llama3.2:1b-text-q4_K_M
```

> [!NOTE]
> The `-text-*` tags are the pre-instruction-tuning base models. The default `llama3.2:1b` is the instruct variant. The trailing `q4_K_M` is the quantization level.

Ollama exposes the same OpenAI-compatible `/v1/completions` endpoint on `localhost:11434`, so the only changes from the demo above are the URL and the model:

```sh
curl -s http://localhost:11434/v1/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "llama3.2:1b-text-q4_K_M",
    "prompt": "To be, or not to be, that is the question:\nWhether tis nobler in the mind to suffer\n",
    "max_tokens": 10,
    "temperature": 0
  }' | jq
```

Let's try another one:

```sh
curl -s http://localhost:11434/v1/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "llama3.2:1b-text-q4_K_M",
    "prompt": "The quick brown fox",
    "max_tokens": 10,
    "temperature": 0
  }' | jq
```

## "But ChatGPT doesn't just complete my sentences"

This is the most common confusion. Modern chat models *are* still doing completion. They are completing inside a chat-shaped template that looks roughly like this:

```
<|im_start|>system
You are a helpful assistant.<|im_end|>
<|im_start|>user
What is the capital of Hungary?<|im_end|>
<|im_start|>assistant
```

The example above uses **ChatML**, the template format originally introduced by OpenAI for GPT-3.5/4 and now adopted by open-weight models like Qwen. Other model families use different templates:

- Llama 3 uses `<|start_header_id|>` and `<|eot_id|>`
- Mistral uses `[INST]` and `[/INST]`
 
Each model's exact template lives in its `tokenizer_config.json` on Hugging Face, and the canonical reference for how to use them is [Hugging Face's chat templating docs](https://huggingface.co/docs/transformers/main/en/chat_templating).

The model's job is to predict what comes next after `<|im_start|>assistant\n`. The provider's API hides the template behind a `messages` array, but the underlying call is the same: tokens in, tokens out.

This is the entire principle behind coding assistants: the conversation you have with Claude Code or Cursor is, eventually, prompt text the model continues. It's just wrapped in a chat template instead of emitted raw.

The next topic, [The Chat API](../02-chat-api/), shows exactly that translation.

## Why this matters for the rest of the lecture

If you internalize "LLMs complete text and nothing else," everything that follows lands cleanly:

- A **chatbot** is a list of messages your app keeps and replays into the prompt every turn.
- A **tool call** is the model emitting a structured pattern your code recognizes and acts on.
- An **agent** is a loop that keeps adding to the prompt (tool results, intermediate reasoning) until the model emits a stop token.

If you don't internalize it, the rest will feel like magic. It isn't.

## Resources

- [OpenAI Completions API Reference](https://platform.openai.com/docs/api-reference/completions)
- [Lecture 1: How models turn text into tokens](../../01/README.md#2-how-models-turn-text-to-tokens)
- [Lecture 1: The probabilistic nature of LLM outputs](../../01/README.md#6-about-non-determinism-of-llm-outputs)

### Alternative endpoints

If you don't have an OpenAI key, you can demonstrate the same primitive elsewhere:

- [Together AI](https://docs.together.ai/reference/completions): hosts open-weight base models (e.g. `meta-llama/Meta-Llama-3.1-8B`) on an OpenAI-compatible `/v1/completions` endpoint. A true base model (no instruction tuning) makes the "just completes the next tokens" behavior even starker.
- [Hugging Face Inference Providers](https://huggingface.co/docs/inference-providers): a single HF token routed to multiple providers; useful for swapping base models without re-keying.
