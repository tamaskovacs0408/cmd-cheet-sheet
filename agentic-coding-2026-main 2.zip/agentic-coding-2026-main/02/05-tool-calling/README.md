# 5. Tool Calling

Tool calling is the single most important capability shift in this lecture. Before tools, the model could only generate text from training data and prompt context. With tools, the model can ask the application to run code, look up data, or call APIs, and incorporate the results into its next response.

## Demo: the missing piece

Ask the model a question that depends on the state of *your* machine, with no tools defined:

```sh
curl -s https://api.anthropic.com/v1/messages \
  -H "x-api-key: $ANTHROPIC_API_KEY" \
  -H "anthropic-version: 2023-06-01" \
  -H "content-type: application/json" \
  -d '{
    "model": "claude-sonnet-4-6",
    "max_tokens": 512,
    "messages": [
      {"role": "user", "content": "How many files are in /tmp?"}
    ]
  }' | jq
```

The model's reply will be something like:

> I don't have access to your filesystem, so I can't check `/tmp` on your machine. You could run `ls /tmp | wc -l` in a terminal and I can help interpret the output.

The model knows perfectly well *what command would answer the question*. It just cannot run it. The Chat API from [topic 02](../02-chat-api/) is a pure text-in/text-out function: no side effects, no environment access.

This is the gap tool calling closes. We give the model a way to say *"please run `ls /tmp | wc -l` for me"* in a structured form the application can recognize and act on.

## The mechanism

The mechanism is small. You describe each tool as a [JSON Schema](https://json-schema.org/) (the same vocabulary you'd use to validate an HTTP payload), the model emits a block that matches the schema naming the tool and its arguments, and your application acts on it and sends a result back.

But there is a critical detail that catches almost everyone:

> **The API does not run anything. It just tells you what it would like to happen.**

Executing the tool is the application's job. Sending the result back is the application's job. The model only knows how to *describe* the call it wants made.

## Demo: the model asks, nothing happens

Register one tool (`run_bash`) and ask a question that requires running a shell command:

```sh
curl -s https://api.anthropic.com/v1/messages \
  -H "x-api-key: $ANTHROPIC_API_KEY" \
  -H "anthropic-version: 2023-06-01" \
  -H "content-type: application/json" \
  -d '{
    "model": "claude-sonnet-4-6",
    "max_tokens": 1024,
    "tools": [
      {
        "name": "run_bash",
        "description": "Run a bash command and return stdout, stderr, and the exit code.",
        "input_schema": {
          "type": "object",
          "properties": {
            "command": {"type": "string", "description": "The bash command to execute."}
          },
          "required": ["command"]
        }
      }
    ],
    "messages": [
      {"role": "user", "content": "How many files are in /tmp?"}
    ]
  }' | jq
```

Response (abbreviated):

```json
{
  "stop_reason": "tool_use",
  "content": [
    {
      "type": "tool_use",
      "id": "toolu_01AbCdEf...",
      "name": "run_bash",
      "input": {"command": "ls /tmp | wc -l"}
    }
  ]
}
```

Notice three things:

- **`stop_reason` is `"tool_use"`**, not `"end_turn"`. The model is pausing to wait for a result.
- **The content is a structured `tool_use` block**, not text. It carries an `id`, a `name`, and the `input` JSON arguments.
- **Nothing executed.** The model returned its intent. Your `/tmp` directory is unchanged.

### The stop signal, revisited

[Topic 02](../02-chat-api/) introduced `stop_reason` (Anthropic) / `finish_reason` (OpenAI) as the field that drives control flow. Until now we've seen it carry:

- `end_turn` / `stop`: the model finished and is ready to hand back to the user.
- `max_tokens` / `length`: the model hit the token budget mid-generation.

`tool_use` (Anthropic) / `tool_calls` (OpenAI) is a new third value, and it means something different. The model is **not** done. It has paused and is waiting for the application to act on the `tool_use` block and return a result. This is what turns the Chat API into an agent in [topic 07](../07-agent-loop/).

## When does the tool actually run?

Spelling out exactly where each step happens, because this is the detail everyone gets wrong on a first read:

1. **Your app → API.** Request carries the `messages` and the `tools` (schemas).
2. **Model generates.** It decides it needs a tool and emits a `tool_use` block.
3. **API → your app.** Response has `stop_reason: "tool_use"`. *The API call is over.*
4. **Your app executes the tool.** Ordinary application code, on your machine. The API is not involved.
5. **Your app → API.** New request, with the original `tool_use` block replayed in the assistant turn *and* a matching `tool_result` block appended as the next user turn.
6. **Model generates.** It reads the result and emits either another `tool_use` (goto 3) or `end_turn` with a text answer.

Steps 4 and 5 are the whole reason an agent needs application code at all. The API stops mid-thought. Your code takes over, executes, and resumes the conversation.

## Demo: closing the loop by hand

Take the `tool_use_id` from the previous response, stash it in a shell variable, then pipe the JSON through `envsubst` so curl receives the substituted body. No hand-editing of the payload:

```sh
# Paste the id from the previous response.
export TOOL_USE_ID=toolu_01AbCdEf...

envsubst <<'JSON' | curl -s https://api.anthropic.com/v1/messages \
  -H "x-api-key: $ANTHROPIC_API_KEY" \
  -H "anthropic-version: 2023-06-01" \
  -H "content-type: application/json" \
  -d @- | jq
{
  "model": "claude-sonnet-4-6",
  "max_tokens": 1024,
  "tools": [{
    "name": "run_bash",
    "description": "Run a bash command and return stdout, stderr, and the exit code.",
    "input_schema": {
      "type": "object",
      "properties": {"command": {"type": "string"}},
      "required": ["command"]
    }
  }],
  "messages": [
    {"role": "user", "content": "How many files are in /tmp?"},
    {"role": "assistant", "content": [
      {"type": "tool_use", "id": "${TOOL_USE_ID}", "name": "run_bash", "input": {"command": "ls /tmp | wc -l"}}
    ]},
    {"role": "user", "content": [
      {"type": "tool_result", "tool_use_id": "${TOOL_USE_ID}", "content": "17"}
    ]}
  ]
}
JSON
```

The heredoc's quoted terminator (`<<'JSON'`) stops the shell from touching `${TOOL_USE_ID}`. `envsubst` reads the heredoc on stdin, swaps in the exported variable, and `-d @-` hands the result to curl.

The request includes the entire conversation:

1. The original user question.
2. The assistant turn, *with the original `tool_use` block, verbatim*. This is how the model knows which call the result corresponds to.
3. A new user turn carrying a `tool_result` block with the matching `tool_use_id`.

The model now produces a final answer with `stop_reason=end_turn`.

This round-trip (`tool_use` from the model, `tool_result` from your app) is the agent loop. [Topic 07](../07-agent-loop/) automates it; [topic 06](../06-structured-output/) takes the same `tool_use`-shaped primitive and uses it *without* the round-trip to get typed data out of the model.

## Why this matters

- The model is no longer limited to "what was in training data + the prompt." It can read files, query databases, search the web, or run code.
- The application keeps full control over what tools are available and how they are executed. You can sandbox, log, rate-limit, or refuse any call.
- A single response can contain *multiple* `tool_use` blocks. Your app should execute them all and return all `tool_result`s in the next user turn, possibly in parallel.
- The `input_schema` is a JSON Schema. The model uses it both as documentation and as a structural constraint when generating arguments. Better schemas → better tool calls.

## Resources

- [Anthropic tool use](https://docs.claude.com/en/docs/build-with-claude/tool-use)
- [OpenAI function calling](https://platform.openai.com/docs/guides/function-calling)
- [JSON Schema](https://json-schema.org/): the schema language used in `input_schema`
- [Lecture 1: From Instruct Models to Tool Use](../../01/README.md#10-from-instruct-models-to-tool-use)
