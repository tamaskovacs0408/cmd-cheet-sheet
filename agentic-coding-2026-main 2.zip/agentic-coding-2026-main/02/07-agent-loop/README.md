# 7. The Agent Loop

## Chatbot vs. agent

By now you have a chatbot. [Topic 04](../04-conversation-history/) showed how it works: your app keeps a `messages` list, replays it each turn, and appends the model's reply. The user drives. The model answers. Repeat.

That is everything a chatbot does.

An agent is a chatbot with three additional properties:

- **A goal.** The user's request is a target state, not a single question. ("Fix the failing test" vs. "What is this error?")
- **Tools.** The model can ask the application to act in the world: read a file, run a command, call an API. Covered in [topic 05](../05-tool-calling/).
- **A stop condition the model decides for itself.** The user asks once; after that, the model keeps running until *it* emits `end_turn`. The application keeps sending follow-ups as long as the model keeps asking for tools. The user is out of the loop until the goal is done or the agent gives up.

The loop is what those three properties add up to: a chatbot with tools that runs on its own until the model says it's done.

Put together: *an agent is an LLM in a loop with tools, working toward a goal.*

That is the whole definition. Everything in this topic is making it mechanical.

## The loop, by hand

In [topic 05](../05-tool-calling/) you closed the tool-call round-trip by hand. An agent is a `while` loop that does that automatically: send messages, check `stop_reason`, execute any tool calls, append the results, loop.

That's it. About fifty lines of Python.

> Everything else in the industry (pydantic-ai, OpenAI Agents SDK, LangGraph, Mastra, your own Rust crate) is automation around this loop.

## Demo

```sh
uv run python agent.py "How many markdown files are under /tmp?"
```

The script registers `run_bash` as a tool and starts the loop. You will see something like:

```
[turn 0] tool_use run_bash({"command": "find /tmp -name '*.md' | wc -l"})
[turn 0] tool_result 'exit_code: 0\nstdout:\n12\n\nstderr:\n'

[final]
There are 12 markdown files under /tmp.
```

Read [`agent.py`](./agent.py). It is short and worth understanding line by line.

## A note on "turn"

You will see the word *turn* used in two related-but-different senses from here on:

- **API turn:** one entry in the `messages` array (a user turn, an assistant turn, ...). This is what the Chat API from [topic 02](../02-chat-api/) means when it talks about turns.
- **Loop turn:** one iteration of the `while` loop below, meaning one LLM call plus any tool executions it triggers. The `[turn 0]` / `[turn 1]` prints in `agent.py` count loop turns.

A single loop turn typically produces one assistant API turn, and (if tools fired) appends one user API turn carrying the tool results. They line up in simple cases, but they count different things. When a distinction matters in this lecture it will be called out.

## The shape of the loop

Stripped to its essentials:

```python
messages = [{"role": "user", "content": prompt}]

while True:
    response = client.messages.create(messages=messages, ...)
    messages.append({"role": "assistant", "content": response.content})

    if response.stop_reason == "end_turn":
        return response  # done

    if response.stop_reason == "tool_use":
        tool_results = [
            execute(block) for block in response.content
            if block.type == "tool_use"
        ]
        messages.append({"role": "user", "content": tool_results})
        continue
```

Three things are happening:

1. **State lives in `messages`.** The list grows every turn: assistant content, then tool results as the next user turn. Recall [topic 04](../04-conversation-history/): the model is stateless; the loop holds the state.
2. **The stop signal drives control flow.** `end_turn` exits, `tool_use` triggers execution and another iteration. Other stop reasons (`max_tokens`, `stop_sequence`, ...) are edge cases the loop should handle defensively.
3. **`max_turns` is a safety belt.** Without it, a confused model can loop forever, or until you run out of context window. [Topic 08](../08-agent-control-flow/) goes deep on the failure modes that make this safety belt necessary.

## Why this matters

This is the canonical "agent" definition made concrete: an LLM in a loop with tools. If you understand this loop, you understand every coding agent on the market. They differ only in the tool set, the system prompt, the safety rails, and the surrounding ergonomics.

[Topic 08](../08-agent-control-flow/) names what the loop is actually doing (the Reason → Act → Observe cycle) and catalogs how it fails. [Topic 09](../09-human-in-the-loop/) inserts a human gate inside the loop. [Topic 10](../10-frameworks/) shows the same agent in pydantic-ai, where the loop becomes invisible. [Topic 11](../11-observability/) puts it back in view via tracing.

## Resources

- [Anthropic: Tool use overview](https://docs.claude.com/en/docs/agents-and-tools/tool-use/overview)
- [Anthropic Cookbook: tool use examples](https://github.com/anthropics/anthropic-cookbook/tree/main/tool_use)
- [Anthropic: Building effective agents](https://www.anthropic.com/research/building-effective-agents): design patterns once you have the loop
