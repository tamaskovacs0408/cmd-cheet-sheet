"""
Topic 07: The agent loop, by hand.

This is the entire agentic concept in about 50 lines. Everything else in
the industry (pydantic-ai, OpenAI Agents SDK, LangGraph, Mastra, your own
Rust crate) is automation around this loop.

Talking points when you walk through it live:
  - The `while True` + `stop_reason` check IS the loop.
  - On `tool_use`, we execute and append `tool_result` as a *user* turn.
  - On `end_turn`, we print the final text and stop.
  - History grows every turn. That's your context-window budget going up.

Run it:
  uv run python agent.py "count the markdown files under /home"
"""

from __future__ import annotations

import json
import subprocess
import sys

from anthropic import Anthropic

client = Anthropic()

TOOLS = [
    {
        "name": "run_bash",
        "description": "Run a bash command and return stdout, stderr, and exit code.",
        "input_schema": {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "The bash command to execute.",
                }
            },
            "required": ["command"],
        },
    },
]

SYSTEM = (
    "You are a terminal assistant. Use run_bash to investigate the filesystem "
    "and answer the user's question. Be concise. Stop as soon as you have the answer."
)


def run_bash(command: str) -> str:
    """Host-side tool implementation."""
    result = subprocess.run(
        command, shell=True, capture_output=True, text=True, timeout=15
    )
    return (
        f"exit_code: {result.returncode}\n"
        f"stdout:\n{result.stdout}\n"
        f"stderr:\n{result.stderr}"
    )


TOOL_FNS = {"run_bash": run_bash}


def run_agent(prompt: str, max_turns: int = 10) -> None:
    messages: list[dict] = [{"role": "user", "content": prompt}]

    for turn in range(max_turns):
        response = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=2048,
            system=SYSTEM,
            tools=TOOLS,
            messages=messages,
        )
        # Append the assistant turn verbatim (includes any tool_use blocks).
        messages.append({"role": "assistant", "content": response.content})

        if response.stop_reason == "tool_use":
            tool_results = []
            for block in response.content:
                if block.type == "tool_use":
                    args = json.dumps(block.input)
                    print(f"[turn {turn}] tool_use {block.name}({args})")
                    output = TOOL_FNS[block.name](**block.input)
                    preview = output[:200] + ("…" if len(output) > 200 else "")
                    print(f"[turn {turn}] tool_result {preview!r}")
                    tool_results.append(
                        {
                            "type": "tool_result",
                            "tool_use_id": block.id,
                            "content": output,
                        }
                    )
            messages.append({"role": "user", "content": tool_results})
            continue

        if response.stop_reason == "end_turn":
            for block in response.content:
                if block.type == "text":
                    print(f"\n[final]\n{block.text}")
            return

        print(f"[unexpected stop_reason] {response.stop_reason}")
        return

    print(f"[max_turns={max_turns} reached without end_turn]")


if __name__ == "__main__":
    prompt = (
        sys.argv[1] if len(sys.argv) > 1 else "How many python files are under /home?"
    )
    run_agent(prompt)
