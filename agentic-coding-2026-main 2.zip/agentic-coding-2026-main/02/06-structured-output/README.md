# 6. Structured Output

By default, the Chat API from [topic 02](../02-chat-api/) returns free-form text. That is fine when a human reads the answer, and terrible when code has to.

```json
"content": [{"type": "text", "text": "The capital of Hungary is Budapest."}]
```

Try parsing that. Your regex works today and breaks tomorrow when the model writes "It's Budapest" instead.

Structured output fixes this. You give the model a schema, and it returns data that matches the schema instead of prose.

Two mechanisms are in use today:

1. **Native JSON schema / `response_format`** (OpenAI, Gemini, and some open-weight models).
2. **Forced JSON via a tool definition** (Anthropic, and any model with tool calling).

Both end up in the same place: typed data on the wire. They differ in how you ask for it.

## Demo A: native JSON schema (OpenAI)

OpenAI's `response_format` accepts a JSON Schema directly. With `strict: true`, the provider guarantees the output conforms to the schema.

```sh
curl -s https://api.openai.com/v1/chat/completions \
  -H "Authorization: Bearer $OPENAI_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gpt-4o-mini",
    "messages": [
      {"role": "user", "content": "Márk, 34, mark@example.com"}
    ],
    "response_format": {
      "type": "json_schema",
      "json_schema": {
        "name": "person",
        "schema": {
          "type": "object",
          "properties": {
            "name":  {"type": "string"},
            "age":   {"type": "integer"},
            "email": {"type": "string"}
          },
          "required": ["name", "age", "email"],
          "additionalProperties": false
        },
        "strict": true
      }
    }
  }' | jq
```

Response:

```json
"choices": [{
  "message": {"content": "{\"name\":\"Márk\",\"age\":34,\"email\":\"mark@example.com\"}"}
}]
```

The content is a JSON *string*. You parse it.

## Demo B: force a tool call as output (Anthropic)

Anthropic does not ship a dedicated "JSON mode." Instead, you define a tool whose `input_schema` describes the shape you want, and force the model to call it by setting `tool_choice`.

```sh
curl -s https://api.anthropic.com/v1/messages \
  -H "x-api-key: $ANTHROPIC_API_KEY" \
  -H "anthropic-version: 2023-06-01" \
  -H "content-type: application/json" \
  -d '{
    "model": "claude-sonnet-4-6",
    "max_tokens": 512,
    "tools": [
      {
        "name": "extract_person",
        "description": "Extract a person record from free text.",
        "input_schema": {
          "type": "object",
          "properties": {
            "name":  {"type": "string", "description": "Full name."},
            "age":   {"type": "integer", "description": "Age in years."},
            "email": {"type": "string", "description": "Email address."}
          },
          "required": ["name", "age", "email"]
        }
      }
    ],
    "tool_choice": {"type": "tool", "name": "extract_person"},
    "messages": [
      {"role": "user", "content": "Márk, 34, mark@example.com"}
    ]
  }' | jq
```

The response is a `tool_use` block with the parsed fields in `input`:

```json
"content": [{
  "type": "tool_use",
  "name": "extract_person",
  "input": {"name": "Márk", "age": 34, "email": "mark@example.com"}
}]
```

No `tool_result` is ever sent back. The "tool" is not a real tool. It is a schema the model is forced to fill in. This is the same primitive as tool calling in [topic 05](../05-tool-calling/), minus the round-trip.

## Why this matters

- **Structured output is tool calling without the side effect.** The schema discipline is identical; only the round-trip is absent.
- **Deterministic extraction.** Parsing names, dates, and numeric fields out of prose is a solved problem the moment you stop asking the model to write prose.
- **Validation at the boundary.** The model's output is already typed and schema-checked by the provider. Your application only has to handle the rare schema violation, not parse English.
- **Pick the right mechanism for the model.** Anthropic models use the forced-tool pattern. OpenAI and Gemini models support native JSON schema. Portable libraries (Instructor, pydantic-ai, OpenAI Agents SDK) paper over the difference, but you should know which one you are using.

## A note on schemas

The same JSON Schema you saw as `input_schema` on real tools in [topic 05](../05-tool-calling/) is what you write here, and it will reappear as function arguments in framework code and as validation rules in your application. Invest in writing good schemas once: clear field names, tight types, sensible `required` lists, short descriptions. Everything downstream gets better.

## Resources

- [Anthropic: Tool use for structured output](https://docs.claude.com/en/docs/build-with-claude/tool-use)
- [OpenAI: Structured Outputs](https://platform.openai.com/docs/guides/structured-outputs)
- [JSON Schema](https://json-schema.org/)
- [Instructor](https://python.useinstructor.com/): Python library that wraps both mechanisms behind a Pydantic interface
