# 4. Conversation History

> **The model has no memory.**

Every call to the API is independent. If you want the model to "remember" something from earlier in a conversation, you re-send it as part of the `messages` array.

This is the most under-appreciated fact about LLM APIs. It is also the entire reason agents need a loop, a context window budget, and prompt caching.

## Demo: it forgets

Three independent calls. Turn A introduces a name. Turn B asks the model the name *without* replaying Turn A, and it has no idea. Turn B' asks the same question with the history replayed, and it answers correctly.

```sh
# === Turn A: introduce myself ===
curl -s https://api.anthropic.com/v1/messages \
  -H "x-api-key: $ANTHROPIC_API_KEY" \
  -H "anthropic-version: 2023-06-01" \
  -H "content-type: application/json" \
  -d '{
    "model": "claude-sonnet-4-6",
    "max_tokens": 128,
    "messages": [
      {"role": "user", "content": "Hi, my name is Márk. Remember it."}
    ]
  }' | jq -r '.content[0].text'

# === Turn B: ask WITHOUT replaying history ===
curl -s https://api.anthropic.com/v1/messages \
  -H "x-api-key: $ANTHROPIC_API_KEY" \
  -H "anthropic-version: 2023-06-01" \
  -H "content-type: application/json" \
  -d '{
    "model": "claude-sonnet-4-6",
    "max_tokens": 128,
    "messages": [
      {"role": "user", "content": "What is my name?"}
    ]
  }' | jq -r '.content[0].text'

# === Turn B': ask WITH history replayed ===
curl -s https://api.anthropic.com/v1/messages \
  -H "x-api-key: $ANTHROPIC_API_KEY" \
  -H "anthropic-version: 2023-06-01" \
  -H "content-type: application/json" \
  -d '{
    "model": "claude-sonnet-4-6",
    "max_tokens": 128,
    "messages": [
      {"role": "user",      "content": "Hi, my name is Márk. Remember it."},
      {"role": "assistant", "content": "Got it, Márk."},
      {"role": "user",      "content": "What is my name?"}
    ]
  }' | jq -r '.content[0].text'
```

Output (abbreviated):

```
=== Turn A: introduce myself ===
Got it, Márk. I'll remember.

=== Turn B: ask WITHOUT replaying history ===
I don't know your name. You haven't told me.

=== Turn B': ask WITH history replayed ===
Your name is Márk.
```

The model didn't change between B and B'. The `messages` array did.

## What "chat" actually is

Every chatbot you have ever used works like this:

1. Your app stores the conversation history (in a database, in memory, or in a file).
2. On every user message, the app sends the *entire history* (or a windowed/summarized version of it) to the model.
3. The model completes the next assistant turn.
4. The app appends the new turn to its store.
5. Repeat.

The "chat" experience is an illusion maintained by your client and server. The model itself is stateless on every single call.

## Why this matters

- **Cost scales with history.** Every turn re-pays input tokens for everything that came before. A 50-turn conversation pays for the entire transcript on every new turn.
- **Context window is a hard ceiling.** Once history exceeds the model's window, you must drop, summarize, or retrieve. ([Lecture 1 covered context-window sizes](../../01/README.md#5-model-sizes--architectures).)
- **Prompt caching exists for a reason.** Providers cache repeated prefixes so you don't pay full price for replaying history.

This last point is what makes agentic loops economically viable. Without prompt caching, an agent that runs for 30 turns would re-pay for the same system prompt and growing history 30 times. With caching, you pay full price once and a small fraction thereafter.

## Resources

- [Anthropic prompt caching](https://docs.claude.com/en/docs/build-with-claude/prompt-caching)
- [OpenAI prompt caching](https://platform.openai.com/docs/guides/prompt-caching)
- [Lecture 1: KV Cache in LLMs](../../01/README.md#7-kv-cache-in-llms): the underlying mechanism that makes prompt caching cheap to serve
