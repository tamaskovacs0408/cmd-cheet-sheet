# 12. Reading a Real Coding Agent

You have built an agent. You have instrumented it. The waterfall trace from [topic 11](../11-observability/) has a familiar shape: an outer span, alternating LLM calls and tool executions, terminating when the model emits `end_turn`.

Now turn the same lens on Claude Code, and you will see the same shape. Just with more tools and a longer loop.

> "Agent" is not a marketing word for something exotic. It is a loop with tools. You wrote one in topic 07.

## Demo: enable Claude Code OTel

Claude Code ships with native OTEL support. Metrics and logs are first-class; distributed traces (the waterfall we care about) are behind a beta flag. Both are needed for this demo.

This directory contains a [`.claude/settings.json`](./.claude/settings.json) that sets every env var Claude Code needs to ship telemetry to the local collector defined in [`../compose.yaml`](../compose.yaml). It points at `http://localhost:4318` (OTLP HTTP), turns on metrics, logs, and the trace beta, and enables the privacy-sensitive `OTEL_LOG_USER_PROMPTS` / `OTEL_LOG_TOOL_DETAILS` / `OTEL_LOG_TOOL_CONTENT` flags so the spans are actually informative.

Claude Code picks up `.claude/settings.json` from the current working directory, so:

```sh
# 1. Bring up the observability stack.
(cd .. && docker compose up -d)

# 2. Launch Claude Code from this directory so the settings.json applies.
claude
```

Then ask Claude Code to do something non-trivial:

```
> count the markdown files in this repo and list the three biggest ones
```

Open the UI:

- **Phoenix**: http://localhost:6006. Look for traces tagged `service.name=claude-code`.
- **Grafana → Tempo**: http://localhost:3001 → Explore → Tempo.

## What you will see

A waterfall that looks like:

```
claude-code session
├── user_prompt
├── api_request         ← LLM call (Sonnet decides what to do)
├── tool.Glob           ← Claude Code's built-in tool
├── api_request         ← LLM call (decide next step)
├── tool.Read
├── api_request
├── tool.Bash
└── api_request         ← final, end_turn
```

This is the loop from topic 07. The tools are richer, the system prompt is longer, the agent has memory and sub-agent dispatch, but the loop is the loop.

## What changes for "real" coding agents vs the toy

The differences from your 50-line agent are quantitative, not qualitative:

| | Topic 07 toy | Claude Code |
|---|---|---|
| Tools | 1 (`run_bash`) | dozens (Read, Edit, Glob, Grep, Bash, WebFetch, ...) |
| System prompt | 2 lines | several pages of instructions and conventions |
| Loop length | a few turns | tens to hundreds of turns |
| Context management | none | summarization, file references, sub-agents |
| Permissioning | none | per-tool allow/deny rules |
| Outputs | text | edits, commits, PRs, ... |

The shape is the same. The loop is the loop.

## A note on sub-agents

One row in that table ("sub-agents") sounds exotic. In the trace it isn't. When Claude Code dispatches a sub-agent, what you see is an ordinary `tool_use` span (`Task` in Claude Code's case) whose "execution" happens to be another agent loop:

```
parent session
├── api_request
├── tool.Task                 ← sub-agent dispatch (a tool call)
│   └── sub-agent session     ← child loop nested inside it
│       ├── api_request
│       ├── tool.Read
│       ├── api_request
│       └── tool.Grep
├── api_request
└── ...
```

The child returns a string. That string lands in the parent's `messages` as a `tool_result`, exactly like the output of `run_bash`. The parent reasons on it, decides what to do next, and keeps looping. Sub-agents are not a new primitive. They are a tool whose implementation happens to be "spin up another agent." We won't build one in this lecture, but the trace makes it obvious that the primitive you already understand is all you need.

## ChatGPT and Claude.ai: same pattern, no traces

You can't export OTEL from the ChatGPT or Claude.ai web apps, but the UI *tells* you when tools are running:

- 🔍 "Searching the web" → web search tool
- 🐍 "Analyzing" / code icon → Python sandbox tool
- 🖼 Image-gen icon → image tool
- 📄 "Working" indicator in Claude.ai Research mode → multi-step tool calls

Open a non-trivial conversation in either product and watch the indicators. You are seeing the same loop you wrote in topic 07, just rendered as UI affordances instead of trace spans.

## Optional: see the raw HTTP with mitmproxy

If you want to confirm down to the wire that Claude Code is making the same `POST /v1/messages` call you wrote in topic 02, route it through a proxy:

```sh
mitmproxy -p 8888 --mode reverse:https://api.anthropic.com
# then point Claude Code at the proxy via:
export ANTHROPIC_BASE_URL=http://localhost:8888
claude
```

Every POST is one turn of the loop. Every response with `stop_reason: tool_use` is the model saying "please run this for me." Same body shape as topic 02's first curl. Full circle.

## The session in one sentence

> An agent is an LLM in a loop with tools. You can read the trace.

## Resources

- [Claude Code monitoring & telemetry](https://docs.claude.com/en/docs/claude-code/monitoring-usage)
- [otel-desktop-viewer](https://github.com/CtrlSpice/otel-desktop-viewer): local OTel collector + UI for quick exploration
- [mitmproxy](https://mitmproxy.org/): for the raw-HTTP variant of this demo
- [Anthropic: Building effective agents](https://www.anthropic.com/research/building-effective-agents)
