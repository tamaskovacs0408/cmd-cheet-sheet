# 3. Streaming

Same API call as [topic 02](../02-chat-api/), same response, just delivered differently.

> **Streaming is a UX feature, not a capability of the model.**

Whether you set `stream: true` or `stream: false`, the model is generating tokens at the same speed. The only difference is whether the server buffers them until the response is complete or pushes each one out the moment it is sampled.

## Demo

Two flags turn streaming on: `"stream": true` in the request body, and `-N` (`--no-buffer`) on curl, which flushes output immediately so you see the typing effect.

```sh
curl -N -s https://api.anthropic.com/v1/messages \
  -H "x-api-key: $ANTHROPIC_API_KEY" \
  -H "anthropic-version: 2023-06-01" \
  -H "content-type: application/json" \
  -d '{
    "model": "claude-sonnet-4-6",
    "max_tokens": 400,
    "stream": true,
    "messages": [
      {"role": "user", "content": "Write a short limerick about Hungarian goulash."}
    ]
  }'
```

Each event arrives as a Server-Sent Event (SSE), formatted as `data: {json}\n\n`. The interesting events are `content_block_delta`, each carrying a few characters of generated text:

```
event: content_block_delta
data: {"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":"There"}}

event: content_block_delta
data: {"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":" once"}}

event: content_block_delta
data: {"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":" was"}}
```

To see only the rendered text, pipe the stream through `jq`:

```sh
curl -N -s https://api.anthropic.com/v1/messages \
  -H "x-api-key: $ANTHROPIC_API_KEY" \
  -H "anthropic-version: 2023-06-01" \
  -H "content-type: application/json" \
  -d '{
    "model": "claude-sonnet-4-6",
    "max_tokens": 400,
    "stream": true,
    "messages": [
      {"role": "user", "content": "Write a short limerick about Hungarian goulash."}
    ]
  }' \
  | grep '^data: ' \
  | sed 's/^data: //' \
  | jq -r 'select(.type=="content_block_delta") | .delta.text' \
  | tr -d '\n'
```

## Why this matters

- **Latency to first token vs total time.** Streaming improves perceived latency dramatically. The user sees output starting in ~300 ms instead of waiting 8 seconds for a long completion. Total wall-clock is identical.
- **Tool calls also stream.** `tool_use` blocks arrive as `input_json_delta` events. You can begin parsing arguments before the model has finished generating them, useful for fast tool dispatch.
- **In an agent loop, streaming is optional.** The loop only acts on the *final* response (the assistant turn carrying `stop_reason`). Until then it can either stream tokens to the user (for visibility) or wait silently. Both work; it is a product decision.

A common pattern in coding agents: stream the model's reasoning text to the UI in real time, but only act on tool calls once the assistant turn is fully assembled.

## Resources

- [Anthropic streaming](https://docs.claude.com/en/api/messages-streaming)
- [OpenAI streaming](https://platform.openai.com/docs/api-reference/chat-streaming)
- [Server-Sent Events (MDN)](https://developer.mozilla.org/en-US/docs/Web/API/Server-sent_events/Using_server-sent_events): the underlying transport
