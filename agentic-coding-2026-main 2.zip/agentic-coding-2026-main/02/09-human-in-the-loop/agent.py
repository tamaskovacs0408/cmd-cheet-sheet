"""
Topic 09: The agent loop with a human-in-the-loop permission gate.

Identical to topic 07's agent.py except for one thing: before executing a
tool_use block, we ask the user. If they reject, we send a synthetic
tool_result back to the model instead of running the command, and the
loop continues.

Talking points when you walk through it live:
  - The gate sits between `tool_use` and `execute`. The rest of the loop
    is unchanged.
  - On rejection we return a tool_result with is_error=true. The model
    reads it on the next turn and adapts (usually: proposes a safer
    command, or asks the user what to do).
  - In production, replace `input()` with a Slack approval, a policy
    engine, or an allowlist. The shape of gate() is all that changes.

Run it:
  uv run python agent.py "delete all .tmp files under /tmp"
"""

from __future__ import annotations

import json
import subprocess
import sys

from anthropic import Anthropic

client = Anthropic()

TOOLS = [
    {
        "name": "run_bash",
        "description": "Run a bash command and return stdout, stderr, and exit code.",
        "input_schema": {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "The bash command to execute.",
                }
            },
            "required": ["command"],
        },
    },
]

SYSTEM = (
    "You are a terminal assistant. Use run_bash to investigate the filesystem "
    "and accomplish the user's task. Be concise. If a proposed command is "
    "rejected, consider why and propose a safer alternative."
)

# Tools whose effects we consider read-only. Auto-approve these.
READ_ONLY_PATTERNS = ("ls ", "cat ", "find ", "grep ", "wc ", "head ", "tail ", "file ")

# find is only read-only without these flags. -delete, -exec, -ok and friends
# flip it into something that mutates the filesystem.
DESTRUCTIVE_FIND_FLAGS = {"-delete", "-exec", "-execdir", "-ok", "-okdir"}


def run_bash(command: str) -> str:
    """Host-side tool implementation."""
    result = subprocess.run(
        command, shell=True, capture_output=True, text=True, timeout=15
    )
    return (
        f"exit_code: {result.returncode}\n"
        f"stdout:\n{result.stdout}\n"
        f"stderr:\n{result.stderr}"
    )


TOOL_FNS = {"run_bash": run_bash}


def gate(tool_name: str, args: dict) -> tuple[bool, str]:
    """Decide whether to execute this tool call.

    Returns (approved, reason). Reason is only used when approved=False,
    so the model can see *why* it was rejected.
    """
    if tool_name == "run_bash":
        cmd = args.get("command", "")
        tokens = cmd.split()
        looks_read_only = any(cmd.strip().startswith(p) for p in READ_ONLY_PATTERNS)
        has_destructive_find = bool(DESTRUCTIVE_FIND_FLAGS.intersection(tokens))
        # Cheap allowlist: obvious read-only commands pass without prompting.
        # The find carve-out exists because `find ... -delete` starts with
        # "find " too and would otherwise auto-approve itself.
        if looks_read_only and not has_destructive_find:
            print(f"[auto-approved] run_bash({cmd!r})")
            return True, ""

    print(f"\n[proposed] {tool_name}({json.dumps(args)})")
    answer = input("approve? [y/N] ").strip().lower()
    if answer == "y":
        return True, ""
    return False, "rejected by user"


def run_agent(prompt: str, max_turns: int = 10) -> None:
    messages: list[dict] = [{"role": "user", "content": prompt}]

    for turn in range(max_turns):
        response = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=4096,
            system=SYSTEM,
            tools=TOOLS,
            messages=messages,
        )
        messages.append({"role": "assistant", "content": response.content})

        if response.stop_reason == "end_turn":
            for block in response.content:
                if block.type == "text":
                    print(f"\n[final]\n{block.text}")
            return

        if response.stop_reason == "tool_use":
            tool_results = []
            for block in response.content:
                if block.type == "tool_use":
                    approved, reason = gate(block.name, block.input)
                    if approved:
                        output = TOOL_FNS[block.name](**block.input)
                        preview = output[:200] + ("…" if len(output) > 200 else "")
                        print(f"[turn {turn}] tool_result {preview!r}")
                        tool_results.append(
                            {
                                "type": "tool_result",
                                "tool_use_id": block.id,
                                "content": output,
                            }
                        )
                    else:
                        print(f"[turn {turn}] rejected: {reason}")
                        tool_results.append(
                            {
                                "type": "tool_result",
                                "tool_use_id": block.id,
                                "content": reason,
                                "is_error": True,
                            }
                        )
            messages.append({"role": "user", "content": tool_results})
            continue

        print(f"[unexpected stop_reason] {response.stop_reason}")
        return

    print(f"[max_turns={max_turns} reached without end_turn]")


if __name__ == "__main__":
    prompt = sys.argv[1] if len(sys.argv) > 1 else "delete all .tmp files under /tmp"
    run_agent(prompt)
