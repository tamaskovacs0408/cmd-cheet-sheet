# 9. Human-in-the-Loop

The loop in [topic 07](../07-agent-loop/) executes every `tool_use` the model emits. No gate, no confirmation, no policy. That is fine for `run_bash("ls /tmp")`. It is terrifying for `run_bash("rm -rf ~")`.

A human-in-the-loop (HITL) agent inserts a **permission gate** between the model's `tool_use` and the application's `execute`. The model still decides *what* to do. The human (or a policy) decides whether to let it happen.

```
model → tool_use → [ GATE ] → execute → tool_result → model
```

The gate has three jobs:

1. **Decide** whether to allow the call.
2. **Return a result** to the model: either the real tool output on approval, or a synthetic `tool_result` describing the rejection so the loop continues cleanly.
3. **Never block the loop forever** without a reason the user understands.

That is all. Everything below is variations on this one pattern.

## Demo

```sh
uv run python agent.py "delete all .tmp files under /tmp"
```

The script is [`agent.py`](./agent.py) from [topic 07](../07-agent-loop/) with a gate added. Before every `run_bash` call it prints the proposed command and asks for `y/n`:

```
[turn 0] proposed run_bash({"command": "find /tmp -name '*.tmp' -delete"})
[approve? y/n] y
[turn 0] tool_result 'exit_code: 0\nstdout:\n\nstderr:\n'

[final]
Done. Removed all .tmp files under /tmp.
```

On rejection the tool is not executed and the model receives a synthetic `tool_result` like `rejected by user`. It can try again with different arguments or give up.

> **Heads up, macOS users.** If you run the demo and the agent reports success while the `.tmp` file is still sitting in `/tmp`, you have hit a classic BSD `find` + symlink gotcha, not a bug in the gate. [Topic 08](../08-agent-control-flow/) covers this failure class ("Silent success, wrong answer") and what to do about it.

## Three gate policies

Ask-every-time is useful for a demo. Real agents layer policies.

### 1. Ask every time

Every tool call prompts. Safe, slow, exhausting. The demo uses this.

```python
def gate(tool_name: str, args: dict) -> bool:
    print(f"proposed {tool_name}({args})")
    return input("approve? y/n ").strip().lower() == "y"
```

### 2. Allowlist / denylist

Auto-approve read-only tools, always gate destructive ones.

```python
READ_ONLY = {"read_file", "list_dir", "glob", "grep"}

def gate(tool_name: str, args: dict) -> bool:
    if tool_name in READ_ONLY:
        return True
    return ask_user(tool_name, args)
```

This is the model most CLI coding agents use by default. Claude Code ships with `--permission-mode` flags that wire up allowlists for exactly this reason.

### 3. Blast-radius gating

The expensive version: decide per call, based on the arguments and the cost of being wrong.

```python
def gate(tool_name: str, args: dict) -> bool:
    if tool_name == "run_bash":
        cmd = args["command"]
        if any(bad in cmd for bad in ["rm ", "DROP ", "--force", "> /", "| sudo "]):
            return ask_user(tool_name, args)  # destructive: confirm
        return True                           # read-ish: auto
    ...
```

Same shape, more intelligence in the `if`. In production this often becomes a small rule engine or an LLM-as-judge call ("is this command destructive?").

## Rejection as a first-class tool result

When the gate denies a call, you have a choice:

- **Return a synthetic `tool_result`** with `is_error: true` and a short message ("rejected by user: command would delete production data"). The model reads it, reasons, and usually tries a safer approach or asks the user for guidance.
- **Abort the loop.** Cleaner when the user has said "stop," but wasteful otherwise.

Prefer the first. It preserves the loop semantics and lets the agent recover.

```python
if not gate(tool_use.name, tool_use.input):
    tool_results.append({
        "type": "tool_result",
        "tool_use_id": tool_use.id,
        "content": "rejected by user",
        "is_error": True,
    })
    continue  # back to the loop; model will see the rejection and adapt
```

## Why this matters

- **Safety.** The gate is the boundary between a helpful agent and a dangerous one. Every other safety layer (sandboxing, credential scoping, network policy) is defense-in-depth *around* this gate.
- **Trust.** Users tolerate more autonomy once they have seen the gate work a few times. Claude Code's "trust this folder" prompt is a literal version of this.
- **Production parity.** The demo prompts a human on a terminal. Production pipelines replace the human with a Slack approval, a GitHub review, or a policy engine. The loop code does not change. Only the `gate()` function does.
- **Auditability.** Every gated decision is a log line. This is what lets you answer "why did the agent do that?" weeks later.

The pattern you wrote here is the same one Claude Code, Cursor, and every serious coding agent implement. You will recognize it in the traces in [topic 11](../11-observability/) and in Claude Code's permission prompts in [topic 12](../12-real-coding-agents/).

Before that, [topic 10](../10-frameworks/) takes the same agent and hides the loop inside pydantic-ai, so you can see what a framework buys you (and what it costs in visibility).

## Resources

- [Claude Code: permission modes](https://docs.claude.com/en/docs/claude-code/iam): `--permission-mode`, allowlists, the `default`/`acceptEdits`/`plan`/`bypassPermissions` modes
- [Anthropic: Building effective agents](https://www.anthropic.com/research/building-effective-agents): design patterns including HITL
- [OpenAI Agents SDK: human-in-the-loop](https://openai.github.io/openai-agents-python/): framework-level approval hooks
