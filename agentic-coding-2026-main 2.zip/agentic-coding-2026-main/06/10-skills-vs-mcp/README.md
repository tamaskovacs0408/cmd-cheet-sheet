# 10. Skills vs MCP

A skill (lecture 5) is a markdown procedure with an activation rule. Loaded into the agent's context when its description matches the prompt.

An MCP server (this lecture) is an external process that exposes tools, resources, or prompts over JSON-RPC. Queried by the host across a process boundary.

Both are units of *the agent gets a new capability without writing per-host code*. That superficial similarity is where confusion starts. Walking out of lecture 5, it is easy to summarise skills as "MCPs without the server" and assume the choice is just a deployment question.

It is not. Skills and MCP overlap nowhere in what they actually do. They answer different questions, live on different sides of the process boundary, and fail in different directions.

The interesting question on every team that adopts both is *which one a given workflow belongs in*. This topic gives you a four-dimension rubric.

## The rubric

Four dimensions. Walk them in order. See which side wins. If both sides win on different dimensions, you probably want both.

| Dimension | Skill | MCP | Decision rule |
|---|---|---|---|
| Invocation | Model recognises a procedure-shaped prompt | Model calls a tool, host attaches a resource, user fires a prompt | Procedural recognition: skill. Discrete capability: MCP. |
| State | Stateless. Lives in markdown + agent's normal tools | Stateful server process. Can hold connections, cache, share | Persistent/shared state: MCP. Stateless guidance: skill. |
| Trust | In-process. Inherits agent's permissions | Foreign process. Needs the trust framework from topic 9 | In-process is enough: skill. Crossing a process boundary anyway: MCP. |
| Audience | One developer ports the file across hosts | One server serves the team across hosts | Personal procedural knowledge: skill. Shared infrastructure: MCP. |

### Invocation

A skill activates when the model recognises that the current prompt matches the skill's description. The prompt says "bootstrap a new project" or "write the PR description". The model decides the situation looks like one of the skill's situations. The skill body loads as a tool result. The procedure runs in the conversation.

The trigger is *procedural recognition*: pattern-matching across the prompt, the conversation, and the skill descriptions the model saw at startup.

MCP has three invocation models, none of which is procedural recognition:

- A *tool* fires when the model decides to call it. Same loop position as a skill, but the trigger is a discrete capability with a name (`create_pull_request`, `query_warehouse`).
- A *resource* fires when the host attaches it. The user `@`-mentions a `notes://` URI, or the host pulls it in automatically.
- A *prompt* fires when the user invokes a slash command like `/summarise_notes`.

The decision lever: does the trigger come from procedural recognition (skill) or from a discrete action with a name (MCP)? If you cannot point to a single concrete capability you would name, you are probably looking at a skill.

### State

A skill is stateless. The skill body is markdown the agent reads into context. Whatever state the procedure operates on lives in files the agent reads and writes via existing tools, in the conversation, or in the user's environment. Across sessions the skill remembers nothing.

That is fine when the work is "follow this procedure on whatever the user is currently doing". It falls apart when the work needs anything to persist beyond the session, or to be visible to anyone other than the agent that just ran it.

An MCP server is a process. It can hold a database connection pool, cache results between calls, manage long-running side effects, or maintain server-side state that outlives any agent session. Multiple agents can connect to the same server and see the same state. A shared notes store. A shared project tracker. A shared queue.

That shared-state property is qualitative, not just convenient. A skill cannot give two agents a consistent view of the same data, no matter how cleverly written. The skill has no shared place to put the data.

The decision lever: does the capability genuinely need persistent or shared state? Or just procedural guidance applied to whatever is in front of the model?

### Trust

A skill stays in-process. The skill body is markdown. Any tools the procedure calls (Write, Edit, Bash, Read) are the agent's existing tools, governed by the agent's existing permission rules. No new code path. No new binary. No new network endpoint.

If you trusted the agent before installing the skill, the trust posture does not change. The lethal-trifecta analysis from [topic 9](../09-permissions-and-trust/) does not get harder.

An MCP server crosses a process boundary into foreign code. Lecture 5 did not have to deal with this. This lecture spent a whole topic on it.

Every MCP you install is a new actor with its own tools, its own descriptions (untrusted strings the model will read), and (for remote servers) its own network reach. Each one expands the trust surface. Combinations of them can land you in the lethal trifecta even when each one looks fine alone.

The decision lever: can you afford to treat this as foreign code? Or does it need to inherit the agent's existing in-process trust? If a markdown procedure is enough, you avoid an entire class of question.

### Audience

A skill is portable as a markdown file. Each agent that imports it gets its own copy. Updates propagate by re-importing or by committing the file.

That is the right shape for procedural knowledge that one developer wants to carry across hosts. Your `bootstrap-project` skill follows you into Claude Code, OpenCode, Cursor, and Codex without modification. A teammate who wants the same procedure copies the file.

The skill is *personal* in the sense that each user has their own working copy.

An MCP server is portable as a wire endpoint. One process serves many agents, possibly many users, possibly across teams. That is the right shape for *infrastructure*. A shared notes store. A team's GitHub integration. A vendor's hosted Linear server. One operational thing to deploy, monitor, update. The agents are clients of it.

The decision lever: is this *procedural knowledge* one developer should learn, or *infrastructure* a team should operate? Procedural knowledge wants to be copied. Infrastructure wants to be shared.

## Worked example: `bootstrap-project` vs `notes`

Walk both through the rubric.

### Why `bootstrap-project` is a skill

- **Trigger**: "user wants to start a new project". Procedural recognition. Not a discrete named capability.
- **State**: none. Each invocation creates files in the current directory. State lives in the filesystem the agent already touches.
- **Trust**: in-process. The skill body says "write README.md, write .gitignore, run `git init`". Calls to existing Write and Bash tools.
- **Audience**: one developer's preferred way to bootstrap. Different developers have different conventions.

If you tried to make `bootstrap-project` an MCP server, you would expose tools like `create_readme`, `create_gitignore`, `init_git_repo`. None need a server process. None benefit from being shared. All duplicate the agent's existing file-writing capability with a foreign process boundary added for no gain.

You would have moved a markdown file's worth of work across a process boundary and inherited every problem from topic 9 in exchange for nothing.

### Why `notes` is an MCP

- **Capabilities**: discrete and named. `create_note`, `list_notes`, `notes://list`, `/summarise_notes`. Each a distinct action surface.
- **State**: real. In-memory in the demo. Persistent in any version a team would actually run. Survives any agent session.
- **Trust boundary**: genuine. The server runs separately. Other agents can connect to the same notes store and see the same data.
- **Audience**: multiple agents, possibly multiple users, sharing one data set.

If you tried to make `notes` a skill, you would write a markdown body that says "use the Write tool to append to `~/.notes/`". It would technically work for a single user on a single machine. It would not scale to a team. It would not give other agents access to the same data. It would fall apart the moment anyone ran the agent from a different directory.

The MCP version trades a process boundary for actual state that actual users can share.

## The "both" pattern

Some workflows want both: an MCP that exposes a capability, *plus* a skill that tells the agent *when and how* to reach for it.

The textbook example: the `pr-description` skill ([lecture 5 topic 10](../../05/10-build-your-own/)) paired with a GitHub MCP ([topic 7](../07-remote-and-oauth/)).

The skill carries the team's voice and procedural conventions: summary first, test plan as a markdown checklist, risk callouts at the bottom. The MCP carries the API call: open the PR.

Without the skill, the model would freelance the description format. Invent a structure. Skip the checklist. Run `gh pr create` automatically.

Without the MCP, the model could not actually open the PR. It could only print the description for the user to copy.

Together they cover both halves: *what to write* (skill) and *how to ship it* (MCP). The skill is procedural recognition. The MCP is a discrete capability. The workflow needs both.

> Skills tell the model *what to do*. MCPs let the model *do things outside the agent process*. Some workflows need only one. The interesting ones need both.

## A decision tree

For a given workflow, ask in order:

1. Does it need persistent or shared state? → MCP.
2. Does it need network access, an API token, or a connection? → MCP.
3. Does it need to be available to multiple agents or team members at once? → MCP.
4. Otherwise, is it procedural knowledge: *how* to do something the agent already can? → skill.
5. Are you describing both *the capability* and *how it should be applied*? → both.

The dominant failure mode for teams new to both formats is over-using MCP for what should be a skill. A long markdown procedure feels less "real" than a server, so engineers build a server. The result is a process boundary that adds no capability. Only friction. Only one more thing to deploy. Only one more entry on the trust surface from topic 9.

If the answer to questions 1 through 3 is *no*, you do not need a server. Adding one will hurt.

The opposite failure mode (skill where you should have an MCP) is rarer because it is self-correcting. The skill cannot reach the database. The user notices on the first invocation. The team builds an MCP.

Over-MCPing is the silent failure. Under-MCPing fixes itself.

## Why this matters

- The format you reach for shapes the architecture. Default to "make it an MCP" and you end up with process boundaries everywhere. Default to "make it a skill" and you end up with skills that try to reach the network and fail.
- The rubric collapses the question to four dimensions. Walk them. The answer falls out.
- "Both" is the production pattern. A team's `pr-description` skill plus a GitHub MCP is the textbook combination.
- Lecture 5 made you fluent in skills. This lecture made you fluent in MCP. The hard part now is choosing per-workflow.

## Resources

- [Lecture 5: Agent Skills](../../05/): the procedural-knowledge unit
- [Lecture 5 topic 2: What is a skill?](../../05/02-agent-skills/): the `bootstrap-project` running example
- [Lecture 5 topic 10: Build your own skill](../../05/10-build-your-own/): the `pr-description` worked example
- [Topic 4: The SDK](../04-sdk/): the `notes` MCP server
- [Topic 7: Going remote: transports and OAuth](../07-remote-and-oauth/): the GitHub MCP referenced in the "both" pattern
- [Armin Ronacher: Skills vs Dynamic MCP Loadouts](https://lucumr.pocoo.org/2025/12/13/skills-vs-mcp/): adjacent commentary
