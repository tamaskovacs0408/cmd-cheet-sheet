# 5. Server features

Topic 4 stopped at one primitive: tools. The model called them, the host shuttled the call across the process boundary. That covers a lot of ground, but not everything an MCP server has on offer.

This topic walks through the rest of the server side. Two more primitives that complete the invocation matrix (resources and prompts), plus three secondary features the spec defines (logging, elicitation, completions) that fill in the communication paths the primitives leave open.

The split is not arbitrary. Tools, resources, and prompts each pick a different *invoker*: the model, the host, the user. The secondary features pick different *initiators* of out-of-band traffic: the server emitting events the host did not ask for, or the server interrupting the user mid-flight.

## Resources

Tools are model-invoked. Resources are different: the model never decides to read a resource. The host does. Often because the user asked.

When a user @-mentions `notes://list` in Claude Code, the host calls `resources/read` and injects the result into the conversation. The model finds that data already present when it starts reasoning. No tool call. No model decision. The host assembled the context and handed it over.

The resource primitive makes that pattern a first-class part of the protocol.

`server.py` exposes two:

- `notes://list` is a *static resource*. The URI is fixed. It appears in `resources/list`.
- `notes://{note_id}` is a *resource template*. The `{note_id}` placeholder becomes a function parameter by name match. Templates appear in `resources/templates/list`, not in `resources/list`. They represent a family of addressable resources: one URI pattern that covers every note id.

### resources/list

From the repo root:

```bash
INIT='{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"test","version":"1"}}}'
INIT_NOTIF='{"jsonrpc":"2.0","method":"notifications/initialized"}'
LIST_RESOURCES='{"jsonrpc":"2.0","id":2,"method":"resources/list"}'
{ echo "$INIT"; echo "$INIT_NOTIF"; echo "$LIST_RESOURCES"; sleep 1; } \
  | uv run --directory 06 python notes_server/server.py 2>/dev/null
```

The response carries a `resources` array. Each entry has `uri`, `name`, `description`, and optionally `mimeType`. FastMCP fills `description` from the docstring and `name` from the function name. The `mimeType` defaults to `text/plain` when the function returns `str`. A function returning `bytes` would produce `application/octet-stream`.

The template `notes://{note_id}` is absent from this response: templates and static resources are returned by separate endpoints (`resources/templates/list` returns templates).

### resources/read

```bash
READ_LIST='{"jsonrpc":"2.0","id":4,"method":"resources/read","params":{"uri":"notes://list"}}'
{ echo "$INIT"; echo "$INIT_NOTIF"; echo "$READ_LIST"; sleep 1; } \
  | uv run --directory 06 python notes_server/server.py 2>/dev/null
```

The response is a `contents` array. Each item has `uri` (echoing the request), optional `mimeType`, and either `text` or `blob`. Text resources carry `text`; binary resources carry `blob`, a base64-encoded string, with a `mimeType` like `image/png` or `application/pdf`. The protocol knows about binary from the start. Text is just the common case.

### Tool vs resource

| Aspect | Tool | Resource |
|---|---|---|
| Who invokes | Model | Host (often via user @-mention) |
| Visibility to user | Hidden (they see the result) | Visible (often as a chip or attachment) |
| Side effects | Allowed | Should be read-only |
| When loaded | At call-time, on demand | At context-assembly time, before the model turn |
| URI? | No | Yes (`scheme://path`) |

The line is *who pulls the trigger*. Not what the operation does. `list_notes` (the tool) and `all_notes_resource` (the resource) return the same data. The difference is who decides when to read it.

> Tools answer *"do this for me."* Resources answer *"read this for me."* The line is who pulls the trigger, not what the operation does.

## Prompts

Prompts are the third invocation model. They are *user-invoked*, surfaced as slash commands.

When you type `/summarise_notes` in a host's command palette, the host issues `prompts/get` to the server, receives a pre-built message, and injects it into the conversation as if you had typed it yourself. The model never decides to fire a prompt. It receives the resulting message and responds.

That is what makes prompts a distinct primitive: a different decision-maker, a different UI affordance, a different lifecycle from tools and resources.

`server.py` exposes one: `summarise_notes`. The function's return value becomes a user message. Function parameters become slash-command arguments.

### prompts/list and prompts/get

```bash
LIST_PROMPTS='{"jsonrpc":"2.0","id":2,"method":"prompts/list"}'
GET_PROMPT='{"jsonrpc":"2.0","id":3,"method":"prompts/get","params":{"name":"summarise_notes","arguments":{"audience":"engineering"}}}'
{ echo "$INIT"; echo "$INIT_NOTIF"; echo "$LIST_PROMPTS"; echo "$GET_PROMPT"; sleep 1; } \
  | uv run --directory 06 python notes_server/server.py 2>/dev/null
```

`prompts/list` returns a `prompts` array. Each entry has `name`, `description`, and `arguments`. The arguments array contains `{name, description, required}` objects. A parameter with a default value (here `audience = "the team"`) appears with `"required": false`.

`prompts/get` returns a `messages` array. One or more chat messages the host injects into the conversation. Each message has `role` (usually `"user"`) and `content` (a text block, or a richer block for images or embedded resources). FastMCP's string-returning prompts produce a single user message with `"type": "text"`.

## Three primitives, three invocation models

| Primitive | Invoker | Where it shows up | Side effects | Example |
|---|---|---|---|---|
| Tool | Model | Hidden, user sees the result | Allowed | `create_note` |
| Resource | Host (typically via user @-mention) | Attached file or chip in the conversation | Should be read-only | `notes://list` |
| Prompt | User | Slash-command palette | None, produces a message | `/summarise_notes` |

The columns are not arbitrary. Each primitive picks out a different decision-maker, a different UI affordance, a different lifecycle.

Why three primitives instead of one? Workflows decompose differently:

- Some are model-driven exploration.
- Some are user-curated context loading.
- Some are user-initiated boilerplate.

One primitive handling all three would either over-expose internals to the model (tools-as-resources) or under-expose UI affordances to the user (everything-as-tools).

> Tools are reasoning. Resources are context. Prompts are templates. The host gives each one a different door to the conversation.

## Beyond the three primitives

Three more server-side features fill out communication paths the primitives leave open. None are obscure. All are absent from most coding-agent servers in the wild.

### Logging

Servers can emit structured log notifications via `notifications/message`. The host sets verbosity with `logging/setLevel` (debug / info / warn / error).

`server.py` logs every note creation. The notification carries `level`, optional `logger` (a nameable subsystem), and `data` (an arbitrary JSON value). The host can filter by subsystem and level rather than grepping unstructured text.

Trigger one from the wire by calling `tools/call create_note` after `logging/setLevel`:

```bash
SET_LEVEL='{"jsonrpc":"2.0","id":2,"method":"logging/setLevel","params":{"level":"info"}}'
CALL_CREATE='{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"create_note","arguments":{"title":"hi","body":"there"}}}'
{ echo "$INIT"; echo "$INIT_NOTIF"; echo "$SET_LEVEL"; echo "$CALL_CREATE"; sleep 1; } \
  | uv run --directory 06 python notes_server/server.py 2>/dev/null
```

Two distinct messages come back: a `notifications/message` with the log payload, and the `tools/call` result with the new note id.

Compare to the stderr convention from topic 2: stderr works for stdio during development. It does not work for remote servers. It gives the host no structured data to display. Logging primitives are the upgrade path for servers that move from local stdio to production remote.

For long-running or background servers (a file indexer, a database watcher, a sync process), structured logging is how diagnostic output reaches the user without polluting stderr.

### Elicitation

Elicitation (`elicitation/create`) is how a server prompts the user for input mid-flight.

The server emits a request carrying a JSON Schema describing the form: free-text string, enumerated choice, boolean confirmation. The host renders the schema as a UI prompt. The user fills it in. The answer goes back to the server.

This is how a server does interactive forms without a custom front-end and without front-loading every argument in the initial tool call.

This topic adds a third tool to `server.py`, `delete_note`, to demonstrate elicitation. Before deleting, the server fires an elicitation with a `confirm: bool` schema and a message naming the note. If the user accepts and confirms, the note is removed. Otherwise the deletion is cancelled and nothing changes. No bespoke UI, no extra round-trip through the conversation.

Elicitation cannot be exercised from the bash invocations above: it requires a real interactive client to render the prompt and send back a response. Try it from the host (next section).

The same shape covers richer cases: a deploy server about to push to production can elicit *"Type the environment name to confirm,"* validate the response, and proceed only on a match.

Elicitation was added in 2025. Host support is patchy. Most coding-agent servers either do not need mid-flight interaction or handle it via initial-call arguments. Worth knowing about. Not worth building critical workflows around yet.

### Completions

Completions (`completion/complete`) is autocomplete for slash-command arguments and resource URI variables.

When a user types a prompt argument or fills in a resource URI template, the host can ask the server what values make sense. The host sends the argument name and the partial string. The server returns candidate values with an optional `hasMore` flag.

Example: a `summarise_notes` prompt with an `audience` argument autocompletes to known team names. Same applies to URI templates: a server exposing `notes://{note_id}` can return known note IDs.

Adoption is rare. The plumbing exists in the spec and SDKs. The host-side UX is mostly absent.

## Trying it in Claude Code

From `06/05-server/`:

- Start a Claude Code session and ask: *"create a note titled hi with body there"*. The model calls `create_note` and the OTel trace shows the `notifications/message` log notification firing alongside the result.
- Ask: *"read @notes://list and tell me how many notes I have"*. Claude Code surfaces `@notes://list` as an attached resource, calls `resources/read` on the `notes` server, injects the result into context, and answers from it. No `list_notes` tool call.
- Ask the agent to delete the note you just created. The model calls `delete_note`, which fires an elicitation. Claude Code renders a confirmation prompt. Approve it; the deletion completes. Decline it once and watch the tool return `deletion cancelled`.
- Run `/notes:summarise_notes audience=engineering`. The host surfaces `summarise_notes` as a slash command in the picker. Claude Code namespaces MCP slash commands as `<server>:<prompt>`.

## Why this matters

- The model never decides to read a resource. That is the host's (often the user's) job.
- Resource templates with URI variables let one decorator handle a family of resources.
- Three primitives map to three invocation models. When designing a server, ask: who decides this should run? Model: tool. User attaching context: resource. User triggering boilerplate: prompt.
- Prompts let you ship boilerplate as a server feature. A `pr-description` prompt is not the same shape as a `pr-description` skill (lecture 5). The prompt is invoked by the user via slash command and runs in *one* model turn. The skill is procedural knowledge that the model uses across many turns.
- Logging, elicitation, and completions exist. Most coding-agent workflows do not need them today. When a server's docs mention them, you know which side of the wire they live on.
- Slash-command namespacing differs by host. Claude Code prefixes with the server name. OpenCode does the same. Codex's prompts surface differently. Covered in [topic 8](../08-cross-agent/).

## Resources

- [MCP specification, server features](https://modelcontextprotocol.io/specification/server): index of all server-side primitives
- [MCP specification, resources](https://modelcontextprotocol.io/specification/server/resources)
- [MCP specification, prompts](https://modelcontextprotocol.io/specification/server/prompts)
- [MCP specification, elicitation](https://modelcontextprotocol.io/specification/server/elicitation)
- [Topic 3: Tools](../03-tools/): the contrast point
- [Topic 6: Client features](../06-client/): sampling and roots, the other side of the wire
- [Topic 10: Skills vs MCP](../10-skills-vs-mcp/): when a workflow belongs in a skill vs a prompt
