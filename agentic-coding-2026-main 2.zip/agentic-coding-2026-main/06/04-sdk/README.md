# 4. The SDK

Topic 3 ended with a hand-rolled server: JSON-RPC parsing, a dispatch chain, and input schemas written by hand as nested dicts. It works. It also means re-deriving the same plumbing every time you add a tool, with the schema living in two places (the function and the schema dict next to it).

The Python MCP SDK ships a decorator-driven layer called FastMCP that replaces all of that. [Lecture 2 topic 10](../../02/10-frameworks/) warned that frameworks hide the loop. Here the SDK hides the framing and the dispatch, but it emits the same wire format. If you understand the frames from topic 2, you still understand everything that crosses the process boundary.

The SDK is compression, not abstraction.

## What FastMCP replaces

- **The stdio read loop and JSON-RPC framing.** `mcp.run()` handles it.
- **The method dispatch.** The `@mcp.tool()` decorator registers each function under its own name. FastMCP builds the routing.
- **The input schema.** Generated from the function's type annotations. The docstring becomes the tool's `description`. Type hints are mandatory: without them, FastMCP cannot generate the schema.
- **Protocol-level notifications.** Handled internally. Application code never sees them.

## Same frames on the wire

Run `initialize` → `notifications/initialized` → `tools/list` against both servers. From the repo root:

```bash
INIT='{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"test","version":"1"}}}'
INIT_NOTIF='{"jsonrpc":"2.0","method":"notifications/initialized"}'
LIST='{"jsonrpc":"2.0","id":2,"method":"tools/list"}'

{ echo "$INIT"; echo "$INIT_NOTIF"; echo "$LIST"; } | uv run --directory 06 python notes_server/stdio_raw.py
{ echo "$INIT"; echo "$INIT_NOTIF"; echo "$LIST"; } | uv run --directory 06 python notes_server/server.py 2>/dev/null
```

Both responses contain the same `tools` array with `create_note` and `list_notes`. Same `name`, same `description`, same core `inputSchema` shape. Tool names and descriptions came directly from Python identifiers and docstrings. FastMCP read them at decoration time.

Three small differences:

1. FastMCP adds a `title` field to each property and to the schema object. Valid JSON Schema annotations. Most hosts ignore them.
2. FastMCP adds an `outputSchema` describing the return type. The hand-rolled server omits this. The spec does not require it. Current hosts do not validate against it.
3. FastMCP emits compact JSON without spaces after `:` and `,`. Cosmetic only.

The framing is identical.

> The SDK hides the framing, the dispatch, and the schema. It does not hide the protocol.

## Now register and use it

Register both servers as project-scoped from the `04-sdk` directory:

```bash
cd 06/04-sdk
claude mcp add --scope project notes-raw uv -- run --directory .. python notes_server/stdio_raw.py
claude mcp add --scope project notes uv -- run --directory .. python notes_server/server.py
```

Both commands write to `.mcp.json`. Run `claude mcp list` from the same directory: both servers report `✓ Connected`. Claude Code can call tools from either in the same session. Ask Claude to create a note, watch the same `tools/call` frame arrive at either server, and get back the same `content` block.

From this topic on, the lecture uses `server.py`. `stdio_raw.py` stays in the repo as the reference: a hand-rolled implementation you can read end-to-end to verify nothing is hidden. Resources (topic 5) and prompts (topic 6) extend `server.py` with two more decorators.

## Why this matters

- The wire understanding from topic 2 stays. The SDK does not invent a new protocol. It generates the same JSON-RPC.
- Type annotations are how FastMCP knows the input schema. Better types, better tool calls.
- The boundary between FastMCP and your code is small: register tools/resources/prompts with decorators, run the server. Everything else is ordinary Python.
- Inverts [lecture 2 topic 10](../../02/10-frameworks/)'s framing. Lecture 2 warned that an agent framework hides things you should understand. Here, the SDK hides only the parts you would re-derive line-for-line.

## Resources

- [Python MCP SDK / FastMCP](https://github.com/modelcontextprotocol/python-sdk): the SDK used here
- [FastMCP server tutorial](https://modelcontextprotocol.io/docs/concepts/servers#tutorial-quickstart-with-typescript): the maintained quickstart
- [Lecture 2 topic 10: Frameworks](../../02/10-frameworks/): the "frameworks hide the loop" framing this topic inverts
- [Topic 2: The wire and the roles](../02-the-wire/): the hand-rolled equivalent
- [Topic 3: Tools](../03-tools/): the JSON-RPC frames the SDK is now generating
