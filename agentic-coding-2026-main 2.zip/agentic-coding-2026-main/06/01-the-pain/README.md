# 1. The pain

After [lecture 5](../../05/) you have a skill format and a context window that no longer drowns in runbooks. What you do not have is a way to reach outside the agent process.

The agent reads your files, runs your shell, calls your local tools. The moment you want it to query Postgres, open a GitHub issue, post to Slack, or look up a Linear ticket, you write integration code.

That code is not hard to write once. The problem is you write it again. Once per capability. Once per editor. Once per agent. Once per team.

## The integration cost

A bespoke integration has a recognisable shape: a function the agent invokes, wrapped in a `tool_use` JSON Schema with name, arguments, and return type.

At minimum you write:

- Auth handling (API keys, OAuth tokens, service accounts)
- Error handling (rate limits, retries, upstream failures)
- Schema design (what to expose from a 40-field API response)
- The undocumented quirks of the API

A GitHub integration that searches issues, creates PRs, and adds comments takes two to four days of careful work.

Maintenance costs more. The upstream API changes; your schema drifts. The auth token format changes; your refresh logic breaks. The service adds pagination in a new header; your paging loop silently drops records.

You did not write a one-time adapter. You took on an ongoing dependency.

That cost is bearable once. The second dimension is what hurts.

## The cross-agent multiplier

The integration you wrote for Claude Code does not work in OpenCode. The schema you wrote for OpenCode does not work in Cursor. The wrapper you wrote for Cursor does not work in Codex.

Each host has its own tool invocation model, its own transport, its own way of describing capabilities. You end up writing the same Postgres adapter three times, for three calling conventions, with three error surfaces.

> You are not paying the integration cost once. You are paying it N × M times: one per capability, one per host. None of those integrations share a wire format.

The cost is multiplicative. Five capabilities and three editors: fifteen integrations. Ten capabilities and five editors: fifty. Most of them are structurally identical. They differ only because the hosts never agreed on how capability exposure should work.

## What you want instead

Write the capability once. Any host that speaks the protocol uses it without modification. No host-specific code. No new adapter per editor. One unit, one description, one transport.

That unit needs to expose more than a single function. It has to describe what it can do, in a form the model can reason about and the host can present without bespoke scaffolding.

There are three kinds of things an agent might want from an external system:

- Actions to take
- Data to read
- Canned interaction patterns to start from

Each maps to a different primitive. [Topic 5](../05-server/) names all three.

The protocol that makes this possible is called Model Context Protocol (MCP). [Topic 2](../02-the-wire/) starts with a hand-rolled server you can read in under a minute.

## Where this came from

MCP launched in November 2024. Skills did not exist yet. Lazy procedural context was not a recognised pattern. The pain agents faced was more basic.

Three forces converged.

**Agents needed extension points.** Not just coding agents. Any AI agent built on tool use ran into the same wall: the model could reason, but it could not reach. Function calling existed per vendor (OpenAI tools, Anthropic tool use), but those specs only described how a single model invokes a tool the host already wired up. They said nothing about how a third party exposes a capability across vendors.

**Hallucination was worse.** Frontier models in 2024 invented API responses, fabricated field names, made up SQL results. The workaround was lengthy prompting: spell out the schema, the constraints, the format, the edge cases. A reliable Postgres query required a thousand-token preamble. The same query as a deterministic tool call required a name and an argument list. Tool use turned probabilistic reasoning into deterministic execution wherever the work was already codable.

**The integrator side had no answer either.** Agent vendors could ship a few first-party integrations. They could not ship the long tail. Linear, Sentry, GitHub, Notion, Stripe, Cloudflare each wanted their product reachable from every agent. Without a protocol, they faced the same N × M problem from the other direction: implement once per agent vendor, or do nothing. Today most of these companies maintain their own MCP server. The agent vendor never sees the integration code.

The shape of the problem was familiar. Editors hit it a decade earlier with language tooling and solved it with the Language Server Protocol: one protocol, every editor speaks it, every language ships one server. The N × M cost collapsed to N + M.

MCP applies the same move to agents. The host implements the client side once. The capability provider implements the server side once. Any host plus any server plus any model that does tool calls equals a working integration.

## Why this matters

Lecture 5's pain was eager procedural context. The fix was lazy-loaded skills.

The pain here is one layer below: even with perfect procedural knowledge, the agent has no reach beyond its own process. Lazy skills fix the context problem. They do not fix the capability problem.

The portability story in lecture 5 was partial. A skill file is portable if the host implements the format, but the tools a skill calls are still bespoke per host. MCP gets to full portability via a wire format: speak the protocol, use the server, regardless of the host.

Topics 2 through 10 each address one facet:

- Topics 2-4: the wire and roles, tools, and the SDK (the core)
- Topics 5-6: server features and client features (the rest of the protocol surface)
- Topics 7-9: remote transports and OAuth, the cross-agent landscape, and the trust surface
- Topic 10: skill vs MCP vs both

## Resources

- [Anthropic: Introducing the Model Context Protocol](https://www.anthropic.com/news/model-context-protocol): the original launch post
- [MCP docs: Why does MCP matter](https://modelcontextprotocol.io/docs/getting-started/intro#why-does-mcp-matter): the official framing of the same problem
- [Microsoft: Language Server Protocol](https://microsoft.github.io/language-server-protocol/): the N × M → N + M precedent MCP inherits from
- [Lecture 5: Agent Skills](../../05/): the lazy *procedural* unit; this topic motivates the lazy *capability* unit
- [Lecture 4: Context Engineering](../../04/): the eager-vs-lazy framing this topic inherits
