# Lecture 6: MCP, Capability Layer and External Integration

## Overview

Your terminal agent can read files, run shell commands, and call your local Python. That is it. The moment you want it to query your warehouse, open a GitHub PR, or notify the on-call channel, you write integration code. Then you write it again, slightly differently, when you switch editors.

This lecture answers one question: how do you give an agent a new capability without rewriting the integration for every host?

The answer is a small JSON-RPC protocol called Model Context Protocol (MCP). The lecture starts with a hand-rolled `notes` server you can read end-to-end. It then names the host, client, and server roles by pointing at real processes. It walks through tools, resources, and prompts as three primitives. From there it covers remote transports, OAuth, the cross-agent landscape, and the trust questions that come with letting external code into the loop.

Lecture 5 made procedural knowledge a lazy unit. This lecture makes external capabilities a portable unit. The closing topics ask: when does a problem belong in a skill, when in an MCP, and when in both?

## Learning Objectives

By the end of this lecture, you will be able to:

- Explain why MCP exists, what gap it closes that lecture 5's skills do not, and what new failure mode it adds
- Read raw MCP JSON-RPC frames and identify host, client, and server in a running session
- Implement a minimal MCP server from scratch over stdio (no SDK), then port it to FastMCP without changing behaviour
- Tell apart tools, resources, and prompts. Pick the right one for a given capability
- Connect Claude Code to a remote MCP server using streamable HTTP and OAuth, and explain each step of the auth dance
- Run the same MCP server unmodified in Claude Code, OpenCode, Codex, and Cursor
- Apply Claude Code's per-server permission model to a tool that should never run without confirmation
- Name the prompt-injection risks every MCP server adds to the trust surface
- Choose between a skill, an MCP server, or both for a given workflow

## Topics

The lecture is built bottom-up. Read in order.

### 1. [The pain](./01-the-pain/)

After lecture 5 you have a skill format and a leaner context window. You still cannot reach outside the agent process. Every team writes the same Postgres, GitHub, and Slack integrations again, and writes them differently for every host.

### 2. [The wire and the roles](./02-the-wire/)

What is on the wire when a host calls an MCP server? When the docs say "host", "client", and "server", which process is which?

### 3. [Tools](./03-tools/)

What does the host send when the model decides to use a tool? How is that the same as the `tool_use` block from lecture 2?

### 4. [The SDK](./04-sdk/)

The hand-rolled server works. How much of it is your tool, and how much is just protocol plumbing? Once the SDK generates the wire frames, are they still the same frames?

### 5. [Server features](./05-server/)

Resources, prompts, and the secondary server-initiated features the spec defines (logging, elicitation, completions). Tools were one primitive. This topic finishes the server side of the wire.

### 6. [Client features](./06-client/)

Sampling and roots: the two features the *client* (the host) advertises. The server reaches up, the host responds. Both absent from most coding-agent hosts today, both worth knowing about.

### 7. [Going remote: transports and OAuth](./07-remote-and-oauth/)

stdio works when the server is your subprocess. For services behind an API and an auth boundary (GitHub, Linear, Notion), the server has to be remote. This topic covers streamable HTTP, the OAuth 2.1 + PKCE dance, and what scopes mean.

### 8. [Cross-agent](./08-cross-agent/)

The `notes_server/server.py` from topic 4 runs unmodified in Claude Code, OpenCode, Codex, and Cursor. No code changes, only a few lines of host-specific config. The protocol converged at the wire level.

### 9. [Permissions and trust](./09-permissions-and-trust/)

Every MCP server adds tools, and strings, to the model's action surface. This topic covers Claude Code's per-tool allow/ask/deny rules, the lethal-trifecta threat model, and the mitigations that keep private data out of untrusted external channels.

### 10. [Skills vs MCP](./10-skills-vs-mcp/)

Skills and MCP look similar. They overlap nowhere. This topic gives a four-dimension rubric (invocation, state, trust, audience), walks `bootstrap-project` and `notes` through it, and shows the production pattern that uses both.

## Further Reading

Cross-cutting references. Topic-specific links live in each topic's own README.

Primary sources:

- [MCP specification](https://modelcontextprotocol.io/specification): the canonical reference
- [Anthropic: Introducing the Model Context Protocol](https://www.anthropic.com/news/model-context-protocol): the original launch post
- [Claude Code MCP docs](https://docs.claude.com/en/docs/claude-code/mcp)
- [MCP Inspector](https://github.com/modelcontextprotocol/inspector): the standard debugging tool
- [`modelcontextprotocol/servers`](https://github.com/modelcontextprotocol/servers): reference server collection
- [`awesome-remote-mcp-servers`](https://github.com/jaw9c/awesome-remote-mcp-servers): community-curated list of hosted remote MCP servers

SDKs:

- [Python SDK / FastMCP](https://github.com/modelcontextprotocol/python-sdk): used in topic 4 and onward
- [TypeScript SDK](https://github.com/modelcontextprotocol/typescript-sdk)
- Go, Rust, Kotlin, Swift, and Java SDKs are listed in the spec repo for reference.

Cross-agent MCP support (the file shape differs per host; the wire is the same):

- [OpenCode MCP](https://opencode.ai/docs/mcp/)
- [OpenAI Codex MCP](https://developers.openai.com/codex/mcp)
- [Cursor MCP](https://cursor.com/docs/context/mcp)
- [Cline MCP](https://docs.cline.bot/mcp)

Commentary worth reading:

- [Armin Ronacher: Skills vs Dynamic MCP Loadouts](https://lucumr.pocoo.org/2025/12/13/skills-vs-mcp/): already cited in lecture 5; reread through this lecture's lens
- [Simon Willison: MCP tag feed](https://simonwillison.net/tags/mcp/): running coverage of the ecosystem
- [Simon Willison: The lethal trifecta](https://simonwillison.net/2025/Jun/16/the-lethal-trifecta/): direct input to topic 9's threat model

Course cross-references:

- [Lecture 2 topic 5: Tool Calling](../02/05-tool-calling/): the model-side primitive MCP wraps
- [Lecture 4: Context Engineering](../04/): the eager-vs-lazy framing inherited
- [Lecture 5: Agent Skills](../05/): the procedural-knowledge unit; topic 10 contrasts the two
