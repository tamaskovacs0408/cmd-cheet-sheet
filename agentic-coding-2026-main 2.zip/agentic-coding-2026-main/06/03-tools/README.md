# 3. Tools

Topic 2 ended with `notes-raw` showing `✗ Failed to connect` in `claude mcp list`. The server returned an error on `notifications/initialized`, so the lifecycle never completed. This topic fixes that and walks through the tool primitive in full.

Tools are the most-used MCP primitive. They are also the bridge back to lecture 2 topic 5: the model's `tool_use` block has not changed at all. What changed is the path between the model's intent and the code that executes it. That path now crosses a process boundary.

## tools/list

`tools/list` asks the server what tools it exposes. From the repo root:

```bash
echo '{"jsonrpc":"2.0","id":2,"method":"tools/list"}' \
  | uv run --directory 06 python notes_server/stdio_raw.py
```

Each tool in the response has three fields:

- `name`: the string the host passes back in `tools/call`. Must be unique within the server.
- `description`: natural language the model reads to decide whether to use the tool. This is the main lever for tool-selection quality. A vague description produces vague calls.
- `inputSchema`: a JSON Schema describing arguments. Same vocabulary as `input_schema` in lecture 2 topic 5.

The host calls `tools/list` during the handshake, caches the result, and presents it to the model as part of the system prompt. The model never sees the JSON-RPC framing. It sees a rendered list of tool names, descriptions, and schemas.

## tools/call

`tools/call` names the tool and passes the arguments the model generated:

```bash
echo '{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"create_note","arguments":{"title":"hello","body":"world"}}}' \
  | uv run --directory 06 python notes_server/stdio_raw.py
```

The response is a `content` array of content blocks. Each block has a `type` (here, `"text"`) and a payload field. The host wraps the content into a `tool_result` and sends it back to the model as the next user turn.

Errors use JSON-RPC's standard codes. `-32602` is the canonical "invalid params" code, used when the host calls a tool the server does not expose.

## The host as translator

Lecture 2 topic 5 showed the model emitting a `tool_use` block and your application running the tool directly. MCP adds a process boundary. The host is no longer the code that runs the tool. It is the code that asks an external process to run it.

| Layer | Lecture 2 topic 5 | This topic |
|---|---|---|
| Model-facing message | `tool_use` block in API response | `tool_use` block in API response (unchanged) |
| Host-side translation | application code calls `run_bash` directly | host issues `tools/call` JSON-RPC to server |
| Server-side dispatch | (no separate process) | dispatch by tool name in the server |
| Result format | `tool_result` block in next API request | `tool_result` block, same shape, content from JSON-RPC response |

The model's side is identical in both cases. When the model emits a `tool_use` block requesting `create_note`, it does not know whether `create_note` is a function in the host process or a method call on a remote server.

The host reads the `tool_use` block, sees that `create_note` came from `notes-raw`, serialises the call as a `tools/call` JSON-RPC request, writes it to the server's stdin, reads the response, extracts the `content` array, and puts it into a `tool_result` for the next API call.

> The model sees the same `tool_use` block whether the tool is built into the host or shuttled in over MCP. The host is the translator.

## Now `claude mcp list` is happy

This topic's directory has its own `.mcp.json`. With the notification handling fixed, the handshake completes and `notes-raw` reports `✓ Connected`.

The sequence:

1. Host spawns the server process.
2. Host sends `initialize`. Server responds.
3. Host sends `notifications/initialized`. No `id`, no response expected.
4. Host calls `tools/list`. Server returns the catalogue.

The bug in topic 2 was a protocol violation: returning a JSON-RPC error to a notification. The client treats that as a handshake failure.

## Why this matters

- The model is unaware whether a tool is built-in or comes from an MCP server. Same JSON Schema, same `tool_use` block, same `tool_result`. The host bridges the difference.
- Schemas are JSON Schema, same vocabulary as lecture 2 topic 5. Better schemas mean better tool calls.
- A single `tools/call` may be one of many in a turn. The model can request multiple tools at once. The host issues each as a separate JSON-RPC call, sometimes in parallel.
- MCP servers do not call models. Translation between `tool_use` and `tools/call` happens only on the host side.

## Resources

- [MCP specification, tools](https://modelcontextprotocol.io/specification/server/tools): formal description of `tools/list` and `tools/call`
- [Lecture 2 topic 5: Tool Calling](../../02/05-tool-calling/): the model-side `tool_use` block this topic translates
- [JSON Schema](https://json-schema.org/): the input schema vocabulary
