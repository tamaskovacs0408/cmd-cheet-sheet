# 8. Cross-agent

[Topic 7](../07-remote-and-oauth/) closed the loop on what it takes to make a server reachable from anywhere: streamable HTTP, OAuth, a token at the wire level. This topic asks: once the server is built, how portable is it?

Lecture 5's portability story was about skills. The `SKILL.md` *file* travelled between agents. Each agent's activation was its own. A Claude Code skill activated through a `Skill` tool call. A Codex skill activated through prompt injection. Same file, different execution path.

MCP's portability story is stronger. The *wire* travels, and there is only one wire.

JSON-RPC over stdio (or streamable HTTP) is what the spec defines. Every MCP-compatible host speaks it. The same `server.py` registers in Claude Code, OpenCode, Codex, and Cursor without a single line changed. What differs is a handful of lines in each host's config file. A cost in minutes, not hours.

The protocol achieved that by being small. It specifies *messages*, not *behaviour*. Every host renders tools its own way, handles confirmation prompts differently, caches `tools/list` on its own schedule. The wire stays identical.

## The same server, four hosts

`notes_server/server.py` from [topic 4](../04-sdk/) is unchanged in this topic. It runs unmodified in Claude Code, OpenCode, Codex, and Cursor. What differs is *how each host registers it*.

### Claude Code

Already covered in [topic 4](../04-sdk/). `.mcp.json` at the project root, written by `claude mcp add --scope project`:

```json
{
  "mcpServers": {
    "notes": {
      "type": "stdio",
      "command": "uv",
      "args": ["run", "--directory", "..", "python", "notes_server/server.py"],
      "env": {}
    }
  }
}
```

### OpenCode

OpenCode reads MCP server config from `opencode.json` (project) or `~/.config/opencode/opencode.json` (user). Same shape, different filename:

```json
{
  "$schema": "https://opencode.ai/config.json",
  "mcp": {
    "notes": {
      "type": "local",
      "command": ["uv", "run", "--directory", "..", "python", "notes_server/server.py"]
    }
  }
}
```

OpenCode calls stdio servers `local` and HTTP servers `remote`. The `command` is a single array (no separate `args` field). The JSON-RPC layer is identical.

<!-- CAPTURE FROM LIVE RUN: paste the output of running `opencode` from `06/08-cross-agent/` with the above config. -->

### Codex (OpenAI)

Codex CLI registers MCP servers in `~/.codex/config.toml` under `[mcp_servers.<name>]`:

```toml
[mcp_servers.notes]
command = "uv"
args = ["run", "--directory", "/home/you/agentic-coding-2026/06", "python", "notes_server/server.py"]
```

Codex requires absolute paths (no working-directory cd into the registration directory like Claude Code). `tools/list` returns the same schema. The host renders tools differently in the UI.

<!-- CAPTURE FROM LIVE RUN: paste `codex` output exercising the same notes server. -->

### Cursor

Cursor reads `~/.cursor/mcp.json` (user) or `.cursor/mcp.json` (project). Same shape as Claude Code's `.mcp.json`:

```json
{
  "mcpServers": {
    "notes": {
      "command": "uv",
      "args": ["run", "--directory", "/home/you/agentic-coding-2026/06", "python", "notes_server/server.py"]
    }
  }
}
```

Cursor surfaces MCP tools through its agent panel, gated by per-server allow/deny rules.

<!-- CAPTURE FROM LIVE RUN: paste a Cursor session showing the same notes server in use. -->

## What converged, what didn't

| | Skills (lecture 5) | MCP (this lecture) |
|---|---|---|
| Unit | `SKILL.md` file | Server process |
| Format that travels | Markdown + YAML frontmatter | JSON-RPC messages |
| Activation | Per-agent. Claude Code uses Skill tool, Codex uses prompt-list, OpenCode uses native tool | Universal. Every host calls `tools/list`, `tools/call`, etc. |
| Discovery path | Per-agent: `~/.claude/skills/`, `~/.config/opencode/skills/`, `~/.codex/skills/` | Per-agent: `.mcp.json`, `opencode.json`, `~/.codex/config.toml`, `.cursor/mcp.json` |
| What you write once | The file body | The server code |
| What you adapt per host | Activation hints, frontmatter dialects | The registration config (a few lines) |

The protocol is universal at the message level. The registration is per-host.

In practice: a skill traveling between agents needs a few lines of activation tuning. An MCP server traveling between agents needs a few lines of config tuning. Both end at the same place: same content, exposed in every editor.

> Skills crossed agent boundaries because the *file* converged. MCP crossed because the *wire* converged. Different mechanisms, same outcome.

## What MCP gave up

Universality has a cost. The protocol specifies *messages*, not *behaviour*. There is no spec for:

- How tools should be rendered to the user (Claude Code shows confirmation prompts, Cursor surfaces them in a side panel, Codex inlines them).
- When to call `tools/list` versus when to cache (each host caches differently).
- How `notifications/tools/list_changed` is propagated (the spec defines the message; not every host listens).
- UX affordances for resources (`@`-mention is a convention, not a requirement).

A server that ships with rich UX assumptions ("the host will show a confirmation prompt before calling this tool") works on Claude Code and breaks on hosts that auto-confirm. Servers should describe capabilities through the protocol's structured fields (tool descriptions, JSON schemas, resource MIME types) and treat host UX as something they cannot rely on.

This is the explicit trade-off. MCP could have specified host behaviour and been less portable, or stayed message-only and been universal. It chose universal.

## Why this matters

- One server, four (or more) hosts. The investment in writing an MCP server is portable in a way no host-specific tool wrapper is.
- The wire converged because the spec is small. Anything more opinionated would have been a harder sell to multiple agent vendors.
- For lecture 5 readers: this is a stronger version of the portability story you saw with skills. The unit of portability got bigger (a server vs. a markdown file). The rendering surface got smaller (the wire vs. the activation).
- When designing an MCP server, prefer protocol-native expressions (descriptions, schemas) over UX assumptions ("the host will…"). Hosts behave differently. The wire does not.

## Resources

- [OpenCode MCP docs](https://opencode.ai/docs/mcp/): `opencode.json` mcp section
- [OpenAI Codex CLI MCP](https://developers.openai.com/codex/mcp): `~/.codex/config.toml` syntax
- [Cursor MCP docs](https://cursor.com/docs/context/mcp): `.cursor/mcp.json` config
- [Claude Code MCP docs](https://docs.claude.com/en/docs/claude-code/mcp): the `.mcp.json` form covered in topic 4
- [Lecture 5 topic 6: Same file, different activation](../../05/06-cross-agent/): the partial-portability counterpart this topic strengthens
- [Topic 4: The SDK](../04-sdk/): the `server.py` that runs unmodified everywhere
