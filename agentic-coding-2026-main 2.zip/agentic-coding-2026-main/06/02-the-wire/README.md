# 2. The wire and the roles

When you run `claude`, three processes exist: the terminal, the client embedded in it, and any server the client spawns. Most people treat the whole thing as one black box. This topic opens the box just far enough to name those three processes and see the bytes that flow between them.

MCP's JSON-RPC messages are not opaque blobs. They are human-readable, one JSON object per line. You can send one by hand with `echo`. That is where we start.

## The smallest possible MCP server

`notes_server` handles three methods (`initialize`, `tools/list`, `tools/call`) and returns a JSON-RPC error for everything else. That is the minimum a host needs to discover and call a tool.

## Reading the wire

Confirm the framing works by talking to the server directly. One JSON object on stdin, one line on stdout.

From the repo root:

```bash
echo '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05"}}' \
  | uv run python notes_server/stdio_raw.py
```

One JSON object goes in. One JSON object comes out: a `result` echoing the protocol version, the server's declared `capabilities`, and a `serverInfo` block with name and version.

## Host, client, server

Register the server as a project-scoped MCP server. From this directory:

```bash
claude mcp add --scope project notes-raw -- uv run --directory .. python notes_server/stdio_raw.py
```

That writes a `.mcp.json` file in the current directory. The file is committed in this repo, but the command is the canonical way to create one.

Verify the server is registered:

```bash
claude mcp list
```

The registration succeeds. The connection does not: `claude mcp list` reports `notes-raw: ... ✗ Failed to connect`. The server returned an error to a JSON-RPC notification, which the client interprets as a handshake failure. [Topic 3](../03-tools/) picks up there.

## The three roles

Now the three roles have processes to point at:

- **Host**: Claude Code itself. The thing the user interacts with. Owns the conversation with the model and decides which tools to offer.
- **Client**: the MCP client logic *inside* the host. Speaks JSON-RPC: spawns the server process, sends `initialize`, calls `tools/list`, dispatches `tools/call`.
- **Server**: the Python process you just started. Reads one JSON object per line on stdin. Routes by method. Writes one JSON object per line on stdout.

```
┌─────────────────────────────────────┐         ┌─────────────────────┐
│ host: claude (your terminal)        │         │ server: python      │
│                                     │  stdin  │   stdio_raw.py      │
│  ┌──────┐         ┌──────────────┐  │ ──────▶ │                     │
│  │ user │ ◀────▶ │ MCP client   │  │         │  notes_server logic │
│  └──────┘         └──────────────┘  │ ◀────── │                     │
│       ▲                             │  stdout │                     │
│       │ Anthropic API               │         │                     │
│       ▼                             │         │                     │
│   (model)                           │         │                     │
└─────────────────────────────────────┘         └─────────────────────┘
```

> The protocol does not name the roles arbitrarily. It names what is already there.

The host existed before MCP. The model API existed before MCP. The application code that bridged them existed too, written by hand for every integration.

MCP names the boundary that was already there and specifies the message format that crosses it.

## Why this matters

- The wire format is JSON-RPC. Same shape as the `tool_use` block from [lecture 2 topic 5](../../02/05-tool-calling/). MCP is the *transport* between them.
- The server is a **separate process**. That isolation makes MCP servers portable. [Topic 8](../08-cross-agent/) takes this same script unmodified to OpenCode, Codex, and Cursor.
- Everything from here on adds primitives, transports, or auth. The protocol's shape (`method`, `params`, `id`, `result`, one JSON object per line) does not change.

## Resources

- [MCP specification, base protocol](https://modelcontextprotocol.io/specification): the JSON-RPC 2.0 envelope used here
- [MCP specification, stdio transport](https://modelcontextprotocol.io/specification/2024-11-05/basic/transports#stdio): the newline framing rule
- [JSON-RPC 2.0 specification](https://www.jsonrpc.org/specification): the underlying RPC convention
- [Lecture 2 topic 5: Tool Calling](../../02/05-tool-calling/): the model-side `tool_use` block
