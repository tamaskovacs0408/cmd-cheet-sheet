# 6. Client features

Topic 5 covered everything the server advertises: tools, resources, prompts, plus the secondary server-initiated features (logging, elicitation, completions). The other half of the protocol is what the *client* (the host) advertises.

Two features here. Both are part of the spec. Both are absent from most coding-agent hosts at the time of writing. Knowing they exist matters because they invert the usual direction of the protocol: the server reaches up toward the client, and the client either responds or refuses.

## Sampling

Sampling (`sampling/createMessage`) inverts the usual direction: a *server* asks the *host* for a model completion. In every other part of the protocol, the host makes requests. Sampling is how a server borrows the host's model for its own reasoning (classification, rewriting, summarisation) without shipping a model of its own.

The request carries a `messages` array (same shape as the Anthropic messages API), an optional `systemPrompt`, and optional preferences like `maxTokens` and `temperature`. The host is not obligated to honour the preferences. It can apply its own policy on cost, context window, and model selection. This is intentional. The host, not the server, controls what model runs and what it costs the user.

Concrete case: a `summarise-pr` server receives a long diff and needs to compress it before formatting. The server does not embed an LLM. It sends `sampling/createMessage` to the host with the raw diff, the host runs the model, and the server formats the completion into its response. The server stays simple; the reasoning lives in the host's model.

Adoption is uneven. Claude Desktop implements `sampling/createMessage`. Several SDK-based hosts do too. Claude Code does not at the time of writing. Worth understanding. Hard to depend on today.

## Roots

Roots (`roots/list`) is how the *host* tells the *server* which directories the user authorised it to operate on. The workspace boundaries.

A filesystem server can refuse paths outside the announced roots. A git server can use them to know which repository the user means when they ask "what changed?". The host pushes the list at session start and re-pushes via `notifications/roots/list_changed` if the user opens or closes a folder. Each root is a URI, typically a `file://` path.

Practical example: a code-search server walks the workspace and returns only files under one of the announced roots. Without roots, the server has to guess, or the user configures the workspace in the server's own config. With roots, the host handles the handoff automatically.

There is a trust angle. A server that refuses to operate outside announced roots is harder to coerce through prompt injection. If a malicious instruction in a file tells the server to read `/etc/passwd`, a roots-checking server can reject the path before reading it. Roots are not a security boundary on their own (a server can choose to ignore them), but they give a conscientious server a clean way to enforce scope.

Adoption is more uniform than sampling. Most file-touching servers in the ecosystem respect roots.

## Why this matters

- MCP is bidirectional. The host calls the server (tools, resources, prompts), and the server calls the host (sampling) or is informed by it (roots). Both sides have features.
- Client features express what the host is willing to do for servers. A host without sampling cannot run servers that depend on it. A host that does not advertise roots forces servers to guess at workspace boundaries.
- The fact that these primitives exist tells you something about the protocol's design intent: MCP is a full bidirectional capability channel, not just a way to expose tools.
- For most teams: do not depend on sampling today. Roots are safer to assume in newer hosts but still verify before shipping.

## Resources

- [MCP specification, sampling](https://modelcontextprotocol.io/specification/client/sampling): server asks host for a model completion
- [MCP specification, roots](https://modelcontextprotocol.io/specification/client/roots): host tells server about workspace
- [Topic 5: Server features](../05-server/): the other side of the wire
- [Topic 9: Permissions and trust](../09-permissions-and-trust/): the trust model that roots and sampling sit inside
