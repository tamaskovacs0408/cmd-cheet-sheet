import json
import sys

NOTES = {}
NEXT_ID = 1


def respond(msg_id, result=None, error=None):
    body = {"jsonrpc": "2.0", "id": msg_id}
    if error is not None:
        body["error"] = error
    else:
        body["result"] = result
    sys.stdout.write(json.dumps(body) + "\n")
    sys.stdout.flush()


def handle(msg):
    method = msg.get("method")
    msg_id = msg.get("id")
    if "id" not in msg:
        # JSON-RPC notification, no response expected.
        return
    if method == "initialize":
        respond(
            msg_id,
            {
                "protocolVersion": "2024-11-05",
                "capabilities": {"tools": {}},
                "serverInfo": {"name": "notes-raw", "version": "0.1"},
            },
        )
    elif method == "tools/list":
        respond(
            msg_id,
            {
                "tools": [
                    {
                        "name": "create_note",
                        "description": "Create a note with a title and body. Returns the note id.",
                        "inputSchema": {
                            "type": "object",
                            "properties": {
                                "title": {"type": "string"},
                                "body": {"type": "string"},
                            },
                            "required": ["title", "body"],
                        },
                    },
                    {
                        "name": "list_notes",
                        "description": "List all notes. Returns the title of every stored note, indexed by id.",
                        "inputSchema": {"type": "object", "properties": {}},
                    },
                ],
            },
        )
    elif method == "tools/call":
        global NEXT_ID
        name = msg["params"]["name"]
        args = msg["params"].get("arguments", {})
        if name == "create_note":
            nid = str(NEXT_ID)
            NEXT_ID += 1
            NOTES[nid] = {"title": args["title"], "body": args["body"]}
            respond(
                msg_id, {"content": [{"type": "text", "text": f"created note {nid}"}]}
            )
        elif name == "list_notes":
            summary = (
                "\n".join(f"{nid}: {n['title']}" for nid, n in NOTES.items())
                or "no notes"
            )
            respond(msg_id, {"content": [{"type": "text", "text": summary}]})
        else:
            respond(msg_id, error={"code": -32602, "message": f"unknown tool: {name}"})
    else:
        respond(
            msg_id, error={"code": -32601, "message": f"method not found: {method}"}
        )


if __name__ == "__main__":
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            handle(json.loads(line))
        except (ValueError, KeyError):
            continue
