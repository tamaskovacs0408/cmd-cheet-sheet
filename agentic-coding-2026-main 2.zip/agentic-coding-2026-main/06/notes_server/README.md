# notes_server

The running example for lecture 6, evolved across topics:

- `stdio_raw.py`: hand-rolled JSON-RPC server (introduced in [topic 2](../02-the-wire/))
- `server.py`: FastMCP rewrite, then extended with resources, prompts, structured logging, and an elicitation-driven `delete_note` (introduced in [topic 4](../04-sdk/) and grown through [topic 5](../05-server/))
