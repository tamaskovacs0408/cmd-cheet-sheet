from mcp.server.fastmcp import Context, FastMCP
from pydantic import BaseModel, Field

mcp = FastMCP("notes")
NOTES: dict[str, dict] = {}
NEXT_ID = 1


class DeleteConfirmation(BaseModel):
    confirm: bool = Field(description="True to confirm deletion, false to cancel.")

@mcp.tool()
async def create_note(title: str, body: str, ctx: Context) -> str:
    """Create a note with a title and body. Returns the note id."""
    global NEXT_ID
    nid = str(NEXT_ID); NEXT_ID += 1
    NOTES[nid] = {"title": title, "body": body}
    await ctx.info(f"created note {nid}", logger_name="notes")
    return f"created note {nid}"

@mcp.tool()
def list_notes() -> str:
    """List all notes. Returns the title of every stored note, indexed by id."""
    return "\n".join(f"{nid}: {n['title']}" for nid, n in NOTES.items()) or "no notes"

@mcp.tool()
async def delete_note(note_id: str, ctx: Context) -> str:
    """Delete a note by id. Asks the user to confirm before deleting."""
    note = NOTES.get(note_id)
    if note is None:
        return f"note {note_id} not found"
    result = await ctx.elicit(
        message=f"Delete note '{note['title']}' (id={note_id})?",
        schema=DeleteConfirmation,
    )
    if result.action != "accept" or not result.data or not result.data.confirm:
        return f"deletion cancelled for note {note_id}"
    del NOTES[note_id]
    await ctx.info(f"deleted note {note_id}", logger_name="notes")
    return f"deleted note {note_id}"

@mcp.resource("notes://list")
def all_notes_resource() -> str:
    """Plain-text listing of every note's id and title."""
    return "\n".join(f"{nid}: {n['title']}" for nid, n in NOTES.items()) or "no notes"

@mcp.resource("notes://{note_id}")
def one_note_resource(note_id: str) -> str:
    """The full title and body of a single note."""
    n = NOTES.get(note_id)
    if n is None:
        return f"note {note_id} not found"
    return f"# {n['title']}\n\n{n['body']}"

@mcp.prompt()
def summarise_notes(audience: str = "the team") -> str:
    """Produce a summary of all stored notes for a given audience."""
    body = "\n\n".join(f"## {n['title']}\n{n['body']}" for n in NOTES.values())
    if not body:
        return "There are no notes to summarise."
    return f"Summarise the following notes for {audience} in three bullets max:\n\n{body}"

if __name__ == "__main__":
    mcp.run()
