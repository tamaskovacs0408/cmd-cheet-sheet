# 7. Going remote: transports and OAuth

Every server in topics 2 through 6 ran as a subprocess of the host. A process you spawned locally, communicating over stdin and stdout. That model works for anything you own: a filesystem tool, a local database, a notes server you wrote.

It cannot work for a service on someone else's machine. Stack Overflow does not let you fork a subprocess of its Q&A index. Linear does not ship a binary you can spawn locally.

If you want an agent that opens pull requests, searches Stack Overflow, or queries your warehouse, the server has to be remote.

This topic introduces three things:

1. **Streamable HTTP**: the current remote transport. One HTTP endpoint, same JSON-RPC envelope.
2. **OAuth 2.1 with PKCE**: how the host handles an auth-gated remote server. A browser-based handshake the host manages on your behalf.
3. **Scopes**: what they mean once auth is in the picture, and how they connect to the permission model in topic 9.

## Why stdio falls short

stdio is ideal for local capabilities. Fast. Zero configuration. The security boundary is simple: the server inherits your process environment.

It requires the server to be a process you can spawn. Stack Overflow's MCP runs on Stack Overflow's infrastructure. Same for GitHub, Linear, Notion, Sentry, Slack, and almost every service integration a real team wants. The moment the capability lives behind an API, stdio is wrong.

## Streamable HTTP

Streamable HTTP is MCP's current remote transport. The server exposes a single HTTP endpoint, for example `https://mcp.stackoverflow.com`. The client interacts via HTTP POST.

A request is a JSON-RPC message body in the POST payload. A response is either:

- A JSON-RPC message body in the HTTP response (one-shot, for simple tool calls)
- An upgrade to Server-Sent Events for streaming server→client messages (notifications, progress, long-running results)

The client sends one request. The server decides whether the response fits in one HTTP reply or needs to stream.

The JSON-RPC envelope is identical to topic 2. A `tools/call` looks the same whether written to a subprocess's stdin or POSTed to an HTTP endpoint. The protocol does not know or care about the transport.

This matters: everything from topics 2 through 6 still applies. The only difference is that instead of a subprocess reading stdin, a remote HTTP process reads POST bodies.

For streaming responses, the server sets `Content-Type: text/event-stream` and emits SSE events. Each event carries a JSON-RPC notification or partial result. The client reads the stream until the server closes it or sends the final response event.

This is not the old SSE transport, which used two separate endpoints. That two-endpoint model is deprecated. Streamable HTTP unifies the pattern into one endpoint that can optionally stream. If you encounter docs that distinguish "SSE servers" from "HTTP servers" as peers, the docs predate 2025.

## Add the Stack Overflow MCP to Claude Code

The `.mcp.json` in this directory:

```json
{
  "mcpServers": {
    "stackoverflow": {
      "type": "http",
      "url": "https://mcp.stackoverflow.com",
      "headers": {}
    }
  }
}
```

`type: "http"` tells Claude Code to use streamable HTTP. The `url` is Stack Overflow's published MCP endpoint. Headers are empty.

Auth is added by the OAuth flow, not hard-coded. Hard-coding a token would work, but any process reading this file would have your token, and rotation is manual. The OAuth flow stores the token in the host's credential store, where it can be refreshed and revoked.

The first time `claude mcp list` runs in this directory:

<!-- CAPTURE FROM LIVE RUN: paste the actual `claude mcp list` output the first time, showing the OAuth prompt or the device-code URL -->

## The OAuth dance

When the host POSTs to `https://mcp.stackoverflow.com` without an `Authorization` header, Stack Overflow responds with HTTP 401 and a `WWW-Authenticate` header pointing at its OAuth authorisation server.

From there:

1. **Discovery.** The host fetches `https://mcp.stackoverflow.com/.well-known/oauth-authorization-server`. Returns issuer URLs: `authorization_endpoint`, `token_endpoint`, supported scopes.
2. **Dynamic Client Registration (RFC 7591).** The host POSTs its identity to Stack Overflow's registration endpoint. Stack Overflow returns a `client_id`. No pre-existing app needed.
3. **PKCE handshake.** The host generates a `code_verifier` (random) and a `code_challenge = sha256(code_verifier)`. The challenge goes in the auth URL. The verifier stays local.
4. **Authorisation request.** The host opens the user's browser to:
   ```
   https://stackoverflow.com/oauth
       ?client_id=...&code_challenge=...&code_challenge_method=S256
       &redirect_uri=http://localhost:NN/callback&scope=...&state=...
   ```
   The user sees Stack Overflow's "Authorize Claude Code" screen, picks scopes, clicks Approve.
5. **Authorisation code → token.** Stack Overflow redirects to `localhost:NN/callback?code=...&state=...`. The host catches the redirect, POSTs the `code` plus the original `code_verifier` to Stack Overflow's token endpoint, gets back an `access_token` (and possibly a `refresh_token`).
6. **Authorised request.** The host retries the original JSON-RPC POST, this time with `Authorization: Bearer <access_token>`. Stack Overflow now responds with `tools/list`, `tools/call` results, and so on.

PKCE makes step 5 safe even though the browser saw the `code` in the URL bar. Only the host that generated the verifier can redeem the code.

Steps 1, 2, 4, and 5 are standard OAuth 2.1. Only the discovery URL (`/.well-known/oauth-authorization-server` from the resource's own host) is MCP-flavoured.

<!-- CAPTURE FROM LIVE RUN: paste the actual interactive output from `claude mcp list` followed by the first Stack Overflow tool call. -->

## Scopes and what the model can do

The scopes you grant in step 4 control what the model can do once authenticated. Stack Overflow's MCP exposes tools whose effective permissions are `min(your account, the granted scopes)`.

If you grant only a read scope like `read_inbox`, the model cannot post answers or comments even if the tool is exposed.

This is the bridge to [topic 9](../09-permissions-and-trust/). Scopes are the auth-server-side permission lever. Topic 9 covers the host-side lever (Claude Code's per-tool allow/deny rules). They stack: a tool call must pass *both* OAuth scope and host permission to run.

> The transport is the wire. OAuth is the trust handshake. The protocol on top is the same JSON-RPC.

## SSE → streamable HTTP migration

Older docs and SDKs reference an "SSE transport" with two endpoints: POST for client messages, GET for an SSE stream. That model is deprecated. Streamable HTTP unifies it into one endpoint.

If you read docs that distinguish "SSE servers" from "HTTP servers", the docs predate 2025. New servers should use streamable HTTP exclusively.

## Why this matters

- The wire format is unchanged. A JSON-RPC request that worked over stdio works over HTTP. Topics 2 through 6 still apply. Only the transport changed.
- OAuth replaces the implicit trust of "it runs on my machine". The user explicitly grants the host permission to act, with revocable scopes.
- Remote MCP is where the ecosystem is concentrating. Local stdio servers stay relevant for filesystem and developer-tool workflows. Everything user-account-scoped is heading remote.
- Discovery + dynamic registration mean students do not need to register an OAuth app per server. The protocol does it.

## Resources

- [MCP specification, streamable HTTP transport](https://modelcontextprotocol.io/specification/basic/transports#streamable-http): current remote transport
- [MCP specification, authorization](https://modelcontextprotocol.io/specification/basic/authorization): the OAuth profile
- [Stack Overflow API: authentication](https://api.stackexchange.com/docs/authentication): Stack Overflow's OAuth 2.0 flow, the same shape the MCP dance uses
- [GitHub: github-mcp-server](https://github.com/github/github-mcp-server): a second hosted MCP example
- [RFC 7591: Dynamic Client Registration](https://datatracker.ietf.org/doc/html/rfc7591): step 2 of the dance
- [RFC 7636: PKCE](https://datatracker.ietf.org/doc/html/rfc7636): what makes the redirect safe
- [Topic 9: Permissions and trust](../09-permissions-and-trust/): the host-side counterpart to OAuth scopes
