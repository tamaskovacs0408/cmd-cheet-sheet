# 7. Writing a good skill

So far we have treated skills as a file format. This topic is about writing one well: what makes a skill activate when it should, do what it should, and stay readable as it evolves. The advice consolidates two primary sources: Anthropic's own [`skill-creator`](https://github.com/anthropics/skills/tree/main/skills/skill-creator), and Jesse Vincent's [`obra/superpowers/writing-skills`](https://github.com/obra/superpowers/blob/main/skills/writing-skills/SKILL.md). Both are skills *about writing skills*, meta-skills that have learned this lesson by watching other skills fail.

The whole topic comes down to a single observation made first in [topic 3](../03-progressive-disclosure/):

> The description is the skill's user interface. Everything else is implementation.

Five commandments and a list of anti-patterns follow from that.

## The five commandments

### 1. Trigger on "Use when…", not "what it does"

The single most common failure mode is a description that summarises *what the skill does* instead of *when the model should reach for it*. The model only sees the description until activation, so the description has to do double duty as a marketing pitch and a trigger rule. From `obra/superpowers/writing-skills`:

> Testing revealed that when a description summarizes the skill's workflow, Claude may follow the description instead of reading the full skill content.

The cure is to lead with `Use when…`, third-person, and concrete: file types, error strings, library names, observable symptoms.

### 2. Be slightly pushy

A subtle calibration point: the model is *under-eager* to invoke skills by default. It will read your description and decide the user did not "really" mean it unless the trigger is unambiguous. From `anthropics/skills/skill-creator`:

> currently Claude has a tendency to "undertrigger" skills -- to not use them when they'd be useful. To combat this, please make the skill descriptions a little bit "pushy".

This is the rare authoring rule that asks you to over-specify trigger keywords on purpose. List the synonyms; list the symptoms; assume the user will not use your exact word. The `skill-creator` examples illustrate it: instead of *"How to build a fast dashboard,"* a pushy description says *"use this skill whenever the user mentions dashboards, data visualization, internal metrics, or wants to display any kind of company data, even if they don't explicitly ask for a 'dashboard'."*

### 3. Keep `SKILL.md` under ~500 lines

The Anthropic [docs](https://docs.claude.com/en/docs/claude-code/skills) state the budget directly: *"Keep `SKILL.md` under 500 lines. Move detailed reference material to separate files."* For skills with > 300-line references, include a table of contents at the top so the model can read only the section it needs.

500 lines is the *body* budget after activation. Going over is not catastrophic because Claude Code has a 25,000-token combined skill-content budget in auto-compact ([topic 5](../05-frontmatter-advanced/)), but it is wasteful. Long bodies tend to mean the skill is doing too much and should be split, or that detail belongs in `references/` ([topic 4](../04-bundled-resources/)).

### 4. Explain the *why*; avoid all-caps MUSTs

A surprisingly common mistake is to ALL-CAPS imperatives in the body. From `skill-creator`:

> If you find yourself writing ALWAYS or NEVER in all caps, or using super rigid structures, that's a yellow flag; if possible, reframe and explain the reasoning so that the model understands why the thing you're asking for is important.

Modern models comply better with reasoned instructions than with shouted ones. *"Always run the test suite before bumping the version"* fails when the model finds an edge case. *"Run the test suite before bumping the version because version bumps trigger an automatic deploy and a regression in tests will reach production within minutes"* gives the model the context to handle edge cases sensibly.

The deeper rule: a skill body is a teaching artefact for an agent that will sometimes encounter situations the author did not anticipate. Reasons travel further than rules.

### 5. Watch it fail before you write it

Both meta-skills converge on the same authoring discipline: *do not write a skill into the void*. From `obra/superpowers/writing-skills`:

> NO SKILL WITHOUT A FAILING TEST FIRST.

The methodology is:

1. **RED**: pick the prompt the skill is meant to handle. Run it through the agent *without* the skill. Watch what the model does. Pay attention to the rationalisations it produces ("I don't have enough information," "the user probably means…"). Those rationalisations are exactly what the skill needs to fix.
2. **GREEN**: write the minimum SKILL.md that addresses the observed failures. Resist the urge to write more.
3. **REFACTOR**: close loopholes by re-running the test, and any related tests, with the skill installed.

The skill ends up much smaller than what you would write from imagination. It also tends to trigger more reliably, because the description is grounded in the *actual* phrasing users (and the model) use, not a guess.

[Topic 8](../08-testing-skills/) covers the full eval-loop methodology Anthropic ships in `skill-creator` for tuning descriptions quantitatively. The TDD-for-docs methodology above is the lighter-weight cousin.

## Side-by-side: a bad description vs a good one

A real `description` field for a code-review skill, before and after.

**Before:**

```yaml
description: Helps with code review.
```

Three problems:

- No trigger keywords. Nothing for the model to match a user prompt against.
- No symptoms. What kind of review? Diff review? Architecture review? Security?
- Vague enough that any vaguely-related prompt could match, meaning none reliably will.

**After:**

```yaml
description: |
  Use when the user asks for a code review, mentions reviewing a PR,
  pastes a diff, or runs `gh pr review`. Reviews for SQL injection,
  conditional side effects, LLM trust boundary violations, and
  structural issues. Use proactively before merging, even when the
  user has not explicitly requested a review.
```

What changed:

- **Trigger keywords**: "code review", "PR", "diff", `gh pr review`. The model has multiple matchable phrases.
- **Symptoms / scope**: SQL injection, side effects, trust boundaries: concrete checks the model can recognise as "this is the same kind of thing".
- **Pushy**: "Use proactively before merging, even when the user has not explicitly requested a review." Per commandment 2.

The bad version costs the same tokens at Level 1. It just does not trigger.

## Anti-patterns to avoid

A handful of failure modes that show up repeatedly in skill libraries:

- **Description summarises the body.** The model reads the description, decides it knows the workflow, and never reads the body. Cure: trigger language only: `Use when…`, never workflow.
- **Body grows past 500 lines.** Either the skill is doing too much (split it) or detail belongs in `references/`. Going over alone is not a bug; doing so unintentionally is.
- **`@file` syntax in `SKILL.md`.** Claude Code's `@file` *force-loads* the named file into context, defeating progressive disclosure ([topic 3](../03-progressive-disclosure/)). Reference bundled files in plain prose and let the model decide whether to `Read` them.
- **Heavy-handed MUSTs and NEVERs.** Per commandment 4. Reframe to give the model the reasoning, then let it judge.
- **Multi-language dilution.** A single skill that tries to cover Python *and* TypeScript *and* Rust gets long and uneven. Either split into three skills, or have a thin `SKILL.md` that routes to language-specific `references/` (the [topic 4](../04-bundled-resources/) pattern).
- **Generic templates.** Using the `template/` SKILL.md from `anthropics/skills` and not removing the placeholder text. The placeholder triggers on nothing and confuses readers.

## Why this matters

A skill that does not trigger is invisible. A skill that triggers wrongly is annoying. A skill that triggers correctly but delivers a poor body wastes the activation. The five commandments are aimed at one thing each:

- Commandment 1: triggers correctly.
- Commandment 2: triggers reliably.
- Commandment 3: stays affordable and readable.
- Commandment 4: works on edge cases the author did not foresee.
- Commandment 5: is grounded in the real failure modes, not the author's imagination.

Authors who skip even one of these tend to ship skills that work in their own demos and fail on someone else's prompt.

[Topic 8](../08-testing-skills/) covers the methodology for verifying all of the above quantitatively before shipping.

## Resources

- [`anthropics/skills/skills/skill-creator/SKILL.md`](https://github.com/anthropics/skills/blob/main/skills/skill-creator/SKILL.md): Anthropic's meta-skill for authoring skills, with the description-pushiness and reasoning advice
- [`obra/superpowers/skills/writing-skills/SKILL.md`](https://github.com/obra/superpowers/blob/main/skills/writing-skills/SKILL.md): the TDD-for-docs methodology and the description-as-trigger rule
- [Claude Code skills authoring guide](https://docs.claude.com/en/docs/claude-code/skills): the 500-line target and the `references/` recommendation
- [`anthropics/skills/template/`](https://github.com/anthropics/skills/tree/main/template): the canonical skeleton SKILL.md
