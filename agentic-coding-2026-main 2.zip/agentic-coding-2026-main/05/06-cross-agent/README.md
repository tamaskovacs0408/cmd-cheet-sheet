# 6. Same file, different activation

[Topics 2 through 5](../02-agent-skills/) built `bootstrap-project` and `bootstrap-service` against Claude Code. This topic takes the same files to a different agent and shows that the *file format* travels but the *activation mechanism* does not.

The point lands hard if you do it live. The same `SKILL.md` runs in two agents. The behaviour the user sees is roughly the same. The mechanism behind it is fundamentally different.

## Demo: take `bootstrap-service` to OpenCode

The repo-shared skill from [topic 5](../05-frontmatter-advanced/) lives at `.claude/skills/bootstrap-service/SKILL.md`. OpenCode is the open-source coding agent at [opencode.ai](https://opencode.ai), a separate codebase from Claude Code with no shared lineage.

OpenCode's [skills documentation](https://opencode.ai/docs/skills/) lists the project-level discovery paths. The first three are:

```
.opencode/skills/
.claude/skills/
.agents/skills/
```

That second entry is the trick. **OpenCode reads `.claude/skills/` directly for cross-compatibility.** No port. No conversion. Run OpenCode in the demo repo:

```sh
cd demo-repo
opencode
```

Then ask the same question we asked Claude Code:

> bootstrap a new auth service

The skill activates. The body runs. The procedure produces the same files. From the user's seat, nothing has changed.

From the model's seat, almost everything has.

## What's different under the hood

Claude Code's mechanism, recapped from [topic 2](../02-agent-skills/):

1. At startup, Claude Code exposes a model-callable `Skill` tool and loads the available skills' `name` and `description` into Claude's context. The docs describe this as skill descriptions being "loaded into context"; the important point is that the model can see the listing before the body loads.
2. When the model decides to invoke a skill, it calls the `Skill` tool.
3. The tool reads `SKILL.md` body off disk and returns it as a tool result.
4. The body sits in the conversation for the rest of the session.

OpenCode's mechanism:

1. At startup, the model has a `skill` tool registered. **The descriptions of every available skill live inside that tool's *own* description**, so the model still sees them, but they are scoped to the tool rather than presented as a free-floating text list.
2. When the model decides to invoke a skill, it calls the `skill` tool with the skill's name as an argument.
3. The tool reads `SKILL.md` body off disk and returns it.
4. From there, the same as Claude Code.

The serialization differs, but the activation model is the same camp: the model has a tool affordance for loading the body. Practically, both behave like progressive disclosure ([topic 3](../03-progressive-disclosure/)): descriptions early, body on demand through a tool call.

Now look at Codex.

## The other camp: prompt/list-mediated selection

Codex CLI has [its own skills documentation](https://developers.openai.com/codex/skills) that uses the same SKILL.md frontmatter. But the activation is fundamentally different:

> Skills list is injected into the context window as an initial list (~2% of context window, ~8,000 chars budget).

Codex does not expose a model-callable `Skill` tool. The initial context contains a text list of available skills, including name, description, and file path, capped by a context budget. The model picks up on the right skill by ordinary text matching or explicit skill mention, then Codex loads the full `SKILL.md` for the selected skill.

This is the second activation camp. There is no model-visible "ask the tool to fetch the body" step. The body is read off disk when invoked, but the *signalling* is prompt-side, not tool-side.

Cursor 2.4's [skill documentation](https://cursor.com/docs/context/skills) describes the same shape:

> The agent is presented with available skills and decides when they are relevant.

The phrasing is consistent with prompt injection rather than a dedicated tool, though Cursor's docs are less explicit than Codex's.

## The two camps

Every agent that has shipped skills support so far falls into one of two camps:

| Activation style | How skills are discovered | How activation happens | Agents |
|---|---|---|---|
| **Tool-mediated** | Tool/context metadata lists names + descriptions | Model calls a `Skill` / `skill` tool, body returned as tool result | Claude Code, OpenCode, Cline, Sourcegraph Amp |
| **Prompt/list-mediated** | Initial context includes a text list of available skills | Body loaded on explicit skill mention or implicit text-match | Codex CLI, Cursor (inferred) |

The file format converged. The activation mechanism did not.

> The same `SKILL.md` is interpreted by every agent. *How* it is interpreted is the design decision each agent owns.

## What survives the port and what doesn't

OpenCode reads the standard frontmatter (`name`, `description`) plus its own optional fields (`license`, `compatibility`, `metadata`). Claude-Code-specific fields from [topic 5](../05-frontmatter-advanced/), including `allowed-tools`, `paths`, `model`, `effort`, `context: fork`, and `hooks`, are *ignored*. Not rejected; ignored. The skill still loads. It just behaves as if those fields were not there.

The honest table:

| Field | Claude Code | OpenCode | Codex CLI | Cursor |
|---|---|---|---|---|
| `name`, `description` | ✓ | ✓ | ✓ | ✓ |
| `allowed-tools` | ✓ | ignored | ignored | ignored |
| `paths` | ✓ | ignored | ignored | ignored |
| `model`, `effort` | ✓ | ignored | ignored | ignored |
| `context: fork` | ✓ | ignored | ignored | ignored |
| `disable-model-invocation` | ✓ | ignored | partial | ✓ |
| `license`, `compatibility`, `metadata` | ignored | ✓ | ignored | ✓ |
| Codex-specific (lives in `agents/openai.yaml`) | n/a | n/a | ✓ | n/a |

For a skill you want to ship to multiple agents, the practical rule is: keep the body and the description authoring practices universal; treat anything in the frontmatter beyond `name` and `description` as an enhancement specific to one agent.

## A wider survey

The full landscape, briefly:

| Agent | Skills support | Discovery | Activation | Notes |
|---|---|---|---|---|
| **Claude Code** | First-class | `~/.claude/skills/`, `.claude/skills/`, plugin, enterprise | Tool-driven (`Skill`) | Reference implementation; richest frontmatter |
| **OpenCode** | First-class | `.opencode/skills/`, `~/.config/opencode/skills/`, `.claude/skills/`, `.agents/skills/` | Tool-driven (`skill`) | Reads `.claude/` for cross-compat |
| **Codex CLI** | First-class | `.agents/skills/`, `~/.agents/skills/`, `/etc/codex/skills` | Prompt/list-mediated | Codex extras live in `agents/openai.yaml` |
| **Cursor** | First-class (2.4+) | `.cursor/skills/`, `.agents/skills/`, plus Claude/Codex compat | Prompt/list-mediated (inferred) | Has `/migrate-to-skills` to convert legacy rules |
| **Cline** | First-class (3.48+) | `.cline/skills/`, `~/.cline/skills/` | Tool-driven (inferred) | Standard spec |
| **Sourcegraph Amp** | First-class | `.agents/skills/`, `~/.config/agents/skills/`, plus `.claude/` | Tool-driven | Standard spec |
| **Continue** | Via MCP plugin | (no native path) | MCP tool call | Not native |
| **Aider** | None | n/a | n/a | Community discussion only |
| **Zed AI** | Via marketplace | Plugin-driven | n/a | No first-party native support |
| **Goose** | Via extensions framework | Inferred native | Inferred | Listed by multi-agent installers |

Cursor's [skill docs](https://cursor.com/docs/context/skills) note explicitly that they read `.claude/` and `.codex/` paths for cross-compatibility. Three agents in the table now read each others' directories.

## Why this matters

The skill format is the most successful piece of cross-agent standardization since `AGENTS.md`. The reason it spread is that it is small (two required fields, a markdown body, a directory) and that the [open spec at agentskills.io](https://agentskills.io) formalised the file format without forcing a particular activation mechanism. Every agent could keep its own runtime model and read the same files.

The downside is the asymmetry covered above. The frontmatter dialect is not really shared; only the universal subset is. The activation differences mean that *how aggressively* a skill triggers depends on which agent the user is running. A skill written and tuned in Claude Code or OpenCode (where the model has a tool affordance for invocation) may behave differently in Codex, where the initial skill list is ordinary prompt context and capped by a context budget.

For an author shipping a skill to a multi-agent audience, as `obra/superpowers` and `garrytan/gstack` from [topic 9](../09-skills-in-the-wild/) both do, the lesson is to author for the *least* informative camp. If your description triggers reliably under prompt-injection, it almost certainly triggers under tool-driven.

> Author for the weakest activation camp. Anything works in the strongest one.

## Resources

- [Anthropic Agent Skills: open spec](https://agentskills.io)
- [OpenCode skills](https://opencode.ai/docs/skills/)
- [OpenAI Codex Agent Skills](https://developers.openai.com/codex/skills)
- [Cursor Agent Skills](https://cursor.com/docs/context/skills)
- [Cline Skills](https://docs.cline.bot/customization/skills)
- [Sourcegraph Amp: Agent Skills](https://ampcode.com/news/agent-skills)
- [Cursor Rules vs Agent Skills (community comparison)](https://dev.to/nedcodes/cursor-rules-vs-agent-skills-i-tested-both-heres-when-each-one-actually-works-1ld)
