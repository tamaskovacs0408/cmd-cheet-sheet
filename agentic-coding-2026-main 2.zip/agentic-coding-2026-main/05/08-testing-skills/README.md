# 8. Testing and evolving

[Topic 7](../07-writing-good-skill/) covered authoring as a craft. This topic covers it as an engineering discipline: how to verify a skill activates when it should, does what it should, and stops doing what it should not. The unit of work is the *eval*: a prompt, a run, an assertion. The goal is to turn skill authoring into something you can iterate on with feedback rather than vibes.

Two methodologies have emerged in the public ecosystem. They disagree on rigor and converge on principle.

> Validate against reality, don't write into the void.

## Why a skill needs to be tested

A skill that never triggers is indistinguishable from a skill that does not exist. A skill that triggers when it shouldn't is worse because it spends tokens, hijacks unrelated conversations, and undermines trust in every other skill installed alongside it. Reading a SKILL.md and pronouncing it good is a poor predictor of either failure mode. The model picks up on patterns the author cannot see: the way two adjacent skills' descriptions interact, the way a vague trigger word matches a phrasing the user actually used.

There are three things you can test about a skill:

1. **Activation correctness**: does the skill trigger on the prompts it should, and not on the ones it should not?
2. **Body correctness**: when activated, does the model produce the work the skill was meant to produce?
3. **Side-effect safety**: does the skill behave the same alongside other skills as it does alone?

The two methodologies below address (1) and (2). Side-effect safety mostly takes care of itself if (1) is rigorous; a skill that triggers only on its intended prompts is unlikely to interact badly with others.

## Methodology 1: Anthropic's eval loop (quantitative)

Anthropic ships [`skill-creator`](https://github.com/anthropics/skills/tree/main/skills/skill-creator), a meta-skill in the official skills repo that scaffolds new skills *and* drives an eval harness for them. The harness lives inside `skill-creator` itself, distributed across several subdirectories:

```
skill-creator/
├── SKILL.md
├── scripts/        # run_eval.py, run_loop.py, aggregate_benchmark.py,
│                   # improve_description.py, generate_report.py, ...
├── agents/         # analyzer.md, comparator.md, grader.md (sub-agent prompts)
├── eval-viewer/    # viewer.html + generate_review.py
└── references/     # schemas.md
```

When you use `skill-creator` to author a new skill, it instructs Claude to write your test cases to `evals/evals.json` *in the skill being authored*, and then runs the harness against them. The output lands as `benchmark.json` in your skill's directory.

`evals.json` is a list of test prompts paired with assertions:

```json
[
  {
    "prompt": "bootstrap a python project for me",
    "should_trigger": "bootstrap-project",
    "assertions": [
      "creates README.md",
      "creates .gitignore",
      "runs git init",
      "produces an initial commit"
    ]
  },
  {
    "prompt": "what is the syntax for a python list comprehension?",
    "should_trigger": null
  }
]
```

The flow has two pieces. For *body correctness*, `skill-creator`'s SKILL.md instructs Claude to **spawn two sub-agents in the same turn**: one with the skill installed, one without. It replays each prompt against both, then delegates grading to a third sub-agent prompt at `agents/grader.md`. The aggregated results land in `benchmark.json`, and `eval-viewer/` renders them as an HTML report you can read alongside the diff.

For *activation correctness*, `scripts/run_loop.py` automates description tuning. Its argparse defaults are worth knowing: `--runs-per-query 3`, `--holdout 0.4` (60/40 train/test split), `--max-iterations 5`, `--num-workers 10`, `--trigger-threshold 0.5`. SKILL.md (line 339) recommends *"create 20 eval queries"*, balanced 8 to 10 should-trigger and 8 to 10 should-not.

The two loops operate independently:

- **The body loop**: tweak `SKILL.md`, rerun, see whether the activated runs satisfy the assertions better. This tests whether the procedure works.
- **The description loop** (`scripts/run_loop.py`): tunes the *description* against the ~20 queries. Picks the description with the best held-out trigger score across iterations. Per SKILL.md: *"splits the eval set into 60% train and 40% held-out test … running each query 3 times."*

This is the only piece of the skills ecosystem with a quantitative tuning loop. It is heavier than what most authors will reach for, but the precedent is important: descriptions are tunable, and a tuned description outperforms an authored one.

## Methodology 2: TDD for docs (qualitative)

`obra/superpowers/writing-skills` advocates the lighter-weight discipline already introduced in [topic 7](../07-writing-good-skill/):

> NO SKILL WITHOUT A FAILING TEST FIRST.

The methodology is RED-GREEN-REFACTOR adapted to skill authoring:

1. **RED: watch the failure.** Pick the user prompt the skill is meant to handle. Run it through the agent *without* the skill installed, in a fresh sub-agent so there is no contamination from your own conversation. Watch the model's response, especially the rationalisations it produces, such as *"I don't have enough context,"* *"the user probably means…"*, *"I'll guess at…"*. These are the gaps a skill body needs to close.
2. **GREEN: write the minimum.** Write only what addresses the observed gaps. Resist the urge to anticipate other failure modes. The skill stays small.
3. **REFACTOR: close loopholes.** Re-run the original prompt and any related prompts. New rationalisations? Add to the body. Old ones gone? Move on.

The product is qualitatively different from the eval-loop output. There is no `evals.json` and no aggregated score. The artefact is the skill itself, plus the author's notebook of failure modes. The methodology trades repeatability for speed and works well for skills with few prompts and high judgement-content (debugging procedures, code reviews) where the assertions in an `evals.json` would be brittle.

## When to use which

| | `skill-creator` eval loop | `superpowers` TDD-for-docs |
|---|---|---|
| Best for | Skills with measurable outputs (code generated, files written) | Skills with judgement-heavy outputs (review, debug, plan) |
| Cost per iteration | High, runs ~20 prompts × 3 runs | Low, single run, single observation |
| Reproducibility | High, `benchmark.json` is diffable | Low, relies on author's reading of the trace |
| Catches activation drift | Yes, held-out queries flag both undertriggering and overtriggering | Partially, only on the prompts you happen to test |
| Best for tuning | Descriptions, especially across a multi-skill library | Bodies, especially for novel skills |

A pragmatic combination: TDD-for-docs for the first version of the skill, eval-loop for the second.

## A manual fallback

For one-off skills you do not plan to maintain, a single-prompt manual check is fine. Run Claude Code, ask:

> What skills are available?

The model will list every skill loaded into the Level 1 description budget. If the new skill is not there, the description was either too long (truncated) or the file is in the wrong directory. If it is there, run a phrasing the description should match. If it does not trigger, edit the description to add the keywords from the prompt and try again.

This is what most skill authors do for the first few skills they write. It is not enough for anything that ships to others, but it is enough to feel the loop.

## Common testing mistakes

- **Testing in your own session.** The author's main Claude Code session is contaminated with conversation history. Run evals in a sub-agent or a fresh session.
- **Testing against the same prompt every time.** The description optimises to that one prompt and over-fits. Use ≥10 phrasings of the same intent.
- **Skipping should-not-trigger tests.** A skill that triggers on everything also "passes" all positive tests. Held-out negatives are essential.
- **Grading the wrong thing.** Assertions about the activated *output* (files written, commands run) are stronger than assertions about the *response text* (which is harder to grade reliably). Prefer "did the file exist after this run?" to "did the model say it created the file?".

## Why this matters

Skills are the agent-context analogue of code. They get committed, reviewed, refactored, and broken by neighbouring changes. Treating them as untested code is the same mistake teams made with shell scripts in the early 2010s, and the cure is the same: a small harness around the things that are already there. The two methodologies above are early but real attempts at that harness, and the public skill libraries from [topic 9](../09-skills-in-the-wild/) increasingly ship with `evals/` directories of their own.

The end-to-end exercise in [topic 10](../10-build-your-own/) walks through both methodologies on a single skill, so you see what each one feels like.

## Resources

- [`anthropics/skills/skills/skill-creator/SKILL.md`](https://github.com/anthropics/skills/blob/main/skills/skill-creator/SKILL.md): the full eval-harness definition, including `run_loop.py`
- [`anthropics/skills/template`](https://github.com/anthropics/skills/tree/main/template): the bare skill skeleton; use `skill-creator` when you want the eval harness
- [`obra/superpowers/skills/writing-skills/SKILL.md`](https://github.com/obra/superpowers/blob/main/skills/writing-skills/SKILL.md): the TDD-for-docs Iron Law and the rationalisation-watching technique
- [Topic 10: Build your own skill](../10-build-your-own/): both methodologies applied end-to-end to one skill
