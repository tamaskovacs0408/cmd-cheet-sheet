# 1. The pain

The failure mode is not that `CLAUDE.md` exists. The failure mode is that it becomes the only place to put everything the agent might need.

At first the file is useful: language version, package manager, test command, code style, repository layout. Those facts belong in always-on context because most turns need them. Then the file starts to collect procedures: how to write PR descriptions, how to handle a Sentry alert, how to run a deploy, how to add a new microservice, how to bump the changelog. Those procedures are useful, but most turns do not need them.

## The eager context problem

[Lecture 4](../../04/README.md) covered the eager layer: `CLAUDE.md`, `AGENTS.md`, system prompts, project memory. Anything in those files is loaded before the user asks the next question. That is correct for stable facts. It is costly for occasional procedures.

Imagine a `CLAUDE.md` that has accreted over six months:

```markdown
# Project: Acme API

## Conventions

- Python 3.12, uv for dependencies.
- Conventional Commits.
- Squash-merge to main.

## How to deploy

(40 lines of deploy steps and rollback instructions)

## How to debug a Sentry alert

(60 lines of triage flow with grep examples)

## How to write a PR description

(20 lines of structure and examples)

## How to add a new microservice

(80 lines of scaffolding instructions)
```

The first block is a fact every turn needs. The next four are procedures most turns do not need. The deploy procedure costs tokens on the typo turn. The Sentry runbook costs tokens on the PR-description turn. The scaffolding instructions sit in context while the agent edits a README.

That creates two problems:

- **Long context**: the model has more tokens to read before it can answer, and the important facts have to compete with rarely used procedures.
- **Context rot**: stale runbooks, obsolete commands, and contradictory old instructions keep influencing unrelated work because they are always present.

The file grows because it is useful. It rots because every useful procedure is treated as if it were relevant all the time.

## The tool overload problem

The same pattern shows up in tools. A coding agent starts with a small set of general tools: read files, search, edit, run commands. Then every recurring workflow tempts you to add another specialized tool: create a PR description, triage a Sentry alert, query the warehouse, deploy a service, open an incident, generate a report.

Too many tools create a different kind of eager context. Tool names, descriptions, schemas, permissions, and examples all have to be exposed before the model can choose among them. The action surface gets larger, tool selection gets noisier, and the agent has more ways to do the wrong thing confidently.

Writing tools also raises the cost of capturing a procedure. A real tool needs code, packaging, auth, error handling, versioning, tests, and sometimes hosting. That is justified when the agent needs a new capability, such as calling an API the shell cannot reach. It is overkill when the missing piece is procedural knowledge: *when we write a PR description, use this structure; when we debug Sentry, follow this checklist; when we bootstrap a service, create these files in this order.*

## What you want instead

The shape you want is between always-on memory and custom tools:

- Keep project facts eager because every turn needs them.
- Keep occasional procedures lazy because they matter only on matching prompts.
- Make the unit simple enough to write without building a service or SDK integration.
- Let the unit carry deterministic helpers when plain prose is not enough.

That is the hint for the rest of the lecture: lazy loaded, simple capabilities. The next topic gives that shape a name and a file format.

## Resources

- [Lecture 4: Context Engineering and Project Memory Design](../../04/README.md): the eager-context layer this topic contrasts with
