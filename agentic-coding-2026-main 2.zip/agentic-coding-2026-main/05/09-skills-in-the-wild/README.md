# 9. Skills in the wild

The previous topics covered how to write a good skill. This topic covers what other people have written. Six months after the format launched, the public ecosystem is large enough that there is now more to learn from reading skills than from writing your first one. Most of the conventions you will reach for were developed in libraries other people maintain.

There is one structural caveat to acknowledge first.

> There is no skill marketplace. Discovery is GitHub stars and awesome-lists.

The format is open ([agentskills.io](https://agentskills.io)), the implementations are open-source, and the libraries are scattered across personal repositories. Some early skill-manager UIs are appearing, which we mention at the end, but as of this lecture the canonical move is to clone an interesting library, copy individual skill directories into `~/.claude/skills/` (or your repo's `.claude/skills/`), and iterate.

This topic is therefore a reading list rather than a feature comparison.

## Anthropic-official: `anthropics/skills`

The reference repository at [`github.com/anthropics/skills`](https://github.com/anthropics/skills) (~125k stars) is the canonical home for the format. It contains the spec under `spec/`, a starter scaffold under `template/`, and a working library of ~17 skills under `skills/`. The skills are intentionally varied; they exist as much to demonstrate what a well-formed skill looks like as to be useful.

Worth reading and reusing:

- **`skill-creator`**: meta-skill that scaffolds new skills and the eval harness from [topic 8](../08-testing-skills/). Your first stop when authoring.
- **`webapp-testing`**: browser-driven QA via Playwright. Reads as a reference for skills that bundle non-trivial scripts.
- **`docx`, `pdf`, `pptx`, `xlsx`**: Office-format authoring. Each ships a Python script that does the deterministic format manipulation; the SKILL.md is small. Excellent worked examples of the script-source-doesn't-cost-tokens primitive from [topic 4](../04-bundled-resources/).
- **`frontend-design`, `theme-factory`, `brand-guidelines`**: UI generation. Useful template for skills that ship reference assets (fonts, colour palettes).

Anthropic also maintains [`anthropics/claude-plugins-official`](https://github.com/anthropics/claude-plugins-official) (~18k stars), an "official plugin directory" of skills bundled as installable plugins. The same skills, plus a plugin manifest, plus an installer.

## The most-cited community library: `obra/superpowers`

[`github.com/obra/superpowers`](https://github.com/obra/superpowers) (~171k stars), maintained by Jesse Vincent, is the most influential community skill library and the source of much of the authoring vocabulary used in [topic 7](../07-writing-good-skill/) and [topic 8](../08-testing-skills/). It is multi-harness: the same skills ship with `.claude-plugin/`, `.codex-plugin/`, `.cursor-plugin/`, and `.opencode/` directories, picking up the cross-agent compatibility from [topic 6](../06-cross-agent/).

The library is organised around process discipline rather than role-playing. The skills are meta-skills about how to do work, not about what to do:

- **`writing-skills`**: meta-skill that imposes the TDD-for-docs methodology from [topic 8](../08-testing-skills/) on new skill authors. The most-quoted skill in this lecture.
- **`writing-plans`** + **`executing-plans`**: the "spec then execute" pattern. Used together to plan a feature, get approval on the plan, and then execute against it with review checkpoints.
- **`systematic-debugging`**: root-cause-first debugging procedure. The Iron Law: *"no fixes without root cause."*
- **`test-driven-development`**: the obvious one. Forces the model to write failing tests before implementation.
- **`brainstorming`**: turns vague ideas into validated specs through one-question-at-a-time dialogue.
- **`subagent-driven-development`**, **`dispatching-parallel-agents`**: the patterns for fanning out work across sub-agents.
- **`requesting-code-review`**, **`receiving-code-review`**: reviewer and reviewee discipline, separated.
- **`verification-before-completion`**: refuses to claim work is done without an evidence step. A useful counter-skill against agent over-confidence.

If you adopt one library, this is probably the one. The skills compose with each other: `writing-plans` produces an artefact `executing-plans` knows how to consume. The writing style is the cleanest reference in the public ecosystem.

## The role-based virtual team: `garrytan/gstack`

[`github.com/garrytan/gstack`](https://github.com/garrytan/gstack) (~86k stars), by Garry Tan, takes a different organising principle: model the skills after job roles in a startup. The library is large (~40 skills) and opinionated. Reading a few:

- **`cso`**: chief security officer mode. Infrastructure-first audit (secrets, supply chain, CI/CD), OWASP top-10, STRIDE. Two modes: daily zero-noise, monthly comprehensive. Trend tracking across runs.
- **`investigate`**: root-cause debugging in four phases. The "Iron Law" again: no fixes without root cause.
- **`qa`**, **`qa-only`**: systematic QA testing. `qa` runs the test-fix-verify loop; `qa-only` produces a report without fixing anything. The split is a useful pattern for when a skill should and should not have side effects.
- **`ship`**, **`land-and-deploy`**: release workflow. `ship` does the PR creation; `land-and-deploy` takes over after merge through to production verification.
- **`plan-ceo-review`**, **`plan-eng-review`**, **`plan-design-review`**, **`plan-devex-review`**: interactive plan reviewers from each disciplinary lens. Useful as a pattern: a single skill family with multiple personae.
- **`autoplan`**: runs all four reviewers sequentially with auto-decisions. The composite skill that depends on the others.
- **`careful`**, **`freeze`**, **`guard`**: safety guardrails (warns before destructive operations, restricts edits to a directory, both combined).

`gstack` is more opinionated than `superpowers` and reaches further into product/business decision-making. For teams that want a "virtual engineering organisation" out of the box, it is the most complete option. For teams that want a methodology-only library, prefer `superpowers`.

## Built-in Claude Code commands and skills

Claude Code itself ships with prompt-based bundled skills and built-in commands that are available without installing anything. The exact set changes over time, so treat this as a snapshot worth rechecking before a live demo.

- **Bundled skills**: `/simplify`, `/batch`, `/debug`, `/loop`, and `/claude-api` are prompt-based skills listed alongside commands in Claude Code's command reference.
- **Built-in commands exposed through the Skill tool**: `/init`, `/review`, and `/security-review` can be controlled with `Skill(...)` permission rules, but they are not the same thing as user-authored skills on disk.

These are not meant to replace reading user-authored `SKILL.md` examples from the public libraries above. They are useful mainly as quality-of-life utilities and as a reminder that hosts can expose both slash commands and prompt-based skills through the same user interface.

## Awesome-lists and aggregators

Three community-maintained indexes act as discovery surfaces:

- [`hesreallyhim/awesome-claude-code`](https://github.com/hesreallyhim/awesome-claude-code) (~42k stars): broadest-coverage awesome-list. Skills, hooks, commands, and tooling.
- [`VoltAgent/awesome-agent-skills`](https://github.com/VoltAgent/awesome-agent-skills) (~19k stars): multi-harness focus. Skills tagged by which agents they support.
- [`zebbern/claude-code-guide`](https://github.com/zebbern/claude-code-guide) (~4k stars): a beginner-to-power-user reference rather than a list, but with substantial skill coverage.

Early skill-manager UIs are also appearing, including projects like `iannuttall/dotagents` (dotfiles-style management) and `skalesapp/skales` (a desktop manager). None has reached the maturity of an `npm` registry or a real marketplace.

## Top 10 to read first

If you only read ten skills, read these, chosen for being well-tuned authoring examples in addition to being useful:

1. [`anthropics/skills/skill-creator`](https://github.com/anthropics/skills/tree/main/skills/skill-creator): the canonical authoring template and eval-harness machinery.
2. [`obra/superpowers/writing-skills`](https://github.com/obra/superpowers/tree/main/skills/writing-skills): the TDD-for-docs methodology.
3. [`obra/superpowers/systematic-debugging`](https://github.com/obra/superpowers/tree/main/skills/systematic-debugging): root-cause-first debugging.
4. [`obra/superpowers/test-driven-development`](https://github.com/obra/superpowers/tree/main/skills/test-driven-development): TDD as a skill.
5. [`obra/superpowers/writing-plans`](https://github.com/obra/superpowers/tree/main/skills/writing-plans) and [`executing-plans`](https://github.com/obra/superpowers/tree/main/skills/executing-plans): the "spec then execute" pair.
6. Claude Code built-in [`security-review`](https://docs.claude.com/en/docs/claude-code/skills): short, well-tuned, ships in every session.
7. [`garrytan/gstack/cso`](https://github.com/garrytan/gstack): the most ambitious security-audit skill in the public ecosystem.
8. [`garrytan/gstack/investigate`](https://github.com/garrytan/gstack): comparison reading for `superpowers/systematic-debugging`.
9. [`anthropics/skills/webapp-testing`](https://github.com/anthropics/skills/tree/main/skills/webapp-testing): bundled-script reference, browser-driven.
10. [`anthropics/skills/mcp-builder`](https://github.com/anthropics/skills/tree/main/skills/mcp-builder): scaffolds MCP servers, ties to lecture 6.

A useful exercise after this lecture is to read three skills from different libraries and compare how each handles the same underlying problem (e.g. debugging in `superpowers/systematic-debugging` vs `gstack/investigate`).

## Why this matters

Skills are six months old. The public ecosystem has converged on a handful of conventions in that time, almost all of which were invented in the libraries above and then absorbed into authoring guides like the one in [topic 7](../07-writing-good-skill/). The fastest way to write a better skill is to read three skills from `superpowers`, three from `gstack`, and three from `anthropics/skills`, notice what they have in common, and adopt those conventions.

The closing exercise in [topic 10](../10-build-your-own/) walks through writing a skill from scratch using `skill-creator` as the scaffold and one of the conventions above (the TDD-for-docs methodology from [topic 8](../08-testing-skills/)).

## Resources

- [`anthropics/skills`](https://github.com/anthropics/skills): official reference repo
- [`anthropics/claude-plugins-official`](https://github.com/anthropics/claude-plugins-official): official plugin directory
- [`obra/superpowers`](https://github.com/obra/superpowers): most-cited community library
- [`garrytan/gstack`](https://github.com/garrytan/gstack): role-based virtual engineering team
- [`hesreallyhim/awesome-claude-code`](https://github.com/hesreallyhim/awesome-claude-code): community awesome-list
- [`VoltAgent/awesome-agent-skills`](https://github.com/VoltAgent/awesome-agent-skills): multi-harness awesome-list
- [Claude Code built-in skills](https://docs.claude.com/en/docs/claude-code/skills): reference for the bundled set
