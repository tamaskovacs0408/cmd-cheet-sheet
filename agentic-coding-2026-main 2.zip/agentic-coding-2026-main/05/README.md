# Lecture 5: Agent Skills

## Overview

You have been pasting the same instructions into project after project. Your `CLAUDE.md` files are growing into runbooks, and most of what's in them loads on every turn even when irrelevant. The same overload shows up in tool lists: every repeated workflow tempts you to add another custom tool, even when the missing piece is procedure rather than code.

This lecture starts with the pain of eager context and tool overload, then introduces the missing middle: lazy loaded, simple capabilities called skills. A skill is a `SKILL.md` file with frontmatter, a markdown body, and an activation rule. From there, the lecture builds out progressive disclosure, bundled scripts and references, advanced frontmatter, the cross-agent landscape, the historical context, the authoring craft, the testing methodologies, the public ecosystem, and an end-to-end walkthrough of writing a real skill in fifteen minutes.

Throughout, the running example is a project bootstrapper: a personal `bootstrap-project` skill in `~/.claude/skills/`, and a repo-shared `bootstrap-service` skill in the demo repo's `.claude/skills/`. Both run unmodified in Claude Code and OpenCode, demonstrating that the file format converged across agents while the activation mechanism did not.

## Learning Objectives

By the end of this lecture, you will be able to:

- Explain why eager `CLAUDE.md` runbooks and oversized tool lists both become a context-management problem
- Write a SKILL.md from scratch, including the agentskills.io portable core, placement rules, required frontmatter, and the gotchas the docs spell out
- Explain the first activation trace and the three levels of progressive disclosure, then predict what enters context at each step
- Use bundled `references/` and `scripts/` correctly, and know why script source costs zero tokens
- Verify a skill's activation and bundled-file usage in an OpenTelemetry trace
- Use the advanced frontmatter fields
- Port a skill to OpenCode and predict what survives the port and what does not
- Distinguish between Claude Code's tool-mediated activation and Codex's prompt/list-mediated activation
- Author a skill that triggers reliably, applying the five commandments from `skill-creator` and `superpowers/writing-skills`
- Validate a skill quantitatively (Anthropic eval loop) or qualitatively (TDD-for-docs)
- Navigate the public skill ecosystem and find the right reference skill to read for any new authoring task

## Topics

### 1. [The pain](./01-the-pain/)

Why does a skill exist? What goes wrong when long `CLAUDE.md` runbooks and large tool lists are loaded eagerly?

### 2. [What is a skill?](./02-agent-skills/)

The standard at agentskills.io, the `SKILL.md` file, where skills live, how to create the first one, and what activation looks like in the trace.

### 3. [Progressive disclosure](./03-progressive-disclosure/)

What gets loaded when, and why does the format scale to dozens of installed skills? What does Anthropic mean by "filesystem-based architecture"?

### 4. [Bundled resources](./04-bundled-resources/)

A skill is a directory, not a file. What is the difference between a `references/` file and a `scripts/` file, and why does a script's source cost zero tokens?

### 5. [Frontmatter beyond the basics](./05-frontmatter-advanced/)

`allowed-tools`, `paths`, `model`, `effort`, `context: fork`. Which of them does what, what does Claude Code's "personal overrides project" rule actually mean, and what is the most common gotcha?

### 6. [Same file, different activation](./06-cross-agent/)

Take the repo-shared skill to OpenCode. Why does it just work, and how is the activation different under the hood? What are the two camps every coding agent has chosen between?

### 7. [Writing a good skill](./07-writing-good-skill/)

Five commandments. The single biggest failure mode is a description that summarises the body instead of triggering on it.

### 8. [Testing and evolving](./08-testing-skills/)

Two methodologies: Anthropic's quantitative eval loop and `superpowers`' TDD-for-docs. Which one fits your team?

### 9. [Skills in the wild](./09-skills-in-the-wild/)

A reading tour of `anthropics/skills`, `obra/superpowers`, and `garrytan/gstack`. What conventions has the public ecosystem converged on, and what should you read first?

### 10. [Build your own skill](./10-build-your-own/)

End-to-end walkthrough. Pick a real repeated pain, scaffold with `skill-creator`, author description and body, add bundled resources, validate with evals, ship to `~/.claude/skills/`, port to OpenCode.

## Further Reading

Cross-cutting references that span multiple topics. Topic-specific links live in each topic's own README.

Primary sources:

- [Claude Code skills documentation](https://docs.claude.com/en/docs/claude-code/skills)
- [Agent Skills overview (Anthropic)](https://docs.claude.com/en/docs/agents-and-tools/agent-skills/overview)
- [Anthropic Engineering: Equipping agents for the real world with Agent Skills](https://www.anthropic.com/engineering/equipping-agents-for-the-real-world-with-agent-skills)
- [Skills explained: Skills vs prompts, Projects, MCP, and subagents](https://claude.com/blog/skills-explained)
- [agentskills.io: the open spec](https://agentskills.io)
- [`github.com/anthropics/skills`](https://github.com/anthropics/skills)

Cross-agent skills documentation:

- [OpenCode skills](https://opencode.ai/docs/skills/)
- [OpenAI Codex Agent Skills](https://developers.openai.com/codex/skills)
- [Cursor Agent Skills](https://cursor.com/docs/context/skills)
- [Cline Skills](https://docs.cline.bot/customization/skills)
- [Sourcegraph Amp: Agent Skills](https://ampcode.com/news/agent-skills)

Public skill libraries (full reading list in [topic 9](./09-skills-in-the-wild/)):

- [`anthropics/skills`](https://github.com/anthropics/skills): official reference
- [`obra/superpowers`](https://github.com/obra/superpowers): most-cited community library
- [`garrytan/gstack`](https://github.com/garrytan/gstack): role-based virtual engineering team

Commentary worth reading:

- [Simon Willison: Claude Skills are awesome, maybe a bigger deal than MCP (Oct 2025)](https://simonwillison.net/2025/Oct/16/claude-skills/)
- [Simon Willison: Agent Skills (open standard writeup, Dec 2025)](https://simonwillison.net/2025/Dec/19/agent-skills/)
- [Armin Ronacher: Skills vs Dynamic MCP Loadouts](https://lucumr.pocoo.org/2025/12/13/skills-vs-mcp/)
