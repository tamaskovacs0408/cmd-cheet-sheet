# 2. What is a skill?

A skill is a directory that contains a `SKILL.md` file. `SKILL.md` has YAML frontmatter at the top and a markdown body underneath.

The frontmatter tells the agent *when* the skill is relevant. The body tells the agent *what to do* after it has decided the skill applies.

```markdown
---
name: bootstrap-project
description: Use when the user wants to start a new project from scratch. Sets up README.md, .gitignore, license, and an initial commit.
---

When the user asks to bootstrap a new project:

1. Confirm the language or framework.
2. Create README.md with a one-paragraph stub.
3. Create .gitignore from the language defaults.
4. Add MIT LICENSE with the user's name and year.
5. Run `git init`, then make an initial commit.
```

That is the smallest useful form: a name, a description, and a markdown procedure.

> A skill is a markdown procedure with an activation rule.

## The standard

The portable format is specified at [agentskills.io](https://agentskills.io). The standard is intentionally small:

- A skill is a directory.
- The entry point is `SKILL.md`.
- `SKILL.md` starts with YAML frontmatter.
- The portable required fields are `name` and `description`.
- The body is markdown.
- Extra files can live beside `SKILL.md` and be loaded later.

That small core is why the format crossed agent boundaries quickly. Claude Code, OpenCode, Codex, Cursor, Cline, and Amp disagree about discovery paths and activation mechanics, but they can all understand the same basic file: `SKILL.md` with a `name`, a `description`, and a body.

## Where skills live

Discovery paths are agent-specific. For this lecture, the two Claude Code locations matter most:

| Scope | Path | Use when |
|---|---|---|
| Personal | `~/.claude/skills/<skill-name>/SKILL.md` | The procedure is yours and should follow you across projects. |
| Project | `.claude/skills/<skill-name>/SKILL.md` | The procedure belongs to this repository and should be shared with the team. |

The directory name should match `name`. Claude Code is lenient, but the habit keeps the same skill portable to agents that enforce the match.

## Create the first skill

Make a personal skill directory:

```sh
mkdir -p ~/.claude/skills/bootstrap-project
```

Write `~/.claude/skills/bootstrap-project/SKILL.md`:

```markdown
---
name: bootstrap-project
description: Use when the user wants to start a new project from scratch. Sets up README.md, .gitignore, an MIT LICENSE, and an initial commit. Triggers on phrases like "new project", "bootstrap", "scaffold", "set up a repo".
---

When the user asks to bootstrap a new project:

1. Confirm the language or framework (Python, TypeScript, Rust, Go, …).
2. Create `README.md` with a one-paragraph description placeholder.
3. Create `.gitignore` matching the language defaults.
4. Add an MIT `LICENSE` with the current year and the user's name.
5. Run `git init`, stage all files, and make an initial commit titled `chore: initial commit`.
```

That is enough to run the demo. Open a fresh project directory:

```sh
mkdir /tmp/test-project
cd /tmp/test-project
claude
```

Then ask:

> bootstrap a python project for me

Claude Code starts with only the skill metadata. It sees the `bootstrap-project` description, decides it matches the request, loads the body, and follows the procedure.

If the skill does not fire, the description did not match the request. Edit it to be more explicit about phrases like "bootstrap", "new project", "scaffold", and "set up a repo", then try again. [Topic 7](../07-writing-good-skill/) covers trigger descriptions in detail.

## What activation looks like in the trace

If you route Claude Code through the OpenTelemetry stack from [lecture 2 topic 12](../../02/12-real-coding-agents/), the first invocation produces a trace like this:

1. At startup, the model sees `name` and `description` for available skills.
2. The body of `SKILL.md` stays on disk.
3. When the prompt matches the description, Claude Code invokes the `Skill` tool.
4. The `Skill` tool returns the rendered markdown body as a tool result.
5. The model continues with that procedure in the conversation.

From the model's point of view, a skill is one more tool call in the normal agent loop. Nothing magical is happening: user prompt, API request, tool result, API request, more tools. The difference is that the tool result is procedural knowledge rather than file contents or shell output.

## Frontmatter rules and gotchas

A few rules from the docs will bite you if you miss them:

- **`name` is technically optional in Claude Code** because it falls back to the directory name, but the open standard requires it. Always set it.
- **`name` constraints**: max 64 characters, lowercase letters, numbers, and hyphens only. No XML tags. The reserved words `anthropic` and `claude` are forbidden.
- **`description` constraints**: non-empty, max 1,024 characters.
- **`name` should match the directory name.** OpenCode enforces this strictly; Claude Code is lenient. Match it everywhere as a habit.
- **The body is plain markdown.** No magic, no template language at this level.

## Why this matters

The skills format is small on purpose. Two required fields, a markdown body, and a directory are enough to express a lazy procedure. That is the missing middle between a long `CLAUDE.md` and a custom tool.

[Topic 3](../03-progressive-disclosure/) turns this activation story into the three-level loading model. [Topic 4](../04-bundled-resources/) adds references and scripts to the same directory so skills can carry larger context and deterministic helpers without loading everything upfront.

## Resources

- [The open spec at agentskills.io](https://agentskills.io)
- [Claude Code skills documentation](https://docs.claude.com/en/docs/claude-code/skills)
- [Agent Skills overview (Anthropic)](https://docs.claude.com/en/docs/agents-and-tools/agent-skills/overview)
- [Anthropic: Skills explained: Skills vs prompts, Projects, MCP, and subagents](https://claude.com/blog/skills-explained)
- [Lecture 2 topic 12: Reading a Real Coding Agent](../../02/12-real-coding-agents/): the trace model reused here
