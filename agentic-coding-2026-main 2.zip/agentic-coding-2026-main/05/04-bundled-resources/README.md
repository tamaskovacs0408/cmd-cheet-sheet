# 4. Bundled resources

[Topic 3](../03-progressive-disclosure/) introduced Level 3: files that live alongside `SKILL.md` in the skill directory and load on demand. This topic builds them out on the running example and walks through the part of the format that makes skills meaningfully different from a long system prompt.

## The expanded skill directory

A skill is a directory, not a file. Anything else in that directory is available to the model when the skill body references it. Common conventions, settled by `anthropics/skills` and adopted by every public library:

```
~/.claude/skills/bootstrap-project/
├── SKILL.md
├── references/
│   ├── python.md
│   ├── typescript.md
│   └── rust.md
└── scripts/
    ├── init-git.sh
    └── apply-license.sh
```

`references/` holds long-form prose the model reads with `Read`. `scripts/` holds executable code the model runs with `Bash`. The split matters because they have different token economics.

Update `SKILL.md` to point at them:

```markdown
---
name: bootstrap-project
description: Use when the user wants to start a new project from scratch. Sets up README.md, .gitignore, an MIT LICENSE, and an initial commit. Triggers on phrases like "new project", "bootstrap", "scaffold", "set up a repo".
---

When the user asks to bootstrap a new project:

1. Confirm the language. Read the matching reference for language-specific
   defaults: `references/python.md`, `references/typescript.md`, or
   `references/rust.md`.
2. Create `README.md` with a one-paragraph description placeholder.
3. Create `.gitignore` matching the language reference.
4. Run `bash scripts/apply-license.sh "$(git config user.name)"` to drop in
   an MIT LICENSE with the current year.
5. Run `bash scripts/init-git.sh` to configure the local git defaults
   the instructor prefers (commit signing, merge.ff=only, pull.rebase=true)
   and makes the initial commit.
```

The body is still short. The detail lives in the bundled files.

## Two kinds of bundled resource

### References: read into context, cost tokens

`references/python.md` is plain markdown. When the body says *"Read the matching reference,"* the model invokes the `Read` tool, the file contents are added to the conversation as a tool result, and from that point on the reference is in context. It costs tokens.

The win is *which* tokens you pay for. The TypeScript and Rust references contribute zero on a Python bootstrap. A 600-line reference about Django project layouts costs nothing the day the user wants a Flask project until the model reads the *Flask* section.

This is sometimes called the *router pattern*: a small body decides *which* of several long references to load. It is the most common way skills handle a multi-language or multi-framework concern.

### Scripts: executed, cost only their output

`scripts/init-git.sh` is the more interesting case. Watch what happens when the model runs it:

```sh
#!/usr/bin/env bash
set -euo pipefail
git init -q
git config commit.gpgsign true
git config merge.ff only
git config pull.rebase true
git add -A
git commit -q -m "chore: initial commit"
echo "initialized git in $(pwd) with commit-signing on, ff-only merges, rebase pulls"
```

When the model runs `bash scripts/init-git.sh`, the *script source never enters the context window*. Only the script's stdout does; in this case, one line of confirmation. Anthropic's docs are explicit:

> The script's code never loads into the context window. Only the script's output … consumes tokens.

This is the punchline that justifies the file format. You can ship a 200-line bash script, a Python script that hits an API, a Node.js code generator, anything. The source is on disk, the model invokes it via `Bash`, and you pay tokens only for what the script prints. The script becomes a *deterministic capability* the skill body composes against.

A useful mental rule:

> If the work is deterministic, put it in a script. If the work is judgment, put it in `SKILL.md` or in a reference.

Calls to a database, file system manipulations, code generation, and formatting belong in script territory. Deciding *what* to do, in what order, and with what trade-offs belongs in skill-body territory.

## What does this buy you over a long system prompt?

Three things, in order of importance:

1. **Token economics that scale with users.** A user with 30 skills installed pays for the ~30 descriptions at startup, the body of whichever skill activates, and the references the model actually reads. Without scripts and references, every skill's full content would have to live in `SKILL.md` and the math from [topic 3](../03-progressive-disclosure/) gets uglier fast.

2. **Composability and reuse.** `apply-license.sh` is shellable from anywhere: other skills, manual invocations, CI. The procedural knowledge in the script does not have to be re-expressed in markdown for every skill that needs it.

3. **Determinism for the parts that should be deterministic.** Asking the model to "init git with commit signing, ff-only merges, and rebase pulls" works most of the time. Running `bash scripts/init-git.sh` works *every* time. The skill body decides; the script does.

## Demo: count the tokens

The cleanest way to feel the difference is a back-of-the-envelope on a real run. Bootstrap a Python project with the expanded skill above and tally what entered the context window:

| Source | Approx. tokens entering context |
|---|---|
| `bootstrap-project` description (Level 1, always loaded) | ~80 |
| `SKILL.md` body (Level 2, on activation) | ~150 |
| `references/python.md` (Level 3, read by model) | ~600 |
| `references/typescript.md` (not read) | 0 |
| `references/rust.md` (not read) | 0 |
| `scripts/apply-license.sh` source (executed, source not read) | 0 |
| `scripts/apply-license.sh` stdout (one line) | ~20 |
| `scripts/init-git.sh` source (executed, source not read) | 0 |
| `scripts/init-git.sh` stdout (one line) | ~25 |

Total: ~875 tokens for a skill whose full directory is several thousand tokens of content. Switch to TypeScript and the only number that changes is *which* reference is read; the Python reference contributes zero on that run.

## Authoring conventions

Both `anthropics/skills` and `obra/superpowers` (covered in [topic 9](../09-skills-in-the-wild/)) use the same directory shape:

- `SKILL.md`: the entry point. Anthropic's guidance: keep it under 500 lines.
- `references/`: long-form prose loaded on demand.
- `scripts/`: deterministic code, executed not read.
- `assets/`: templates, fonts, icons, anything binary or copied verbatim.

For very large references (the docs suggest > 300 lines), include a table of contents in the file. The model reads the TOC first, decides which section it actually needs, and reads only that.

A common anti-pattern, called out by `obra/superpowers/writing-skills`: *do not* use Claude Code's `@file` syntax to reference bundled files from `SKILL.md`. `@file` force-loads the file into context, defeating progressive disclosure. Use plain prose references the model reads with `Read`.

## Why this matters

The bundled-resources design is what separates a skill from a system-prompt fragment. Without scripts, you would need to write deterministic procedures in markdown and trust the model to execute them. Without references, every multi-variant skill would balloon `SKILL.md`. The whole format is shaped around making *what enters context* a decision the skill author and the model make jointly, on each run.

The trace shape from [topic 2](../02-agent-skills/) becomes more interesting once bundled files exist. Every `Skill` invocation, every `Read` of a reference, and every `Bash` execution of a script shows up as a span in the waterfall.

## Resources

- [Claude Code: Skill content lifecycle and bundled files](https://docs.claude.com/en/docs/claude-code/skills)
- [`anthropics/skills`: `template/` and `skill-creator/`](https://github.com/anthropics/skills): canonical examples of the directory layout
- [`obra/superpowers/skills/writing-skills/SKILL.md`](https://github.com/obra/superpowers/blob/main/skills/writing-skills/SKILL.md): the `@file` anti-pattern and other authoring guidance
