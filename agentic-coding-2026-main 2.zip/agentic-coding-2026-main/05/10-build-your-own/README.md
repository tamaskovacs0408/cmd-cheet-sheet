# 10. Build your own skill

This is the capstone. Everything from [topics 2 through 9](../02-agent-skills/) gets used at least once: the file format, progressive disclosure, bundled scripts and references, advanced frontmatter, the eval loop, the cross-agent port. The goal is to walk through writing a real, useful skill end-to-end in fifteen minutes and to leave with the conviction that you can do it again on Monday.

The example is a `pr-description` skill that writes a PR body from the diff and recent commits, in the team's voice. It is small enough to write in front of you, useful enough that you will actually keep it, and exercises every part of the format. Pick a different pain if you have one; the structure of the walkthrough is the same.

## Step 0: pick a repeated pain

A skill is for procedural work the agent does *sometimes*. The skill format does not pay back for one-off requests. Look for things you do every week or two:

- Writing PR descriptions in a specific format your team uses.
- Triaging a Sentry alert through your team's standard checklist.
- Bumping a CHANGELOG and a version in three places at once.
- Creating a new microservice with the team's standard layout.
- Reviewing for a specific category of bug your team keeps shipping.

Anything that has a *procedure* with *judgement* parts qualifies. If it is purely deterministic ("run these three commands"), make it a script. If it is purely judgement ("what does this code do"), trust the model's general capability. Skills sit in the middle: a procedure with judgement.

We will use **PR descriptions** as the worked example.

## Step 1: scaffold with `skill-creator`

`skill-creator` from [`anthropics/skills`](https://github.com/anthropics/skills/tree/main/skills/skill-creator) ([topic 9](../09-skills-in-the-wild/)) is a meta-skill whose only job is creating other skills. Install it as a personal skill once and you have a `/skill-creator` command available everywhere:

```sh
git clone --depth 1 https://github.com/anthropics/skills /tmp/anthropic-skills
mkdir -p ~/.claude/skills
cp -r /tmp/anthropic-skills/skills/skill-creator ~/.claude/skills/
```

Now in a fresh Claude Code session:

```
> use skill-creator to make a new skill called pr-description that
> writes a PR body from the diff and recent commits in our team's voice
```

`skill-creator` will:

1. Create `~/.claude/skills/pr-description/` with `SKILL.md`, `references/`, `scripts/`, and `evals/` subdirectories.
2. Ask you a few questions: what does the skill do, what is the trigger phrase, who is it for.
3. Generate a starter `SKILL.md` and an `evals/evals.json` skeleton.

Reading that starter is itself a lesson. The frontmatter it generates is *pushy* by default ([topic 7](../07-writing-good-skill/), commandment 2) and the body is structured around references rather than inlined.

## Step 2: write the description (the hardest part)

The starter description from `skill-creator` will be okay but not great. You will rewrite it. Apply the five commandments from [topic 7](../07-writing-good-skill/):

```yaml
---
name: pr-description
description: |
  Use when the user asks to write a PR description, mentions opening a PR,
  or runs `gh pr create`. Generates the PR body from the staged diff and
  recent commits in the team's house style: Summary at the top, Test plan
  as a markdown checklist, Risk callouts at the bottom. Use proactively
  before merging if the current branch has commits ahead of main and no
  PR description exists yet, offer to write one.
---
```

Notice:

- **Trigger keywords** the user might say: "PR description," "open a PR," `gh pr create`.
- **Symptoms** the model can recognise as a match: branch ahead of main, no description yet.
- **Pushy**: explicit instruction to *offer* even without a request.
- **Structure callout**: Summary / Test plan / Risk. The model now knows what shape the body produces, which helps activation when the user says *"can you write the test-plan section?"*, a vague prompt that still needs to match.

This description is ~110 words. The body of the SKILL.md will be much longer; the description is doing the activation work alone.

## Step 3: write the body (short, with most detail in references)

```markdown
When invoked, write the PR description for the current branch.

1. Get the context with `bash scripts/get-context.sh`. This produces:
   - the staged + unstaged diff against the base branch
   - the list of new commits on this branch with messages
   - the touched files grouped by directory
2. Read `references/pr-template.md` for the team's exact template structure.
3. Read `references/voice-guide.md` for the team's voice rules: short
   imperative sentences, no marketing language, no emojis.
4. Generate the description following the template:
   - **Summary**: 1 to 3 bullets explaining *why* this changed, not *what*.
   - **Test plan**: a markdown checklist of how to verify.
   - **Risk callouts**: surface anything the reviewer should pay attention to
     (migrations, behaviour changes, performance trade-offs).
5. Print the description to stdout. Do not run `gh pr create` automatically.
   The user reviews the description and runs the command themselves.
```

The body is under 30 lines. Everything substantive, including the team's exact template and the voice rules, lives in the references.

## Step 4: bundled resources

`scripts/get-context.sh`:

```sh
#!/usr/bin/env bash
set -euo pipefail
BASE=${1:-$(git symbolic-ref refs/remotes/origin/HEAD | sed 's@^refs/remotes/origin/@@')}

echo "## Commits"
git log --oneline "${BASE}..HEAD"
echo
echo "## Touched files"
git diff --name-only "${BASE}...HEAD" | awk -F/ '{print $1"/"$2}' | sort -u
echo
echo "## Diff summary"
git diff --stat "${BASE}...HEAD"
echo
echo "## Full diff"
git diff "${BASE}...HEAD"
```

The script source is ~12 lines. Recall from [topic 4](../04-bundled-resources/) that this source costs zero tokens; only the stdout enters context. For a typical PR, that stdout is a few hundred lines of diff plus a dozen lines of commit summary.

`references/pr-template.md` is the team's exact template with placeholder text, readable in five seconds. `references/voice-guide.md` is a longer style guide; the model reads it on the first invocation and the rules stick for the rest of the session.

## Step 5: validate with the eval loop

When you ask `skill-creator` to validate the new skill, it writes an `evals/evals.json` into your skill directory and runs the harness from its own `scripts/`. A reasonable starter `evals.json` for `pr-description`:

```json
[
  { "prompt": "write the pr description for this branch",
    "should_trigger": "pr-description",
    "assertions": ["produces a Summary section",
                   "produces a Test plan checklist",
                   "produces Risk callouts",
                   "does not run gh pr create"] },
  { "prompt": "open a pr",
    "should_trigger": "pr-description" },
  { "prompt": "what does this function do?",
    "should_trigger": null },
  { "prompt": "review my code",
    "should_trigger": null }
]
```

In Claude Code, ask `skill-creator` to run them:

```
> validate pr-description against evals/evals.json
```

`skill-creator` invokes its own `scripts/run_eval.py` (for trigger-rate measurement) or `scripts/run_loop.py` (for description-tuning iteration), spawns the with-skill / without-skill sub-agent pair from [topic 8](../08-testing-skills/), grades the responses through `agents/grader.md`, and writes `benchmark.json` into your skill directory. Iterate on the description until both *trigger correctly* (PR-related prompts hit, unrelated prompts miss) and *body is correct* (the four assertions pass).

For this first version, the TDD-for-docs methodology from [topic 8](../08-testing-skills/) is also worth running once: in a sub-agent with no skill installed, ask *"write the PR description for this branch."* Watch the model. Note what it gets wrong without your skill; usually it invents a structure, skips the test-plan checklist, or runs `gh pr create` automatically. Each of those is a line of body content.

## Step 6: ship it

The skill is already in `~/.claude/skills/pr-description/` from step 1. It is live. Open Claude Code in any project with an in-progress branch:

```sh
cd ~/code/my-project
claude
> write the pr description for this branch
```

The skill activates. The script runs (its source costs nothing). The references load (the long ones only on first invocation). The model produces the description following the template, in the team's voice, with a test plan and risk callouts.

If someone else on the team should have the same skill, drop it into the project's `.claude/skills/` instead. Now it ships with the repo and everyone running Claude Code from the project root gets it. Recall the override rule from [topic 5](../05-frontmatter-advanced/): a personal skill of the same name will *shadow* the project version, so for a team-shipped skill, name it differently than anything in your personal directory (e.g. `acme-pr-description`).

## Step 7: cross-agent check

If the team uses OpenCode (or Cursor, Cline, Codex), the skill works there too without modification ([topic 6](../06-cross-agent/)). OpenCode reads `.claude/skills/` directly:

```sh
cd ~/code/my-project
opencode
> write the pr description for this branch
```

Same skill. Same broad activation camp: Claude Code uses the `Skill` tool, while OpenCode uses its native `skill` tool. The user-visible behaviour is the same; Codex is the system-prompt-list counterexample from [topic 6](../06-cross-agent/). Claude-Code-specific frontmatter fields (`paths`, `model`, `context: fork`) are ignored without breaking anything, and `allowed-tools` support varies by agent.

## Step 8: maintain it

The skill is committed to your dotfiles or to the repo, like any other code. Treat it that way:

- When the team's PR template changes, update `references/pr-template.md`.
- When the eval-loop's trigger rate drops on a new release of Claude, retune the description.
- When you find yourself writing PR descriptions that the skill should have caught and didn't, add the failing prompt to `evals/evals.json` and rerun.

> A skill is the agent-context analogue of code. It gets committed, reviewed, refactored, and broken by neighbouring changes. The conventions you would apply to a small library, including semantic naming, evals as tests, and version control, are the conventions a skill needs.

## Choose your next twenty

You wrote a skill in fifteen minutes. The skill format is small enough that the next one will take ten. The cost has shifted entirely from *writing* to *choosing*: which procedural pains in your work are worth turning into skills?

A list to seed thinking; every one is a skill someone has shipped publicly:

- `triage-sentry-alert`: read the alert, find the recent deploys, surface suspect commits, write the triage doc.
- `bump-version`: bump the version in `package.json`, the changelog, and the deploy manifest at once.
- `code-review-security`: review a diff for the specific security categories your team has shipped bugs in.
- `release-notes`: generate the changelog entry from commits since the last tag.
- `incident-postmortem`: start a postmortem document from an incident channel link.
- `debug-flaky-test`: systematic procedure for the team's most-common flaky-test patterns.
- `add-feature-flag`: add a flag definition to the right places, with the team's naming convention.

> You wrote a skill in fifteen minutes. You can write twenty. The hard part is choosing which twenty.

## Why this matters

The point of this lecture has been to make the skill format feel routine. It is a YAML header on a markdown file in a directory. The agent decides when to read it. You decide what it says. That entire chain, from writing a description to watching it activate, observing in the trace, porting to another agent, and evolving it with evals, was the loop you have now done end-to-end.

The skills you reach for next are the ones that solve work you actually do. The hardest part of being good at this is not the file format; it is the discipline of [topic 7](../07-writing-good-skill/) (write the description for triggers, not for description), [topic 8](../08-testing-skills/) (test before shipping, against reality not against vibes), and [topic 9](../09-skills-in-the-wild/) (read other people's skills before writing your own).

The rest is repetition.

## Resources

- [`anthropics/skills/skills/skill-creator`](https://github.com/anthropics/skills/tree/main/skills/skill-creator): the meta-skill used in step 1
- [`anthropics/skills/template`](https://github.com/anthropics/skills/tree/main/template): the bare scaffolding without the eval-loop opinions
- [Topic 7: Writing a good skill](../07-writing-good-skill/): the authoring rules applied here
- [Topic 8: Testing and evolving](../08-testing-skills/): the eval-loop and TDD-for-docs methodologies used in step 5
- [Topic 9: Skills in the wild](../09-skills-in-the-wild/): three libraries' worth of reference reading for skill #2 onward
