# 3. Progressive disclosure

[Topic 2](../02-agent-skills/) showed a single skill activating. This topic names the loading model behind that behaviour. If every available skill loaded its full body into the context window at startup, the initial context of any non-trivial setup would be enormous. A working developer with 30 skills installed (a not-unusual count once you start using the public ecosystem from [topic 9](../09-skills-in-the-wild/)) would burn tens of thousands of tokens before typing a single character.

This is the problem skills are designed around. Anthropic calls the design **progressive disclosure**, and the [overview docs](https://docs.claude.com/en/docs/agents-and-tools/agent-skills/overview) state it directly:

> This filesystem-based architecture enables progressive disclosure: Claude loads information in stages as needed, rather than consuming context upfront.

There are three stages. Each one is loaded lazily relative to the one above it.

## The three levels

| Level | What | When loaded | Token weight |
|---|---|---|---|
| 1 | Frontmatter (`name` + `description`) | Always, at agent startup, in model-visible skill metadata | ~100 tokens per skill |
| 2 | The body of `SKILL.md` | When the skill activates | Target < 5,000 tokens |
| 3 | Bundled files in the skill directory | On demand, the model reads them as it needs | Effectively unlimited |

The contract is straightforward: at every step, the agent has just enough information to decide what to do next. It does not need the body to know the skill exists; it does not need the bundled files to follow the procedure unless the procedure tells it to.

### Level 1: frontmatter, always loaded

Every available skill contributes its `name` and `description` to model-visible skill metadata at startup. For our `bootstrap-project` skill from [topic 2](../02-agent-skills/), the skill listing contains, roughly:

```
Available skills:
- bootstrap-project: Use when the user wants to start a new project from
  scratch. Sets up README.md, .gitignore, an MIT LICENSE, and an initial
  commit. Triggers on phrases like "new project", "bootstrap", "scaffold",
  "set up a repo".
```

That is all the model sees. It does not see the procedure body. Its only job at this level is to recognize that an incoming user prompt matches the description.

### Level 2: body, on activation

When the model decides the description matches, it invokes the `Skill` tool with the skill's name. Claude Code reads the body of `SKILL.md` off disk and adds it to the conversation as a tool result. From [Claude Code's lifecycle documentation](https://docs.claude.com/en/docs/claude-code/skills):

> When you or Claude invoke a skill, the rendered SKILL.md content enters the conversation as a single message and stays there for the rest of the session. Claude Code does not re-read the skill file on later turns.

Two consequences worth holding onto:

- A skill body that is 4,000 tokens is *loaded from disk once*. After activation, it sits in the message history like any other message and continues to occupy context on later turns until compaction.
- If you edit a skill mid-session, the change does not reach an already-active skill. You need a fresh session for the new body to load. (Live file-watching applies to Level 1: descriptions are reloaded, but not Level 2 once a skill has been invoked.)

### Level 3: bundled files, on demand

A skill is not just a single file. It is a directory. Anything else in that directory, including markdown references, scripts, and templates, is available to the model via ordinary tool calls (`Read`, `Bash`) when the body of `SKILL.md` mentions them.

Crucially, *those files do not enter context unless the model reads them*. A 600-line reference about Python project layouts costs zero tokens if the user is bootstrapping a TypeScript project. A 200-line shell script that does the actual `git init` only contributes its stdout to the conversation, not its source.

Level 3 is the topic of the next lesson. [Topic 4: bundled resources](../04-bundled-resources/) builds out the `bootstrap-project` skill with real `references/` and `scripts/` subdirectories and walks through what costs tokens and what does not.

## The token math

The reason progressive disclosure matters becomes clear with arithmetic. Imagine a developer with 30 installed skills, each averaging 1,500 tokens of body content.

|  | Without progressive disclosure | With progressive disclosure |
|---|---|---|
| Always-loaded cost | 30 × ~1,600 ≈ 48,000 tokens | 30 × ~100 ≈ 3,000 tokens |
| Cost when one skill activates | Already loaded | ~1,500 tokens added at activation, then retained in history |
| Cost of an unactivated skill | 1,500 tokens, every turn | 0 |

Skills are designed so that you can install many and pay for only the ones you use. Without progressive disclosure, the format would not survive contact with the public ecosystems in [topic 9](../09-skills-in-the-wild/), some of which ship 40+ skills in a single library.

## Verifying it yourself

Claude Code writes every session to `~/.claude/projects/<encoded-cwd>/<session-id>.jsonl`. The first entry is the system prompt; subsequent entries are messages and tool calls.

[Topic 2](../02-agent-skills/) introduced the OTel trace shape. After bundled files and scripts are added, the same trace will include ordinary `Read` and `Bash` spans for those resources.

## Why this matters

Progressive disclosure is the reason the skill format scales. It is also why the design choices in the rest of the lecture make sense. The activation table for `allowed-tools` ([topic 5](../05-frontmatter-advanced/)), the cross-agent split into "tool-mediated vs. prompt/list-mediated" ([topic 6](../06-cross-agent/)), and the authoring rule that descriptions should be triggers and not summaries ([topic 7](../07-writing-good-skill/)) are all shaped by the fact that the description is the only thing the model sees by default. Get the description wrong and the rest of the skill might as well not exist.

> The description is the skill's user interface. Everything else is implementation.

## Resources

- [Agent Skills overview (Anthropic)](https://docs.claude.com/en/docs/agents-and-tools/agent-skills/overview): the canonical statement of the three-level model
- [Claude Code skills documentation](https://docs.claude.com/en/docs/claude-code/skills): the lifecycle quote and the per-session caching behaviour
