# 5. Frontmatter beyond the basics

[Topic 2](../02-agent-skills/) introduced the two required frontmatter fields, `name` and `description`. Everything else is optional, and most of "everything else" is Claude-Code-specific. This topic covers the optional fields you will actually reach for, plus the discovery and override rules that decide *which* version of a skill wins when several are installed.

## Demo: a repo-shared skill

So far `bootstrap-project` has lived at `~/.claude/skills/bootstrap-project/`. That makes it personal: available in every project on your machine, but not visible to teammates working on the same repo.

The other side of this is **repo-shared skills**, which live in `.claude/skills/<skill-name>/SKILL.md` *inside the project*. They ship with the repo, are picked up automatically when anyone runs Claude Code from the project root, and version with the code.

For a worked example, create a sibling skill alongside the personal one. Same shape, but tuned to a team's service-scaffolding conventions:

```
demo-repo/
└── .claude/
    └── skills/
        └── bootstrap-service/
            └── SKILL.md
```

```yaml
---
name: bootstrap-service
description: Use when the user wants to scaffold a new microservice in this monorepo. Creates the standard service layout, Dockerfile, CI config, and deploy manifest matching the team's conventions. Triggers on phrases like "new service", "scaffold a service", "add a microservice".
allowed-tools:
  - Bash(git init)
  - Bash(uv init *)
  - Bash(npm init *)
argument-hint: <service-name>
paths:
  - "services/**"
model: claude-sonnet-4-6
---

When the user asks to scaffold a new service:

1. Confirm the language. Read `references/<lang>.md` for the team layout.
2. Create `services/<service-name>/` with the team's standard subtree.
3. Drop in the team `Dockerfile` and `.github/workflows/<service>.yml`.
4. Run `bash scripts/register-service.sh <service-name>` to add the service
   to the deploy manifest.
```

The body is short. The new content is in the frontmatter. We will walk it field by field.

## The fields you will actually use

### `allowed-tools`: pre-approval, not a sandbox

This is the field most people misread. The name suggests a sandbox: *only the listed tools are usable while the skill is active.* That is wrong. Quote the [docs](https://docs.claude.com/en/docs/claude-code/skills) verbatim:

> The `allowed-tools` field grants permission for the listed tools while the skill is active, so Claude can use them without prompting you for approval. **It does not restrict which tools are available**: every tool remains callable, and your permission settings still govern tools that are not listed.
>
> To block a skill from using certain tools, add deny rules in your permission settings instead.

It is a *pre-approval list*, not a restriction. The model can still call any tool; the listed ones simply do not trigger an interactive permission prompt.

Two consequences:

- **For UX**, list the tools the skill needs to invoke without breaking flow. The example above pre-approves `git init` and `uv init` / `npm init` so scaffolding does not stop on every command.
- **For security**, do not rely on `allowed-tools` to keep a skill from doing something. If you want a tool blocked, write a deny rule in the project or user `permissions` settings.

The syntax accepts a tool name (`Read`, `Bash`), a name with a wildcard pattern (`Bash(git diff *)`), or a YAML list of either.

### `paths`: gate activation by file glob

The `paths` field restricts when a skill is offered to the model. The skill's description is included in model-visible skill metadata only when the agent is operating on files matching at least one of the listed globs.

```yaml
paths:
  - "services/**"
```

`bootstrap-service` is now invisible from the description listing unless the conversation involves files under `services/`. Personal skills with no `paths` field stay always-discoverable; this is for repo-shared skills that should not pollute the description budget on unrelated work.

### `disable-model-invocation`: user-only skills

Set `disable-model-invocation: true` to tell Claude Code that this skill is intended for human invocation only. The `description` is *not* loaded into model-visible skill metadata at startup, so the model does not know the skill exists. The user can still invoke it with `/skill-name`.

Use this for procedures that should only fire on explicit human request: anything destructive, expensive, or with side effects you want a human to think about. `gstack/ship` and `gstack/land-and-deploy` ([topic 9](../09-skills-in-the-wild/)) use this.

### `user-invocable`: model-only skills (the inverse)

The opposite of the previous field. `user-invocable: false` hides the skill from the user's `/` menu. The model can still invoke it.

Useful for sub-procedures that are meant to be called by other skills, not by humans directly. Most well-organised skill libraries use this to keep the user's `/` menu uncluttered.

(Note: this only *hides*; it does not *block*. A user who knows the skill name can still invoke it programmatically.)

### `model` and `effort`: per-skill compute

```yaml
model: claude-opus-4-7
effort: high
```

Pin a different model or thinking budget for the duration of the skill. The default is whatever the user is running Claude Code with. Use this for skills where the cost-quality trade-off is *known* to be different: security review and architecture planning typically want Opus and high effort; a `bootstrap-project` does not.

Setting `model` per skill avoids the alternative of "always run Claude Code on Opus to be safe," which is expensive on the 95% of work that does not need it.

### `context: fork`: isolated subcontext

```yaml
context: fork
```

When set, the skill runs in a forked subagent context that does not pollute the main conversation. The subagent receives the skill content as its task and still has normal project context such as `CLAUDE.md`, but it does not inherit the parent conversation history. The body, script outputs, and intermediate reasoning stay out of the parent message history; only the returned summary comes back.

This is useful for long, exploratory skills (e.g. a multi-step debugging session) whose intermediate noise would derail the parent conversation. `obra/superpowers/dispatching-parallel-agents` is built on this primitive.

### A few more, in passing

- **`argument-hint`**: a short hint shown in Claude Code's UI when the user types `/skill-name`. Purely cosmetic.
- **`arguments`**: a structured list of named arguments substituted into the body via `${ARG_NAME}`. Useful when the user is expected to invoke the skill via `/skill-name <args>`.
- **`hooks`**: settings.json-style hook overrides scoped to the skill's invocation. Rarely used.
- **`shell`**: `bash` or `powershell`. Affects how Claude Code preprocesses inline shell substitutions in the body. Defaults are correct for almost everyone.

## Discovery and overrides

Now there are two `bootstrap-*` skills installed: a personal one in `~/.claude/skills/`, a repo-shared one in `.claude/skills/`. Run Claude Code from the demo repo and both descriptions appear in the listing.

What if they had the same `name`? Most people will guess the project version wins because it is more specific. They are wrong.

The Claude Code [docs](https://docs.claude.com/en/docs/claude-code/skills) state the order:

> When skills share the same name across levels, enterprise overrides personal, and personal overrides project.

The reasoning Anthropic implies: enterprise admins enforce policy and must win; the user's own preferences trump the project default *on their own machine*; the project is the floor. Practically, this means a personal `bootstrap-project` will silently shadow a same-named project skill, a footgun if you don't know to look.

> The project is the floor, not the ceiling. If you want it to win, name it differently.

Plugin skills sidestep the conflict entirely because they are namespaced as `<plugin-name>:<skill-name>`. A `superpowers:writing-plans` skill cannot collide with a personal `writing-plans` skill because Claude Code treats them as different identifiers.

A summary of the loadable scopes:

| Scope | Path | Visibility | Override rank |
|---|---|---|---|
| Enterprise | managed settings (admin-controlled) | All users in the org | Highest |
| Personal | `~/.claude/skills/<name>/SKILL.md` | All your projects | Above project |
| Project | `.claude/skills/<name>/SKILL.md` | This project | Lowest |
| Plugin | `<plugin>/skills/<name>/SKILL.md` | Where plugin is enabled | Namespaced, does not conflict |

Nested `.claude/skills/` directories inside a monorepo are auto-discovered when working in those subpaths. `--add-dir` extra directories also have their `.claude/skills/` loaded; the docs note this as an explicit exception to the usual `--add-dir` rules.

## Why this matters

The optional fields are where Claude Code extends the portable core at [agentskills.io](https://agentskills.io). The spec covers `name`, `description`, metadata fields, and experimental `allowed-tools`; that is what cross-agent compatibility ([topic 6](../06-cross-agent/)) is built on. Everything else in this topic, including `paths`, `model`, `effort`, `context: fork`, and `hooks`, is Claude-Code-specific. They do not break the file's portability (other agents simply ignore unknown frontmatter), but they do not survive the trip either. Even `allowed-tools` is only portable as a field name; support and semantics vary by agent. A skill that depends on `paths` to keep its description out of Claude Code's model-visible skill metadata will get its description loaded everywhere on OpenCode.

The override-order rule is the highest-leverage piece of trivia in this lecture. It is buried in the docs, contradicts most engineers' intuitions, and is the cause of "why isn't my skill firing" questions whose answer is "your personal skill of the same name is shadowing it."

## Resources

- [Claude Code skills: frontmatter reference](https://docs.claude.com/en/docs/claude-code/skills): the full list of supported fields
- [Claude Code permissions](https://docs.claude.com/en/docs/claude-code/iam): for the deny-rule alternative to `allowed-tools` "restriction"
- [Topic 6: Same file, different activation](../06-cross-agent/): which of these fields survive a port to OpenCode and which do not
