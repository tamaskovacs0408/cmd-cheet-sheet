{ pkgs, ... }:

{
  dotenv.enable = true;

  packages = with pkgs; [
    jq
    fx
  ];

  languages = {
    python = {
      enable = true;

      uv.enable = true;
      venv.enable = true;
    };

    javascript = {
      enable = true;

      bun.enable = true;
    };
  };
}
