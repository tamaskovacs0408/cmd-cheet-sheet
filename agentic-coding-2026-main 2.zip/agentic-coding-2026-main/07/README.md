# Lecture 7: Multi-Agent Architecture in Claude Code

## Overview

By now you have a single agent that knows your project ([Lecture 4](../04/README.md)), reaches for the right procedure on its own ([Lecture 5](../05/README.md)), and talks to your warehouse, your tracker, and your deploy tool through MCP ([Lecture 6](../06/README.md)). For most tasks that is enough. For some it is not.

The work that breaks single-agent setups is not harder code; it is *coordination*. A long debugging session runs out of context window before the bug is reproduced. A planner that also implements skips the parts of the plan it found inconvenient. A reviewer who watched the implementer write the code reviews their own assumptions. Eight hypothesis branches that each take three minutes to investigate get explored serially over twenty-four minutes. Specialization, parallelism, role separation, and context isolation are the four reasons to introduce a second agent, and Claude Code gives you the primitives to do it.

This lecture is about those primitives and the patterns that use them. We start with where the single-agent wall actually shows up. We move to subagent mechanics — the `Task` tool, the `.claude/agents/` directory, the frontmatter — and to the most under-appreciated benefit, context isolation. We walk the four orchestration patterns from Anthropic's *Building Effective Agents* and instantiate each one as concrete Claude Code subagents. We spend extra time on reviewer loops, the pattern most likely to ship value the same week. We tie subagents back to skills and MCP from lectures 5 and 6 — what changes when a specialist has its own narrow tool list. Then a dedicated section on when *not* to reach for multi-agent: the overhead, the debugging cost, the fragmentation traps. 

## Learning Objectives

By the end of this lecture, you will be able to:

- Recognize the four pressures that break single-agent workflows and decide which (if any) apply to a given task
- Define a custom subagent in `.claude/agents/`, including frontmatter, tool restrictions, and system prompt, and predict how the orchestrator will route to it
- Explain context isolation, including what the parent sees, what the subagent sees, and what gets lost between them
- Pick the right pattern (orchestrator–worker, evaluator–optimizer, parallel exploration, hierarchical delegation) for a task and wire it up in Claude Code
- Build a reviewer loop with sensible iteration budgets and avoid the rubber-stamp failure mode
- Compose a subagent with skills (Lecture 5) and MCP servers (Lecture 6) so the specialist sees only the playbook and tools it needs
- Identify the cases where a single well-prompted agent beats a multi-agent pipeline, and resist over-engineering
- Build, run, and debug a three-agent planner → implementer → reviewer pipeline end-to-end

## Topics

### 1. [The single-agent wall](./01-single-agent-wall/)

Where one agent stops being enough: context pressure, role confusion, missed parallelism, diluted specialization. Four pressures, and how each one motivates a specific multi-agent pattern.

### 2. [Subagent mechanics](./02-subagent-mechanics/)

The primitives, not the theory. The `Task` tool, the built-in subagent types, the `.claude/agents/` directory, the frontmatter fields, and what an actual delegation trace looks like.

### 3. [Context isolation](./03-context-isolation/)

The killer feature most people miss. Why "send Explore to grep" beats grepping yourself. What the parent sees, what the subagent sees, and the summary tax you pay for the isolation.

### 4. [Orchestration patterns](./04-orchestration-patterns/)

Four patterns from *Building Effective Agents*, each with a Claude Code wiring sketch: orchestrator–worker, evaluator–optimizer, parallel exploration, hierarchical delegation.

### 5. [Reviewer loops in practice](./05-reviewer-loops/)

The pattern most likely to pay back the same week. Built-in `/review`, `/security-review`, `/ultrareview`. Writing custom reviewer subagents. Iteration budgets. The rubber-stamp anti-pattern.

### 6. [Skill and MCP composition](./06-skill-mcp-composition/)

Subagents inherit skills and can be scoped to specific MCP servers. A `db-schema-explorer` with only the Postgres MCP. A `security-reviewer` restricted to read-only tools. The composition rules from Lectures 5 and 6, applied.

### 7. [When not to use multi-agent](./07-anti-patterns/)

A dedicated section, not a footnote. Coordination overhead, debugging cost, context fragmentation, the agents-all-the-way-down trap. A heuristic for when the wall is real, and a side-by-side comparison of one-agent vs. four-agent on the same task.

### 8. [Capstone lab: build the pipeline](./08-pipeline-lab/)

Forty-five minutes. A starter repo, three subagent stubs, a `TASK.md` describing the change. You write the system prompts, wire up the reviewer loop, run it, and watch the iteration. Then you break it on purpose to feel where pipelines fail.

## What this lecture deliberately does *not* cover

These belong elsewhere in the course:

- Headless mode (`-p`), GitHub Actions, CI integration → [Lecture 8](../08/README.md)
- Continuous and scheduled agent loops → [Lecture 8](../08/README.md)
- Sandboxing and the agentic security threat model → [Lecture 8](../08/README.md)
- Building a custom agent loop with the Agent SDK from scratch → already in [Lecture 2](../02/README.md)
- Survey of cloud agent products (Cursor background agents, Devin, Codex Cloud) → mentioned in [Lecture 3](../03/README.md)

The pattern: this lecture is about *coordination interactively, on your machine*. Lecture 8 is about *automating that coordination in production*.

## Further Reading

Cross-cutting references that span multiple topics. Topic-specific links live in each topic's own README.

Primary sources:

- [Anthropic Engineering: Building effective agents](https://www.anthropic.com/research/building-effective-agents) — the four-pattern taxonomy this lecture instantiates
- [Claude Code subagents documentation](https://docs.claude.com/en/docs/claude-code/sub-agents) — the official reference for `.claude/agents/`
- [Claude Code: How we built our multi-agent research system](https://www.anthropic.com/engineering/built-multi-agent-research-system) — Anthropic's own multi-agent retrospective
- [Skills explained: Skills vs prompts, Projects, MCP, and subagents](https://claude.com/blog/skills-explained) — how the four primitives compose

Companion lectures:

- [Lecture 2: From Text Completion to Agents](../02/README.md) — the agent loop these subagents are instances of
- [Lecture 5: Agent Skills](../05/README.md) — what specialists carry as their playbook
- [Lecture 6: MCP](../06/README.md) — what specialists reach out to
- [Lecture 8: Autonomous Coding Systems](../08/README.md) — what you build *on top of* a working multi-agent design

Public examples to read:

- `[obra/superpowers/skills/subagent-driven-development](https://github.com/obra/superpowers)` — a meta-skill encoding when to delegate
- `[obra/superpowers/skills/dispatching-parallel-agents](https://github.com/obra/superpowers)` — the parallel-exploration pattern as a skill
- `[anthropics/skills](https://github.com/anthropics/skills)` — official patterns referenced throughout

Commentary worth reading:

- [Simon Willison: Claude Code subagents notes](https://simonwillison.net/) — practical observations on when subagents help and when they get in the way
- [Cognition: Don't build multi-agents](https://cognition.ai/blog/dont-build-multi-agents) — the contrarian read; lecture 7's anti-patterns section engages with it directly

