# 1. The single-agent wall

Most of the time, one agent with good context is enough. The point of [Lecture 4](../../04/README.md) was to get that one agent to behave: clear `CLAUDE.md`, the right rules, plan mode for non-trivial work. The point of [Lecture 5](../../05/README.md) was to teach it the procedures it does not do well from raw capability. The point of [Lecture 6](../../06/README.md) was to give it hands and eyes outside the repo. After all three, the agent in front of you is a competent solo engineer for most of what you ask it.

Where does that solo engineer start to break down? Four places. Knowing which one you have hit tells you which multi-agent pattern to reach for, and the rest of the lecture is organized around them.

## Pressure 1: context window

The cleanest failure mode. A single Claude Code session has a finite context window. Long debugging runs, big codebase tours, and noisy tool outputs all eat it. By turn forty of a hard bug hunt, half your window is full of prior `grep` output, half-rejected hypotheses, and stack traces from runs you have already discarded. Two things go wrong at once:

- The information density of the window drops. The model is reading more, but most of what it reads is no longer load-bearing.
- The recent, high-signal turns get crowded by old, low-signal ones. Even when the right hypothesis is in the window, it competes with twelve wrong ones.

You feel this as the agent "getting tired" or "going in circles." The diagnosis is mechanical: the window has accumulated debt, and the model cannot pay it down without forgetting something.

The pattern that solves it is **context isolation through subagents** ([topic 3](../03-context-isolation/)). Send a fresh agent to do the noisy work — grep the repo, read the eighty matching files, read the test logs — and have it return only the answer. The parent's window stays clean.

## Pressure 2: role confusion

A single agent that plans, implements, and reviews has a structural problem: at the review step, it has just spent thirty turns convincing itself that the implementation is correct. Asking it to find the flaw is asking it to disagree with its own working memory.

The model can do this in principle. In practice, the planning context biases the implementation, the implementation context biases the review, and the agent ends every loop confident in its own work. You see it in:

- Tests that the agent writes *and* declares passing without actually running them.
- Plans the agent declares "complete" while skipping the awkward steps.
- Reviews that summarize what was implemented instead of finding what is wrong with it.

This is not a sloppy-prompt problem. It is a same-context problem. A reviewer with the implementer's working memory inherits the implementer's blind spots.

The pattern that solves it is the **evaluator–optimizer loop** ([topic 4](../04-orchestration-patterns/), [topic 5](../05-reviewer-loops/)). A reviewer subagent that did not see the implementation happen reads the diff fresh. It does not know which trade-offs the implementer rationalized; it only sees the result.

## Pressure 3: missed parallelism

Some tasks are embarrassingly parallel. "Investigate which of these five hypotheses explains the bug." "Search for prior art across these four directories." "Try the migration four ways and compare." A single agent does these serially because that is the only thing a single agent can do. Eight parallel two-minute investigations become a sixteen-minute serial chain that exhausts the context window halfway through.

The cost is not just latency. The serial chain biases later branches with the results of earlier ones. The fourth hypothesis gets a less honest look than the first because the agent has built up commitments along the way.

The pattern that solves it is **parallel exploration** ([topic 4](../04-orchestration-patterns/)). N independent subagents, each with the same prompt and a different hypothesis, return their results to the parent, which picks the winner. Cheap, fast, and unbiased between branches.

## Pressure 4: diluted specialization

A single agent's system prompt has to cover everything the agent might do. The result is a prompt where every concern is mentioned briefly and none is mentioned forcefully. A "security reviewer" that is also a UX reviewer that is also a performance reviewer reviews none of them well.

You can patch this with skills ([Lecture 5](../../05/README.md)) — let the agent reach for a focused playbook on demand. That works for procedures the agent invokes deliberately. It works less well for cross-cutting *postures*: how to read code adversarially, how to ignore the implementer's explanation and look only at the diff, how to assume malice. Postures want their own context, not just their own playbook.

The pattern that solves it is **role-based subagents** ([topic 2](../02-subagent-mechanics/), [topic 6](../06-skill-mcp-composition/)). A `security-reviewer` subagent has a system prompt that is *only* about security review. Its tool list is `Read` and `Grep`. Its skills are exactly the ones a security reviewer needs. The dilution is gone because the context was never crowded in the first place.

## Mapping pressures to patterns

The rest of this lecture maps onto these four pressures:

| Pressure | Pattern | Topic |
|---|---|---|
| Context window | Context isolation | [3](../03-context-isolation/) |
| Role confusion | Evaluator–optimizer (reviewer loop) | [4](../04-orchestration-patterns/), [5](../05-reviewer-loops/) |
| Missed parallelism | Parallel exploration | [4](../04-orchestration-patterns/) |
| Diluted specialization | Role-based subagents | [2](../02-subagent-mechanics/), [6](../06-skill-mcp-composition/) |

If your task does not exhibit any of these four, you do not have a multi-agent problem. You have a single-agent problem that wants better context, a better skill, or a better prompt. [Topic 7](../07-anti-patterns/) is about resisting the temptation to reach for orchestration when none of the four pressures actually apply.

## Live demo: feel the four pressures in 90 seconds

**Setup**: open Claude Code in this course's repo (`agentic-coding-2026/`). Fresh session — `/clear` first so the context indicator starts near zero.

**Live actions** (instructor types into Claude Code, in order):

1. `/context` — show the indicator at baseline. Note the percent.
2. `/agents` — pop the agent picker. Point at the built-in `general-purpose` and `Explore` agents. Close without selecting.
3. Prompt: `read every README under 07/ and summarise the four pressures, then read every README under 05/ and summarise the eight skill topics, then do the same for 06/.`
4. Let it run for ~30 seconds, then interrupt with Esc.
5. `/context` again.

**What to highlight**: the indicator jump after the bulk-read. Open one of the trace entries and show how much of the window is now full of README bodies the parent will not consult again. This is **Pressure 1** in real time — the same window that was load-bearing 30 seconds ago now has megabytes of low-signal text crowding the recent turns.

**The aha**: "half my context is gone, and I haven't made a single decision yet." Every pattern in the rest of the lecture is a way to do that read in *somebody else's* window.

## A diagnostic for the next time you reach for multi-agent

Before you write a `.claude/agents/` file, answer these in one sentence each:

1. Is the parent's context running out, or am I just dissatisfied with how the work is going? (If the latter: better prompt or better skill, not a subagent.)
2. Is there a step where I want a clean reader who did not watch the implementation happen? (If yes: reviewer.)
3. Are there genuinely independent branches I can run at once? (If yes: parallel.)
4. Is the work inside one specialized posture for long enough to justify a dedicated system prompt? (If yes: role-based subagent.)

If you cannot answer "yes" to at least one, the multi-agent pipeline is going to make the work worse, not better. We will return to this diagnostic in [topic 7](../07-anti-patterns/) with measurements.

## Resources

- [Anthropic Engineering: Building effective agents](https://www.anthropic.com/research/building-effective-agents) — the source for the four-pattern taxonomy
- [Anthropic Engineering: How we built our multi-agent research system](https://www.anthropic.com/engineering/built-multi-agent-research-system) — what the four pressures look like at scale
- [Lecture 4](../../04/README.md) — the single-agent context engineering this topic builds on
