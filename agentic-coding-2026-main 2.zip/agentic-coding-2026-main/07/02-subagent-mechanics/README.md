# 2. Subagent mechanics

A subagent in Claude Code is a fresh agent loop, spawned by the parent through the `Task` tool, with its own system prompt, its own tool list, and its own context window. When it finishes, it returns one message to the parent — a summary of what it did. That message goes into the parent's context. The subagent's own turns, tool outputs, and intermediate reasoning do not.

That single sentence is the whole mental model. The rest of this topic is the file format, the wiring, and what you actually see in the trace.

## Built-in subagent types

Claude Code ships with a handful of built-in subagents you can call without writing a file:

- `general-purpose`: a fresh agent with the default toolset. Use for open-ended multi-step tasks where you want isolation but not a specialized prompt.
- `Explore`: read-only search agent for locating code. Optimized for "where is X defined" and "what files reference Y." Cannot edit.
- `Plan`: software-architect agent for designing implementation plans. Returns step-by-step plans, not code changes.
- `statusline-setup`, `output-style-setup`, and a few others: niche helpers. Read the bundled list with `/agents`.

The orchestrator routes to one of these by the `subagent_type` argument when calling the `Task` tool. From the parent's prompt:

> Send an Explore agent to find all places that read from `os.environ` and report a list of files with line numbers.

Under the hood, that is a `Task(subagent_type: "Explore", prompt: "find all places…")`. The parent gets back a summary; it does not get back the raw `grep` output the Explore agent saw.

The built-ins cover most of what people need. Custom subagents are for when you have a *role* you reach for repeatedly — `security-reviewer`, `migration-checker`, `api-contract-validator` — and want it to live as a definition rather than as a prompt you re-paste.

## Custom subagents: the `.claude/agents/` directory

A custom subagent is a single markdown file with YAML frontmatter, just like a skill. It lives in one of three places:

- `.claude/agents/<name>.md` — project-shared, committed to the repo
- `~/.claude/agents/<name>.md` — personal, available everywhere you run Claude Code
- `<enterprise>/agents/<name>.md` — enterprise-distributed (precedence: enterprise > personal > project)

A minimal definition:

```markdown
---
name: security-reviewer
description: Use when reviewing a diff for security issues. Triggered by "security review", "check for vulnerabilities", or before any auth-related merge.
tools: Read, Grep, Glob, Bash
model: sonnet
---

You are a security reviewer. You read code adversarially and assume the worst about untrusted input.

For each diff you review, check:

1. Input validation on every external boundary (HTTP params, headers, env vars, file uploads).
2. SQL/command injection: any string concatenation into a query or shell command.
3. Authentication/authorization: who can call this code path, and was that intentional?
4. Secrets in logs, error messages, or response bodies.
5. Cryptographic primitives: any rolled-your-own crypto, weak hashes, missing constant-time compares.

Return a structured report:

- **PASS** or **FAIL** at the top.
- For each finding: severity (HIGH/MEDIUM/LOW), file:line, the issue in one sentence, the fix in one sentence.
- If PASS, list what you checked so the orchestrator knows what coverage you provided.

Do not fix the issues. Reviewing and fixing in the same agent collapses back into the role-confusion problem.
```

That file is the subagent. It has the same shape as a `SKILL.md` from [Lecture 5](../../05/README.md): YAML frontmatter for activation and metadata, markdown body as system prompt. The semantic difference is that a skill is a procedure the *current* agent runs; a subagent is a procedure run by a *fresh* agent the current one spawns.

## Frontmatter fields

| Field | Required | Purpose |
|---|---|---|
| `name` | yes | Identifier the parent uses to invoke. Lowercase, hyphenated, no spaces. |
| `description` | yes | Activation text. The orchestrator reads this to decide when to delegate. Same authoring rules as skills ([Lecture 5, topic 7](../../05/07-writing-good-skill/)): trigger on "use when…", be specific, list keywords. |
| `tools` | no | Comma-separated tool allowlist. If omitted, the subagent inherits the parent's tools. Restrict aggressively — a security reviewer with `Edit` is a foot-gun. |
| `model` | no | Override the default model (`sonnet`, `haiku`, `opus`). Use a faster model for narrow tasks (`haiku` for trivial reviewers); use the default for substantive work. |

The two that matter most are `description` and `tools`. The first decides whether the orchestrator picks your subagent at all; the second decides how much damage a confused subagent can do.

## Reading a delegation trace

What the parent sees, in order:

1. The parent decides to delegate. In the trace this is a tool call: `Task(subagent_type: "security-reviewer", prompt: "review the staged diff for HTTP-input issues")`.
2. The subagent runs in a fresh context. The trace shows its turns indented or in a separate panel depending on your viewer. The subagent's tool calls (`Read`, `Grep`) and their outputs appear *in the subagent's context only*.
3. The subagent returns a final message: its `PASS/FAIL` report.
4. That final message appears in the parent's context as the tool result of the `Task` call. Nothing else from the subagent's run does.

This is the whole reason context isolation works ([topic 3](../03-context-isolation/)): the parent never paid the token cost of the subagent's investigation.

It is also the source of the most common subagent bug: the subagent did good work but reported it badly. The parent has only the summary. If the summary is vague, the parent cannot recover the detail without re-running the subagent. That is why you write the system prompt to be explicit about what to return — see the structured report instruction in the example above.

## How the orchestrator decides to delegate

Same mechanism as skills: the orchestrator has the descriptions of available subagents loaded, and matches the user's prompt against them. Three things drive whether your subagent gets picked:

- **Description quality**: vague descriptions lose. "Reviews code for issues" loses to "Use when reviewing a diff for security issues — triggered by 'security review', 'check for vulnerabilities', or before any auth-related merge." The same authoring discipline from [Lecture 5, topic 7](../../05/07-writing-good-skill/) applies verbatim.
- **Explicit user request**: "use the security-reviewer subagent on this diff" forces the route. Useful for testing.
- **Orchestrator prompt engineering**: in a custom orchestrator setup ([topic 4](../04-orchestration-patterns/)), the parent's own system prompt can mandate the route ("after every implementation step, dispatch the reviewer").

If your subagent is not getting picked when you expect it to, fix the description first. It is almost always the description.

## A live demo to run

Put this in `.claude/agents/explorer-with-tally.md`:

```markdown
---
name: explorer-with-tally
description: Use when asked to count how many places a name is referenced. Searches the repo, counts hits, and returns only the count plus a short list of file:line references — never the full grep output.
tools: Read, Grep, Glob
---

You are a counter. The user wants to know how many times a name appears in the repo.

1. Use Grep to find all occurrences of the name.
2. Count them.
3. Return:
   - Total count on the first line.
   - Up to ten file:line references, one per line.
   - Nothing else. No commentary, no analysis, no diff opinions.
```

Then in Claude Code, ask:

> count how many times `os.getenv` is referenced in the repo

You should see the orchestrator pick `explorer-with-tally`, the subagent run `Grep`, and a single short answer come back. Open the trace and notice that the parent's context contains only the counter's summary, not the dozens of grep hits the subagent saw. That is the picture in your head for the rest of the lecture.

## What changes vs. a skill

A skill ([Lecture 5](../../05/README.md)) is a procedure the *current* agent reads and follows. The current agent's context is what runs the procedure. A subagent is a procedure run *somewhere else*, in a fresh context, with its own tools.

| Property | Skill | Subagent |
|---|---|---|
| Where it runs | Current agent | New agent, fresh context |
| Tool permissions | Inherits caller's allowed tools (mostly) | Defined per subagent |
| Model | Inherits caller's model | Can override |
| Token cost in caller | Body + bundled resources read | One summary message |
| Returns | Whatever the agent does next | A single final message |

You will see in [topic 6](../06-skill-mcp-composition/) that these compose. A subagent can have its own skills loaded, its own MCP servers connected, its own tool restrictions, and a different model — all selectable per role.

## Resources

- [Claude Code subagents documentation](https://docs.claude.com/en/docs/claude-code/sub-agents) — official reference
- [Lecture 2, topic 12: real coding agents](../../02/12-real-coding-agents/) — for the trace-reading approach this topic relies on
- [Lecture 5, topic 7: writing a good skill](../../05/07-writing-good-skill/) — the description authoring rules apply to subagents verbatim
