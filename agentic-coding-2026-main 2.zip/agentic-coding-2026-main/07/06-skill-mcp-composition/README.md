# 6. Skill and MCP composition

Subagents do not exist in isolation. They live in projects that already have skills ([Lecture 5](../../05/README.md)) and MCP servers ([Lecture 6](../../06/README.md)) configured. The interesting question is how those three primitives compose: which skills does a subagent see, which MCP servers does it have access to, and how do you scope each one so a specialist sees exactly the playbook and tools its job requires.

## The composition rules

Three primitives. Each is independently scoped. The intersection is what the subagent actually has.

| Primitive | Scope mechanism | Default for subagent |
|---|---|---|
| Tools (`Read`, `Edit`, `Bash`, …) | `tools:` field in agent frontmatter | Inherits parent's allowed tools if omitted |
| Skills | Skill activation rules; subagent invokes skills like any other agent | All skills available to the parent |
| MCP servers | Server is configured at the Claude Code level; tool allowlist filters which MCP tools are visible | All MCP tools the parent has, unless `tools:` filters |

The mental model: a subagent is a fresh agent that starts with a copy of the parent's available capabilities, then narrows that down via its own `tools:` allowlist and its own system prompt. It does not start broader than the parent; it can only equal or narrow.

## Scoping with `tools:`

The `tools:` field in the agent frontmatter is the primary lever. It accepts a comma-separated allowlist:

```yaml
---
name: db-schema-explorer
description: Use when the user asks about the database schema or wants to understand existing tables, columns, indexes, or relationships. Read-only.
tools: Read, Grep, Glob, mcp__postgres__query, mcp__postgres__list_tables
---
```

The `mcp__postgres__*` entries are MCP tool names with the `mcp__<server>__<tool>` convention. By listing two specific Postgres MCP tools and *not* listing any other MCP tools, this subagent has access only to the schema-introspection subset, even if the project also has a Slack MCP, a GitHub MCP, and a writeable Postgres MCP tool configured.

This is the model: skills tell the subagent *what to do*, the system prompt tells it *how to do it*, and `tools:` constrains *what it is even capable of doing*. A reviewer with `tools: Read, Grep` cannot edit code even if it tried. That is a feature.

## Three composition patterns worth knowing

### Pattern A: subagent + one MCP server, narrowly scoped

The most common useful composition. A specialist subagent that interacts with one external system, with the rest of the project's MCP servers invisible to it.

```yaml
---
name: warehouse-explorer
description: Use when the user wants to investigate data in the warehouse — checking record counts, exploring distributions, validating data quality. Read-only against the analytics warehouse.
tools: mcp__bigquery__query, mcp__bigquery__list_datasets, mcp__bigquery__describe_table
model: sonnet
---

You answer questions about data in the analytics warehouse.

You can run queries, but you must:
- Never run a query without a LIMIT.
- Never run a query that would scan more than 10GB (check with EXPLAIN first).
- Never write, update, or delete. The MCP tools are read-only by configuration; this is your reminder that the *posture* is read-only too.

Return: the user's question restated, the query you ran, a short summary of the result, and the result table itself.
```

Notice this subagent has *no* `Bash`, *no* `Read`, *no* `Edit`. It cannot read the local repo. It is a pure data-warehouse interface. That is exactly the point — when the user asks "how many users signed up last week," the orchestrator routes to this subagent, the warehouse query happens, the answer comes back, and the parent's context is not polluted with code-reading or local-file-traversal turns it did not need.

### Pattern B: subagent + skills, with tool restriction

When the subagent's posture lives in a skill but the role wants tighter tool scoping than the parent provides.

```yaml
---
name: pr-author
description: Use when the user asks to write a PR description, mentions opening a PR, or runs `gh pr create`. Reads the diff and writes the PR body in the team's voice.
tools: Read, Bash, Grep, Glob
---

When invoked, follow the `pr-description` skill (Lecture 5, topic 10) exactly.

Constraints particular to this subagent:
- Never run `gh pr create` yourself. Output the description; the user runs the command.
- Never include emojis or marketing language even if the diff looks "exciting."
```

The skill carries the procedure. The subagent provides the role separation (so the parent's context is not consumed by reading the full diff) and a tighter tool scope (no `Edit` — the PR-author should never modify files). Skills are inherited; you do not need to "install" them per subagent.

### Pattern C: subagent + custom MCP server-only allowlist

When the project has many MCP servers and you want this subagent locked to one of them.

```yaml
---
name: incident-triage
description: Use when investigating a production incident. Searches Sentry for related errors, checks recent deploys, and writes an incident summary.
tools: mcp__sentry__search_issues, mcp__sentry__get_issue, mcp__github__list_commits, Read, Grep
---

You triage production incidents. For each incident:

1. Use Sentry MCP to find the issue.
2. Use GitHub MCP to find the recent deploys (last 24h).
3. Read the suspect files locally (Read, Grep) to identify the likely change.
4. Write an incident summary: time, blast radius, suspect commit, suggested rollback.

Do not write code. Do not edit. Do not push. Triage only.
```

Two MCP servers, two local read tools, no edit capability. The subagent's surface area is exactly what triage needs.

## Skills inside subagents

Skills work inside subagents the same way they work in the parent. The subagent has access to the same set of skills the parent does (project-shared and personal), and the subagent's *own* tool restrictions apply when a skill tries to run a tool the subagent doesn't have.

A skill that runs `bash scripts/get-context.sh` will fail in a subagent whose `tools:` does not include `Bash`. That is a feature, not a bug — it means a read-only subagent cannot accidentally execute a skill that runs shell.

When you write a skill that you expect to be invoked from inside a tightly-scoped subagent, document its tool requirements at the top of the SKILL.md so the subagent author knows which tools to grant.

## When to put logic in a skill vs. a subagent

The line between "this should be a skill" and "this should be a subagent" is one of the trickier judgement calls. A useful test:

- **Skill** if: the procedure is something the *current* agent should follow, the current agent's context is fine, and you want the procedure available everywhere.
- **Subagent** if: the work needs context isolation, has a distinct posture, or operates with a narrower tool list than the parent.
- **Both** if: the procedure has a posture (subagent) that follows a procedure (skill). Like `pr-author` calling the `pr-description` skill.

You almost never want a subagent that is *just* a skill in disguise. If the only difference between calling a skill and dispatching a subagent is "fresh context," the skill itself is too noisy and you should fix the skill.

## Two skills from `superpowers` worth reading

The `superpowers` library has meta-skills that codify subagent composition, mentioned in [Lecture 5, topic 9](../../05/09-skills-in-the-wild/) and worth re-reading now in this lecture's frame:

- [`obra/superpowers/skills/subagent-driven-development`](https://github.com/obra/superpowers) — the procedure for *deciding* when to dispatch a subagent. Useful as a reference for your own decision-making and as a template for the orchestrator's system prompt.
- [`obra/superpowers/skills/dispatching-parallel-agents`](https://github.com/obra/superpowers) — the parallel-exploration pattern (Pattern 3 from [topic 4](../04-orchestration-patterns/)) encoded as a skill.

Both are short, both are well-written, both are templates you can specialize for your team.

## A sanity check before you ship a composed subagent

Before committing a subagent that uses skills + MCP + tool restrictions, verify the four-way intersection works:

1. **Tools resolve**: dispatch the subagent with a trivial task. Does it report which tools it has access to? Are they the ones you expect?
2. **Skills activate**: dispatch with a prompt that should activate a specific skill. Does the skill activate inside the subagent?
3. **MCP works**: dispatch with a prompt that requires the MCP tool. Does it resolve?
4. **Restrictions hold**: dispatch with a prompt that would tempt the subagent to use a forbidden tool. Does it correctly refuse or work around?

The fourth one is the easiest to forget and the most embarrassing when it fails. Test it.

## Live demo: prove a tool restriction holds

**Setup**: the fixture file `06-skill-mcp-composition/.claude/agents/read-only-explorer.md` ships with this topic. Open Claude Code in this repo so it picks up the project-scoped agent.

**Live actions**:

1. `/agents` — show `read-only-explorer` listed; expand it; point at `tools: Read, Grep, Glob` (no `Edit`, no `Write`, no `Bash`).
2. Prompt: `use the read-only-explorer subagent to read 07/README.md and tell me how many topics there are.`
3. Watch it return a clean count.
4. Prompt: `now use the read-only-explorer subagent to add a new bullet to 07/README.md about live demos.`
5. Watch the subagent refuse / report it lacks the tool.

**What to highlight**: in the trace, the second dispatch's tool list — no `Edit`, no `Write`. The subagent cannot do the thing even if the prompt told it to. That is the `tools:` allowlist enforcing the posture mechanically, not just by instruction.

**The aha**: the restriction is not a hint to the model — it is a wall. Postures backed by tool allowlists are auditable; postures backed only by prompt language are not.

## Resources

- [Claude Code subagents documentation](https://docs.claude.com/en/docs/claude-code/sub-agents) — official reference for `tools:` and frontmatter
- [Lecture 5: Agent Skills](../../05/README.md) — the skill format used inside subagents
- [Lecture 6: MCP](../../06/README.md) — the MCP server configuration referenced by `mcp__*__*` tool names
- [`obra/superpowers/skills/subagent-driven-development`](https://github.com/obra/superpowers) — a meta-skill for delegation decisions
- [`obra/superpowers/skills/dispatching-parallel-agents`](https://github.com/obra/superpowers) — parallel exploration as a skill
