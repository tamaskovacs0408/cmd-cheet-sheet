# 3. Context isolation

Most multi-agent writeups start with role separation. Specialist agents, division of labor, the planner-implementer-reviewer triangle. Those matter, but they are not the first thing a working subagent gives you. The first thing is something quieter: the parent's context window stops filling up with noise.

Context isolation is the most under-rated feature of the `Task` tool, and the one most likely to make your single-agent sessions visibly better the day you start using it.

## The mechanic, restated

When the parent dispatches a subagent ([topic 2](../02-subagent-mechanics/)), the subagent runs in a fresh context. Its tool calls, tool outputs, and intermediate reasoning all live in *its* context window, not the parent's. When it returns, the parent sees one thing: the subagent's final message.

That asymmetry is the whole feature. The subagent can read forty files, run twelve `grep`s, and reason through eight false starts. The parent pays exactly one message worth of tokens for all of it.

## Why "send Explore to grep" beats grepping yourself

Imagine you are debugging a regression. You suspect an API contract change, but you do not know which endpoint or which caller. You start grepping. The first few `grep`s are signal-rich: "where is this field referenced?" Then you start grepping into directories you do not really care about, getting hundreds of matches you have to skim, narrowing, expanding, going in circles. By the time you have located the change, your context window is half full of grep output you no longer care about and competing leads you have already ruled out.

The same investigation with a subagent: you tell the parent

> Send an Explore agent to find all places that reference the `legacy_user_id` field, classify them as readers vs. writers, and return only the writers with file:line.

The Explore agent does the noisy work. It can grep recklessly, follow false leads, look at fifty files. None of that touches your context. It comes back with a short, structured answer. You make the next decision with a clean window.

The same task, done by you, would have been *correct* but would have left your window in a worse state for whatever comes next. Multi-agent here is not about parallelism or specialization. It is about keeping the parent's context window load-bearing for the parent's decisions.

## Live demo: side-by-side, grep yourself vs. dispatch Explore

**Setup**: this repo, fresh session (`/clear`). No files to create.

**Live actions**:

1. `/context` — note baseline percent. Call it **Run A**.
2. Prompt: `grep the entire repo for every occurrence of "subagent" and list the top 10 files by hit count.`
3. Let it complete. `/context` — note new percent. Open the trace: the full grep output is sitting in the parent's window.
4. `/clear`. `/context` — back to baseline. Call this **Run B**.
5. Prompt: `dispatch the Explore subagent to grep the entire repo for every occurrence of "subagent" and return only the top 10 files by hit count, as a numbered list — nothing else.`
6. Let it complete. `/context` — note new percent.

**What to highlight**: the `Task` tool call in the trace for Run B; the single short message that comes back versus the wall of grep matches in Run A. Compare the two `/context` deltas on screen.

**The aha**: same answer, similar wall time, but Run B's parent window is barely touched. The subagent is not faster — it is a context-discipline tool. Everything that follows in this lecture rests on this asymmetry.

## The summary tax

The asymmetry has a cost. The parent only sees the summary. If the summary is wrong, vague, or omits something important, the parent cannot recover the missing information without re-running the subagent (and getting *another* summary that may also be wrong).

Three concrete failure modes:

1. **The summary asserts work that did not happen.** "I checked all references and none of them write to the field." The agent says this; the parent believes it; the bug is in one of the references the agent did not check. The parent has no way to verify without redoing the search.
2. **The summary loses the part you wanted.** You asked "are there any callers in `services/`?" The summary says "I found 14 callers." It does not list them. You re-dispatch.
3. **The summary describes the *intent* of the work, not the *result*.** "I investigated whether the migration is safe by checking the relevant invariants and concluded it is safe." This is the most common one with longer-running subagents: the model summarizes its plan instead of its findings.

The defense is to write the subagent prompt with explicit return-shape instructions. Not "find the callers" but "find the callers and return a JSON list of `{file, line, function_name}`." Not "check the migration" but "check the migration and return PASS or FAIL with three bullet points naming what you checked." A subagent that returns a structured artifact is verifiable. A subagent that returns prose is a coin flip.

The official Claude Code guidance puts this as "trust but verify": the summary describes what the subagent intended to do, not necessarily what it did. When the agent's report drives a real action, the parent should verify the load-bearing claims directly.

## Token economics: when isolation pays off, when it costs more

Naively, the cost of dispatching a subagent is the cost of running it. The savings is the tokens you would otherwise have brought into the parent. Three regimes:

**Big win**: noisy investigation, small answer.
- Examples: "find all readers of X," "summarize the test failures," "investigate which of these five hypotheses fits."
- The subagent reads thousands of tokens; the summary is a hundred. The parent saves the difference and stays usable for many more turns.

**Wash**: small investigation, small answer.
- Example: "what does this 30-line function do?"
- Reading the function in the parent costs ~100 tokens. Running a subagent costs the parent ~100 tokens (for the summary) plus the subagent's full run (maybe 500–1000 tokens of overhead before the summary). You spent more compute for no context savings.
- *Don't dispatch a subagent for trivial work.*

**Loss**: big investigation, big answer needed.
- Example: "list every line in the codebase where we touch the `User` model."
- The subagent has to enumerate thousands of references. If the parent actually needs all of them, the summary has to carry them all. You did not save any tokens; you only made the model write the list twice (once internally, once in the summary).
- *If the parent needs the raw output, do not subagent. Or restructure the work so the parent needs only an aggregated answer.*

The rule of thumb: **dispatch when the work is noisy and the answer is small; do it yourself when the work is short or the answer is large.**

## Side effect: cheaper retries

A subagent that fails — wrong answer, didn't follow instructions, made up a finding — can be re-dispatched with a tweaked prompt without polluting the parent's context. The first run leaves no trace in the parent beyond the message you discarded. By contrast, a single agent that goes down a wrong path leaves all of that wrong-path reasoning in its window, and you cannot easily evict it.

This is one of the least-discussed but most useful properties. In an interactive session, you can cheaply iterate on a subagent's prompt — re-dispatch it, look at the result, refine the instruction, re-dispatch — and your parent's context never accumulates the cost of those iterations. Treat subagents as disposable workers.

## Practical heuristics

A short list to keep at hand:

- **Default to dispatching when the next step would otherwise dump >2000 tokens of tool output into your window.** Especially `grep`, `find`, log reads, large file reads.
- **Always specify the return shape.** "Return JSON with these keys" or "return PASS/FAIL with at most three bullets" beats "find out and let me know."
- **Restrict the subagent's tools to what it actually needs.** A read-only investigator should not have `Edit`. A code reviewer should not have `Bash`. Tool restriction is also a form of context discipline — fewer tool descriptions means tighter context in the subagent itself.
- **If the subagent's job is investigation, give it `Explore` (built-in) before writing a custom one.** The built-in is tuned for this exact use case.
- **Re-read the summary against your prompt, not against your hopes.** Did the agent answer the question, or did it answer a similar-sounding easier question? If similar-sounding-easier, redispatch.

## Connecting forward

Context isolation is the substrate the rest of the lecture builds on:

- [Topic 4](../04-orchestration-patterns/) shows the four patterns that all rely on isolation to work.
- [Topic 5](../05-reviewer-loops/) is specifically the case where you *want* the reviewer not to have the implementer's context.
- [Topic 7](../07-anti-patterns/) is the inverse: cases where the parent loses too much by not seeing what the subagent saw, and isolation makes the work worse.

If you remember one thing from this topic: subagents are not just specialists. They are also a context discipline tool, and the discipline is often the bigger win.

## Resources

- [Claude Code subagents documentation](https://docs.claude.com/en/docs/claude-code/sub-agents) — official guidance, including "trust but verify"
- [Anthropic Engineering: How we built our multi-agent research system](https://www.anthropic.com/engineering/built-multi-agent-research-system) — the same context-isolation pattern at research scale
- [Topic 2: subagent mechanics](../02-subagent-mechanics/) — the primitives this topic relies on
