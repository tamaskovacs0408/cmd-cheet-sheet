# 4. Orchestration patterns

Anthropic's *Building Effective Agents* (December 2024) sorts agentic systems into a small set of patterns. The exact taxonomy varies by author, but four patterns cover most of what you will need in Claude Code. Each one solves one of the four pressures from [topic 1](../01-single-agent-wall/), and each one wires up cleanly to the subagent primitive from [topic 2](../02-subagent-mechanics/).

This topic walks all four. For each: a one-paragraph description, a Claude Code wiring sketch, a real-world use case, and the pressure it solves.

## Pattern 1: Orchestrator–worker

**The picture**: a parent agent decomposes a task into independent subtasks, dispatches one subagent per subtask, and synthesizes the results.

**Wiring**: in Claude Code, this is the most natural pattern because the `Task` tool already supports it. The parent's prompt or system prompt instructs it to break the task into N pieces and delegate. The workers can be the built-in `general-purpose` or `Explore` agents, or custom ones. The parent merges the results.

```
You are coordinating a refactor. For each module listed in TASK.md, dispatch
a `module-refactor` subagent with that single module's path and the refactor
instructions. Wait for all of them. Then write a final summary listing what
each subagent reported.
```

**Use case**: refactoring the same change across many files (one worker per file or per module), generating tests for many functions, applying a security patch across services.

**Solves**: missed parallelism. Independent work runs at the same time, and each worker keeps the parent's context clean ([topic 3](../03-context-isolation/)).

**Watch out for**: subtasks that are not actually independent. If worker B's correctness depends on worker A's result, you do not have an orchestrator–worker; you have a sequential pipeline pretending to be parallel. The orchestrator will see two summaries that disagree and have to reconcile them, often badly.

## Pattern 2: Evaluator–optimizer (the reviewer loop)

**The picture**: a builder subagent produces output. A separate reviewer subagent inspects it and returns PASS or FAIL with reasons. On FAIL, the parent feeds the review back to the builder for another round. Loop until PASS or until an iteration budget is hit.

**Wiring**: two subagents and a small piece of orchestration logic in the parent's system prompt.

```
For each task in the plan:

1. Dispatch the `implementer` subagent with the task description.
2. Dispatch the `reviewer` subagent with: the original task description and
   the diff the implementer produced.
3. If the reviewer returns FAIL, dispatch the implementer again with: the
   original task, the previous diff, and the reviewer's findings.
4. After 2 rounds of FAIL, surface to the user. Do not loop indefinitely.
5. After PASS, move on to the next task.
```

**Use case**: code review before merge, security review, contract validation, test-correctness checking, doc accuracy checking.

**Solves**: role confusion. The reviewer never saw the implementation happen, so it does not inherit the implementer's blind spots. We give this pattern its own topic ([topic 5](../05-reviewer-loops/)) because it is the highest-payoff pattern for most teams.

**Watch out for**: the rubber-stamp reviewer (passes everything because the prompt is too lenient — see [topic 5](../05-reviewer-loops/)). Also watch out for infinite loops. Always cap iterations and surface unresolved disagreements to the human.

## Pattern 3: Parallel exploration

**The picture**: the parent has N hypotheses or N approaches. It dispatches one subagent per hypothesis. They run in parallel. The parent reads the summaries and picks the winner.

**Wiring**: the parent's instruction names the hypotheses explicitly and dispatches in parallel. In Claude Code, parallel dispatch happens when the orchestrator emits multiple `Task` tool calls in the same turn.

```
We have a regression. Dispatch four `Explore` agents in parallel:

- agent A: investigate whether the recent change to `auth/middleware.py` could explain the regression
- agent B: investigate whether the recent change to `db/connection.py` could explain it
- agent C: investigate whether the recent dependency bump in pyproject.toml could explain it
- agent D: investigate whether a runtime config change in `config/prod.yaml` could explain it

Each agent should return PASS (likely cause) or FAIL (ruled out) with one paragraph of evidence. After all four return, summarise which hypotheses survived.
```

**Use case**: bug hunting across multiple suspect changes; trying several refactor approaches and comparing; exploring different data shapes before committing.

**Solves**: missed parallelism *and* role confusion (each branch is investigated by an agent that has not seen the other branches' results, so commitments do not bleed across).

**Watch out for**: making the parent rely on the *content* of all four traces. The parent only has the summaries. If the parent needs to do a synthesis that requires raw evidence from each branch, you cannot get it back without re-dispatching.

## Live demo: three parallel Explore agents, one turn

**Setup**: this repo, fresh session.

**Live actions**:

1. Prompt, exactly:
   > Investigate three competing claims about this repo by dispatching three Explore agents *in parallel, in the same turn*:
   > - agent A: does lecture 5 cover MCP servers?
   > - agent B: does lecture 6 cover skills?
   > - agent C: does lecture 7 introduce subagents?
   > Each agent returns YES or NO with one sentence of evidence (a file path and quote). After all three return, summarise.
2. Watch the assistant turn render. Pause before expanding traces.

**What to highlight**: in the turn where the assistant dispatches, three `Task` tool calls appear *in the same message*, not three sequential turns. Expand each one — three independent traces, each with its own Grep/Read calls. The summary turn arrives after all three return.

**The aha**: "same turn, three agents, three contexts." This is what parallelism in Claude Code literally looks like — multiple `Task` invocations in one assistant message. A single agent would have run the three investigations sequentially.

## Pattern 4: Hierarchical delegation

**The picture**: a top-level orchestrator dispatches a planner. The planner produces a structured plan. The orchestrator then dispatches one or more implementers, each working on one plan step. Optionally, a reviewer is dispatched after each implementation. The hierarchy can be deeper.

**Wiring**: this is the pattern the [capstone lab](../08-pipeline-lab/) builds.

```
Phase 1 — plan: dispatch `planner` with the change description from TASK.md.
  Receive: a numbered list of implementation tasks.

Phase 2 — implement: for each task in the planner's list, dispatch `implementer`.
  After each implementer call, dispatch `reviewer` with that task's diff.
  On FAIL, redispatch implementer with the reviewer's notes (max 2 rounds).
  Move to the next task only after PASS.

Phase 3 — final review: after all tasks PASS individually, dispatch `reviewer`
  one more time on the full accumulated diff to catch issues only visible in
  combination.
```

**Use case**: PR-sized changes with a clean planner-builder-reviewer separation. Anything where the plan should exist as an artifact before any code is written.

**Solves**: all four pressures simultaneously, which is also why it is the most expensive to run. Use it when the task is large enough to justify the overhead.

**Watch out for**: orchestration logic in prose. A long English paragraph in the parent's system prompt describing "phase 1, then phase 2, then phase 3" is fragile. Either keep the structure simple enough that the parent can follow prose, or push the orchestration into a [skill](../../05/README.md) that encodes the procedure. The pattern *itself* is fine; the prose-orchestration *implementation* of it is where it usually breaks.

## Live demo: peek at the hierarchical pipeline

**Time budget**: ~60 seconds. Pure show-and-tell, no execution.

**Setup**: the [capstone lab](../08-pipeline-lab/) already ships planner / implementer / reviewer agents under `08-pipeline-lab/.claude/agents/`.

**Live actions**:

1. `/agents` — show the picker listing the custom agents the lab will use.
2. Open `08-pipeline-lab/.claude/agents/planner.md` in a split. Read the `description:` and `tools:` lines aloud.
3. Close. Do not run the pipeline.

**What to highlight**: three `.claude/agents/*.md` files — three system prompts, three tool lists. The orchestration logic is the parent's prompt; the agents themselves are just files.

**The aha**: Pattern 4 is three text files plus an orchestrator prompt. The capstone is not magic; it is this lecture's primitives composed.

## A pattern is not a contract

These four are starting templates. Real systems mix them: an orchestrator–worker where each worker has its own internal evaluator–optimizer; a hierarchical pipeline whose middle layer dispatches parallel exploration. The patterns are useful because they name common shapes, not because they constrain you to one of them.

The shape that does *not* work well is "one big agent with subagents called as helpers." That is not multi-agent architecture; it is a single agent with a noisy tool list. Multi-agent architecture is when the orchestration logic itself is the design, and the patterns above are the vocabulary for that design.

## Anti-pattern preview: needless orchestration

Every one of these patterns has a failure mode where you reach for it when a single agent would have done the job in one third of the tokens and one tenth of the wall time. [Topic 7](../07-anti-patterns/) is dedicated to recognizing those cases. Read it before designing your first multi-agent system, not after.

## A pattern selection cheat sheet

| You have… | Reach for… |
|---|---|
| Independent subtasks that can run at once | Orchestrator–worker (Pattern 1) |
| Output that needs an outsider's review | Evaluator–optimizer (Pattern 2) |
| Multiple hypotheses to investigate | Parallel exploration (Pattern 3) |
| A multi-stage workflow with planning, implementation, and review | Hierarchical delegation (Pattern 4) |
| One specialist tool to call repeatedly | A skill ([Lecture 5](../../05/README.md)), not a subagent |
| One big task with no role separation | A single agent with better context, not orchestration |

## Resources

- [Anthropic Engineering: Building effective agents](https://www.anthropic.com/research/building-effective-agents) — the original taxonomy and decision framework
- [Anthropic Engineering: How we built our multi-agent research system](https://www.anthropic.com/engineering/built-multi-agent-research-system) — orchestrator–worker and parallel exploration at scale
- [Cognition: Don't build multi-agents](https://cognition.ai/blog/dont-build-multi-agents) — the contrarian read; engaged with directly in [topic 7](../07-anti-patterns/)
- [Topic 5: reviewer loops](../05-reviewer-loops/) — pattern 2 in depth
- [Capstone lab](../08-pipeline-lab/) — pattern 4 hands-on
