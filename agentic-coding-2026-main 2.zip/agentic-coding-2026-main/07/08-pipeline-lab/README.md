# 8. Capstone lab: build the pipeline

This is the practical part of the lecture. You will build a planner → implementer → reviewer pipeline against a small Python service, run it on a real change, watch it iterate, and break it on purpose. Forty-five minutes for the full path; thirty if you skip the breakage exercises.

The starter code lives in `starter-code/`. The change you will make is in `TASK.md`. The three agent stubs are in `.claude/agents/`. Your job is to fill in the bodies, wire the orchestrator prompt, run the pipeline, and observe.

## What you are going to build

A three-agent pipeline:

1. **`planner`** — read-only, outputs a numbered list of implementation tasks.
2. **`implementer`** — has `Edit` and `Bash`, executes one task at a time.
3. **`reviewer`** — read-only, returns PASS or FAIL with reasons.

An orchestrator prompt that wires them with a 2-iteration reviewer loop per task.

## Step 0: open the lab and look around

```sh
cd 07/08-pipeline-lab
ls -la
ls -la .claude/agents/
cat TASK.md
cat starter-code/app.py
```

Read `TASK.md` — it describes the change. Read `starter-code/app.py` — it is the Python service the change applies to. Read the three agent stubs — they have frontmatter and section headers but no body content yet.

## Step 1: write the `planner` system prompt

Open `.claude/agents/planner.md`. The frontmatter is filled in. The body is empty. Write a system prompt that:

- Instructs the planner to read `TASK.md` (the parent will pass the path).
- Reads the relevant code in `starter-code/`.
- Outputs a numbered list of implementation tasks. Each task should be small enough that an implementer can complete it in one or two file edits.
- Does NOT write code. Does NOT edit files.
- Returns the list as plain markdown, numbered, with each item as a single sentence.

Keep the prompt short. The five-commandments rules from [Lecture 5, topic 7](../../05/07-writing-good-skill/) apply here as much as they did for skills.

## Step 2: write the `implementer` system prompt

Open `.claude/agents/implementer.md`. Write a system prompt that:

- Receives one task description from the parent.
- Edits exactly the files the task requires.
- Runs the test suite (`uv run pytest` from `starter-code/`).
- Returns: the diff (use `git diff`), the test result (PASS/FAIL with output), and a one-sentence summary.
- Does NOT plan. Does NOT review. Does NOT commit.

Optional: include an instruction that if the implementer is given reviewer feedback, it should address that feedback specifically, but should push back if it disagrees rather than blindly comply.

## Step 3: write the `reviewer` system prompt

Open `.claude/agents/reviewer.md`. Write a system prompt that:

- Receives the original task description and the diff.
- Reviews the diff for: correctness against the task, edge cases the task implies but does not state explicitly, test coverage of the change.
- Has a clear FAIL-default: if uncertain whether something is correct, FAIL with the uncertainty as the reason.
- Returns PASS or FAIL on the first line, then findings as a bulleted list.
- Does NOT edit. Does NOT propose alternative implementations beyond a one-sentence "consider X."

## Step 4: write the orchestrator prompt

This is the prompt you give Claude Code to start the pipeline. It is not a `.claude/agents/` file — it is the instruction you paste into the Claude Code prompt to kick everything off. A working starting point:

```
Read TASK.md. Then orchestrate the three subagents to implement it:

1. Dispatch `planner` with TASK.md. Receive a numbered task list.
2. For each task in the list:
   a. Dispatch `implementer` with the task description.
   b. Dispatch `reviewer` with the original task and the diff.
   c. If FAIL, redispatch implementer with the task, the previous diff, and
      the reviewer's findings. Then redispatch reviewer.
   d. After 2 rounds of FAIL, stop and surface to me.
3. Once all tasks PASS individually, dispatch `reviewer` one final time on
   the full accumulated diff. Surface the result.

Do not commit. Do not push. Stop after the final review and report what
happened.
```

## Step 5: run it

In Claude Code, with this directory as the working directory, paste the orchestrator prompt. Watch the trace.

Things to look for:

- The planner runs first and returns a numbered list. Does the list look reasonable? Are the tasks the right size?
- For each task, the implementer runs, then the reviewer runs. Does the reviewer fail anything? Does the implementer's second attempt address the feedback?
- After all tasks PASS, the final reviewer runs against the cumulative diff. Does it find anything that step-level reviews missed?

Open the trace viewer or the terminal output. Notice that the parent's context only contains the summaries — it never accumulates the implementer's intermediate file reads or the reviewer's intermediate `Grep` output. That is the [topic 3](../03-context-isolation/) effect, live.

## Step 6: break it on purpose

Three quick experiments to feel the failure modes:

### 6a: rubber-stamp the reviewer

Change the reviewer's prompt to be vaguer: replace specific FAIL criteria with "review the code for issues." Re-run. Does the reviewer still catch real problems? Does it just PASS everything?

This is the rubber-stamp anti-pattern from [topic 5](../05-reviewer-loops/) in action. Revert when done.

### 6b: starve the planner of tools

Remove `Read` from the planner's `tools:` list. Re-run. The planner cannot read TASK.md. Does it fail loudly, or does it confidently return a bad plan?

This is the cost of incorrect tool restrictions. The planner needs `Read`; the reviewer doesn't need `Edit`. Both are easy to get wrong on first authoring.

### 6c: remove the iteration cap

Change the orchestrator prompt to remove "After 2 rounds of FAIL." Find a task description that the implementer cannot easily satisfy (or temporarily make the reviewer fail-bias overly strict). Watch how many rounds the loop runs before something gives.

This is why iteration budgets matter ([topic 5](../05-reviewer-loops/)). Revert when done.

## Step 7 (optional, recommended): the side-by-side

The exercise from [topic 7](../07-anti-patterns/). Do TASK.md two ways:

1. With the pipeline you just built.
2. With a single agent, no orchestration, in the same Claude Code session: just paste TASK.md content and ask "implement this."

Record turns, tokens, wall time, and your subjective sense of diff quality for each. For a task this size, the single agent will usually win on every metric. That is the calibration: orchestration is a tool, not a default.

## What to take away

- You have built a Pattern 4 (hierarchical delegation) pipeline ([topic 4](../04-orchestration-patterns/)).
- You have seen a reviewer loop catch and not-catch issues ([topic 5](../05-reviewer-loops/)).
- You have measured the cost of orchestration on a small task ([topic 7](../07-anti-patterns/)) and felt that the cost is real.
- You have three agent definitions you can adapt to your own projects. The shapes are reusable; the bodies are project-specific.

Keep the agent files. Adapt them for your real repo. The capstone is the start of your library, not the end of the lecture.

## Files in this lab

- `TASK.md` — the change to implement
- `starter-code/` — small Python service to modify
- `.claude/agents/planner.md` — stub
- `.claude/agents/implementer.md` — stub
- `.claude/agents/reviewer.md` — stub
- `README.md` — this file

## Resources

- [Topic 2: subagent mechanics](../02-subagent-mechanics/)
- [Topic 4: orchestration patterns](../04-orchestration-patterns/) — pattern 4 (hierarchical delegation)
- [Topic 5: reviewer loops](../05-reviewer-loops/)
- [Topic 7: when not to use multi-agent](../07-anti-patterns/) — the side-by-side measurement
