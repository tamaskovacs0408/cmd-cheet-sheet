from fastapi import FastAPI, HTTPException, Request

app = FastAPI()

_users: list[dict] = []


@app.post("/users", status_code=201)
async def create_user(request: Request) -> dict:
    body = await request.json()
    if not isinstance(body, dict):
        raise HTTPException(status_code=400, detail="body must be an object")
    record = dict(body)
    record["id"] = len(_users) + 1
    _users.append(record)
    return record


@app.get("/users")
async def list_users() -> list[dict]:
    return _users


@app.get("/healthz")
async def healthz() -> dict:
    return {"ok": True}
