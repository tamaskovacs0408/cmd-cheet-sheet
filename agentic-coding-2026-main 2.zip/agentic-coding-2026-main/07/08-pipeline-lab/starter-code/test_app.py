from fastapi.testclient import TestClient

from app import app, _users


def setup_function() -> None:
    _users.clear()


def test_healthz() -> None:
    client = TestClient(app)
    response = client.get("/healthz")
    assert response.status_code == 200
    assert response.json() == {"ok": True}


def test_create_user_returns_record_with_id() -> None:
    client = TestClient(app)
    response = client.post(
        "/users",
        json={"email": "alice@example.com", "username": "alice"},
    )
    assert response.status_code == 201
    body = response.json()
    assert body["email"] == "alice@example.com"
    assert body["username"] == "alice"
    assert body["id"] == 1


def test_list_users_returns_created() -> None:
    client = TestClient(app)
    client.post("/users", json={"email": "a@b.com", "username": "ab"})
    response = client.get("/users")
    assert response.status_code == 200
    assert len(response.json()) == 1
