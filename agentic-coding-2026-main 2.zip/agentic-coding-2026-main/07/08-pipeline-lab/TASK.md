# TASK: Add input validation to the `/users` POST endpoint

The `starter-code/` directory contains a small FastAPI service that exposes a `/users` POST endpoint. Right now it accepts any JSON body and stores it without validation. We have just had an incident in staging where a client sent malformed data and crashed the service.

Your task: add proper input validation to the `/users` POST endpoint and the corresponding test coverage.

## Acceptance criteria

The endpoint must validate that:

1. **`email`** is present, is a string, and matches a valid email format.
2. **`username`** is present, is a string, is between 3 and 32 characters, and contains only lowercase letters, digits, hyphens, and underscores.
3. **`age`** is optional, but if present must be an integer between 13 and 120 inclusive.
4. **`role`** is optional. If present, it must be one of `"user"`, `"admin"`, or `"viewer"`.

On invalid input, the endpoint must return HTTP 422 with a clear error message identifying the offending field. On valid input, the endpoint stores the user and returns HTTP 201 with the stored record.

## Test coverage required

Add tests that cover:

- A valid request with all fields succeeds.
- A valid request with only required fields succeeds.
- Each invalid field above produces a 422 with the right field name in the error.
- Two distinct invalid fields in the same request produce a 422 mentioning both.

## Constraints

- Do not change the URL of the endpoint.
- Do not change the response shape on success (existing clients depend on it).
- The validation should use Pydantic, which is already a dependency.
- Keep the diff small. Do not refactor unrelated code.

## How to verify locally

```sh
cd starter-code
uv run pytest -q
```

All tests must pass. Existing tests must still pass.
