# 7. When not to use multi-agent

There is a strong gravitational pull, once you have learned the patterns, to apply them everywhere. A new task lands on your desk and you immediately reach for the three-agent pipeline. Resist this. Most tasks are still solo work. The set of tasks that genuinely benefit from orchestration is real but smaller than people new to multi-agent assume, and the tasks where orchestration *makes things worse* are common.

This topic is about recognizing those.

## The four costs of multi-agent

Every pattern from [topic 4](../04-orchestration-patterns/) buys you something and costs you something. The costs are easy to underestimate because they show up gradually, not in the first run.

### Cost 1: coordination overhead

Every subagent dispatch is a turn. Every turn is latency, tokens, and a new context to load. A three-agent pipeline that does the work a single agent could do in eight turns will easily run twenty turns and ten times the wall time, because each subagent has to load up, do its job, and write a summary.

For a five-line bug fix, this is theater. The single agent reads the file, writes the fix, runs the test, done. The pipeline reads the task, dispatches the planner, the planner reads the file, the planner writes a one-step plan, the orchestrator reads the plan, the orchestrator dispatches the implementer, the implementer reads the file, the implementer writes the fix, the implementer reports, the orchestrator dispatches the reviewer, the reviewer reads the file and the diff, the reviewer reports PASS, the orchestrator reports done.

The pipeline is not wrong. It produced the same output. It just took ten times the work to produce it, and you are paying for every step.

### Cost 2: debugging cost

When a single-agent session goes wrong, you have one trace to read. When a multi-agent pipeline goes wrong, you have N traces, and the failure may live in any of:

- The orchestrator's decomposition (wrong subtasks).
- A subagent's prompt (wrong posture).
- A subagent's summary (right work, bad summary).
- The orchestrator's synthesis (right summaries, wrong combination).
- The interaction between two subagents that did not see each other's work.

The "right summaries, wrong combination" case is the meanest. Each subagent did its job correctly. Each summary is accurate. But the parent's synthesis missed something that was only visible when you read both raw traces side by side, which the parent could not do because it only had the summaries.

Multi-agent systems fail in failure modes that single-agent systems do not have. Plan for that when you adopt them.

### Cost 3: context fragmentation

A subagent only sees its prompt and what it gathers. The parent only sees the summary. Information that was load-bearing in the parent gets diluted by the time it reaches the subagent, and information the subagent gathered gets diluted by the time the summary returns to the parent.

Concrete failure: the parent has been debugging an intermittent bug and has built up a suspect list. The parent dispatches a subagent to "investigate the database connection." The subagent investigates and reports, "the database connection looks fine." The parent acts on this. But the parent's suspect list specifically wanted to know about a *race condition* in connection handling under load — which the subagent did not check, because the subagent's prompt said only "investigate the database connection."

Information that was implicit in the parent's accumulated context did not transfer to the subagent. The subagent answered a sensible-sounding question that was not the question the parent meant to ask.

### Cost 4: over-confidence in summaries

This is the meta-cost that makes the others worse. Subagent summaries *look* authoritative. A confident-sounding "I checked all references and none of them write to the field" reads like a fact, but it is the summary of one agent's investigation, not a fact about the world. Parents tend to trust summaries more than they trust their own grep results, because the summary feels like a conclusion.

The defense, from [topic 3](../03-context-isolation/): trust but verify, always specify the return shape, ask for evidence not conclusions. But the cost is real even when you are disciplined about it.

## When the costs exceed the benefits

The diagnostic from [topic 1](../01-single-agent-wall/) restated as a "do not orchestrate" test:

| Symptom | Don't orchestrate. Do this instead. |
|---|---|
| The task is small and clear | One agent. Single turn if possible. |
| You are reaching for a subagent because the agent is "going in circles" | Better prompt, better skill, or compact and restart. |
| The task is one specialist procedure you do often | Skill ([Lecture 5](../../05/README.md)), not subagent. |
| You want the agent to "double check" its work | Better tests, not a reviewer subagent. The reviewer can rubber-stamp; the test cannot. |
| You think it would be "cooler" with multiple agents | The honest answer to this is yes, and that is not a reason. |
| The work is exploratory and you are still figuring out the shape | Solo. Add subagents only after the workflow is stable enough to know what to dispatch. |

Multi-agent is the right answer when at least one of these holds:

- The parent's context is genuinely about to overflow with noisy work that has a small answer.
- There is a quality concern that explicitly requires a fresh reader.
- There is genuine independent parallel work to do.
- There is a posture distinct enough to deserve its own system prompt and tool list.

If none of these holds, you do not have a multi-agent problem.

## A side-by-side measurement

The best way to convince yourself of the cost shape is to run the same task two ways. For [the capstone lab](../08-pipeline-lab/), do this exercise:

1. Run TASK.md with a single agent and the default prompt. Record: turns, tokens, wall time, final-diff quality.
2. Run TASK.md with the planner → implementer → reviewer pipeline. Record the same numbers.

What you will typically see for a small task (the lab default is intentionally small):

| Metric | Single agent | Pipeline |
|---|---|---|
| Turns | 4–6 | 12–20 |
| Tokens | low | 2–4× higher |
| Wall time | ~30s | ~3–5 min |
| Diff quality | good | usually similar; occasionally better |

For tasks this size, the pipeline is overkill. The numbers cross over only when the task is big enough — multi-file, multi-concern, with real planning and review demands. Knowing where the crossover is in your codebase is a calibration exercise; do it once and you will reach for orchestration more honestly afterwards.

## Live demo: same task, two ways, count the cost

**Setup**: this repo. Pick one trivial real task — for example, *"add a one-sentence note to `07/README.md` saying lecture 7 has a capstone in topic 8."* Have the exact wording on a sticky or slide so both runs use identical input.

**Live actions**:

1. `/clear`. `/context`. **Run A — single agent.**
2. Prompt verbatim: `add a one-sentence note to 07/README.md saying lecture 7 has a capstone in topic 8.`
3. Let it edit and finish. Note: turn count (count assistant messages), `/context` percent, wall-clock seconds.
4. Discard the change: `git checkout -- 07/README.md`.
5. `/clear`. `/context`. **Run B — orchestrated.**
6. Prompt verbatim: `Orchestrate this as planner→implementer→reviewer. Dispatch a planner subagent to produce a one-step plan; then an implementer to make the edit; then a reviewer to PASS/FAIL it. Task: add a one-sentence note to 07/README.md saying lecture 7 has a capstone in topic 8.`
7. Let it run. Same metrics.
8. Write the four numbers on the board: Run A turns/context/seconds, Run B same.

**What to highlight**: typical numbers — Run A: 3–4 turns, ~5% context, ~20s. Run B: 12+ turns, 15–25% context, 2–4 min. Same one-line diff in both.

**The aha**: the pipeline produced an identical diff for several times the cost. None of the four pressures from [topic 1](../01-single-agent-wall/) were present, so the orchestration was theatre. This is the table from the previous section made concrete in front of the class.

## The agents-all-the-way-down trap

The terminal failure mode. You have a multi-agent pipeline. It mostly works. When it fails, your instinct is to add another agent — a meta-reviewer, a coordinator-of-coordinators, a "dispatcher to decide which dispatcher to use."

This rarely helps. The new layer adds its own coordination overhead, its own debugging surface, and its own context fragmentation. The original failure was usually one of:

- An imprecise prompt at one of the existing layers.
- A wrong tool restriction.
- A bug in the orchestrator's logic.

Fix the layer that failed. Don't add a new one.

## The Cognition argument

The most-cited contrarian piece on multi-agent is Cognition's [*Don't build multi-agents*](https://cognition.ai/blog/dont-build-multi-agents). Their argument, summarised: multi-agent systems make context-sharing problems worse, not better; the failure modes are subtle and expensive; many teams reaching for multi-agent really need better single-agent context engineering.

Most of that argument is correct, *and* it does not contradict this lecture. The lecture's claim is not "build multi-agent for everything." It is "build multi-agent for these four specific pressures, and not for the others." Where Cognition pushes back hardest is on systems that introduce orchestration without one of the four pressures actually being present. That is a real failure mode and we agree.

The synthesis: read Cognition's piece. Hold its skepticism in mind every time you reach for a `Task` tool. If you cannot articulate which of the four pressures justifies the dispatch, do not dispatch.

## A heuristic, written down

When in doubt, the rule:

> **Default to the smallest agent system that produces correct work. Add complexity only when one of the four pressures is concretely present, not anticipated.**

Anticipation is the trap. "We might need a reviewer eventually, so let's wire one in now" produces pipelines that nobody understands when they fail, and the eventual reviewer is rarely tuned to the cases that actually need review. Add the reviewer when you have a class of mistake the implementer keeps making. Add the parallel exploration when you have hypotheses you actually want to investigate. Add the planner when the task is genuinely big enough to deserve a plan as an artifact.

## Resources

- [Cognition: Don't build multi-agents](https://cognition.ai/blog/dont-build-multi-agents) — the contrarian read
- [Anthropic Engineering: Building effective agents](https://www.anthropic.com/research/building-effective-agents) — the section on "when not to use agents"
- [Topic 1: the single-agent wall](../01-single-agent-wall/) — the diagnostic this topic inverts
- [Capstone lab](../08-pipeline-lab/) — the side-by-side measurement to run yourself
