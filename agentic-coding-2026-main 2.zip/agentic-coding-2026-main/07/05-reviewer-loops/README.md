# 5. Reviewer loops in practice

Of the four patterns in [topic 4](../04-orchestration-patterns/), the evaluator–optimizer (reviewer loop) is the one most likely to ship value the same week you adopt it. That is because the cost of the failure mode it prevents — a single agent reviewing its own work — is high and pervasive. Almost every change benefits from a reviewer that did not watch the implementation happen.

This topic is about getting that pattern right.

## Built-in reviewers you already have

Claude Code ships with three review-shaped slash commands. Treat them as the off-the-shelf starting point. Often they are enough.

- **`/review`** — review a pull request. The author flow: you point it at a PR and it reads the diff and writes a review. The reviewer flow: you ask it to summarize the PR for you before you read it.
- **`/security-review`** — complete a security review of the pending changes on the current branch. Tuned specifically for the security posture: input validation, injection, auth boundaries, secrets in logs, crypto misuse.
- **`/ultrareview`** — multi-agent cloud review of the current branch (or a GitHub PR). Runs several specialist reviewers in parallel against the same diff. Higher latency, higher cost, broader coverage. User-triggered and billed; you cannot launch it programmatically.

Two implications for designing your own reviewers:

1. **Don't reinvent these.** If `/security-review` does what you need, use it. A custom `security-reviewer` only makes sense when the built-in does not match your team's specific posture (e.g., you have a domain-specific class of bug — PII handling, multi-tenant isolation, payment flows — that the generic review will not cover).
2. **The shape they take is the shape yours should take.** Each one runs against a diff (not against the live code), returns a structured review, and does not edit anything. Custom reviewers should follow that shape.

## Live demo: built-in reviewer on a real branch

**Setup**: the instructor needs a working branch with a small uncommitted change in this repo — e.g. a deliberately weak edit to one README (a typo and a broken markdown link). If the tree is clean, run `git switch -c demo-review` and make a 5-line edit live before starting.

**Live actions**:

1. `git status` and `git diff` in a side terminal — show the diff is small and obvious.
2. In Claude Code: `/review` — let it complete.
3. Read the output aloud. Note structure: findings, severity, summary.
4. `/security-review` — let it complete.
5. Compare the two: same diff, different posture, different findings.

**What to highlight**: each command spawns its own subagent — open the trace, point at the `Task` invocation. The reviewer never saw the *implementation* happen; it sees only the diff. That is the whole evaluator–optimizer point.

**The aha**: no agent config written, and we already have two specialist reviewers. Custom reviewers (next section) are only worth writing when a built-in does not fit your team's specific posture.

## Writing a custom reviewer subagent

The generic `security-reviewer` from [topic 2](../02-subagent-mechanics/) is a fine template. Specialize it.

Two examples worth writing for a real project:

### `migration-safety-reviewer`

```markdown
---
name: migration-safety-reviewer
description: Use when reviewing a database migration. Triggered by changes to files matching `**/migrations/*.sql` or `**/migrations/*.py`. Checks for online-safe migration patterns under concurrent writes.
tools: Read, Grep, Glob
---

You review database migrations for safety on a production system with 100M+ rows and concurrent writes. Assume the migration runs without taking the table offline.

For each migration, check:

1. **Locking**: does this take any lock that blocks reads or writes for more than a few seconds?
2. **NOT NULL columns**: is a NOT NULL added to an existing column without a default? (always unsafe)
3. **Defaults on large tables**: is a column added with a non-trivial default? (postgres rewrites the table — slow lock)
4. **Index creation**: is an index created without `CONCURRENTLY`?
5. **Foreign key validation**: is a FK added without `NOT VALID` + later `VALIDATE CONSTRAINT`?
6. **Data backfills**: any DML statement that touches more than 10k rows without batching?

Return PASS or FAIL with:

- For each finding: severity (BLOCKER / RISKY / OK), the line, the issue, the safer pattern.
- A one-line summary at the top.

Do not edit. Do not propose the fixed migration. Only review.
```

### `api-contract-reviewer`

```markdown
---
name: api-contract-reviewer
description: Use after editing any file under `api/` or `services/*/handlers/`. Verifies that public API contracts are not broken: response schema changes, removed fields, changed status codes, new required parameters.
tools: Read, Grep, Glob, Bash
---

You review API handler changes for contract breakage that would affect existing clients.

For each changed handler, check:

1. **Removed response fields**: a field that was returned before is no longer returned.
2. **Renamed response fields**: a field that was `userId` is now `user_id`.
3. **Changed types**: a field that was a string is now an int.
4. **New required parameters**: a parameter that was optional is now required, or a parameter that did not exist is now required.
5. **Changed status codes**: a path that returned 200 now returns 201, or 4xx codes have shifted.
6. **Removed endpoints**: a route that existed has been removed or renamed.

For each finding: BLOCKER (existing client will break), RISKY (likely to break some clients), OK (additive, backward-compatible). For each BLOCKER, propose the deprecation path (add new field/route alongside, deprecate old, remove later).

Return PASS / FAIL at top, one paragraph summary, then a list of findings.
```

Both reviewers share three properties worth copying into anything you write:

- **Tools restricted to read.** No `Edit`. No `Bash` unless the reviewer needs to run a check (and then Bash should be on a tight allowlist).
- **Structured return shape.** PASS/FAIL, severity per finding, one summary line. The orchestrator can consume this without re-parsing.
- **No fixing.** The reviewer reviews. The implementer implements. Mixing the two collapses back to the role-confusion failure mode from [topic 1](../01-single-agent-wall/).

## The loop itself

The orchestration logic for an evaluator–optimizer loop is short. From [topic 4](../04-orchestration-patterns/), restated as a recipe you would put in an orchestrator prompt or a custom skill:

```
For each implementation task:
  1. Dispatch `implementer` with the task.
  2. Dispatch `reviewer` with the task and the diff.
  3. If FAIL:
       a. Read the reviewer's findings.
       b. Re-dispatch `implementer` with: task, previous diff, reviewer's findings.
       c. Re-dispatch `reviewer` with the new diff.
       d. If still FAIL, increment iteration counter.
  4. If iteration counter >= MAX_ROUNDS (default: 2), stop and surface to user.
  5. If PASS, move to next task.
```

`MAX_ROUNDS = 2` is a defensible default. Most implementer-reviewer disagreements either resolve in one round or are real disagreements that need a human. Loops longer than three rounds almost always indicate a misaligned spec, not a fixable code issue.

## Quality gates: where to insert reviewers

A reviewer subagent is a quality gate. Where you insert it determines what kind of mistakes it catches:

| Gate location | Catches | Misses |
|---|---|---|
| After every implementer turn | Per-step regressions, role-confusion bugs | Cross-step issues only visible in combination |
| Before commit | Issues the implementer would have committed | Nothing local, everything global |
| Before push | Issues with the full local branch | Issues with how this branch interacts with main |
| After merge to a draft PR | Issues at PR scope, integration with main | Production-only behaviors |

A common mistake: putting the reviewer only at the very end, after a long sequence of implementer steps. By then the implementer has built up momentum and a long diff. Step-level reviews catch issues earlier and cheaper. End-of-task reviews catch combinatorial issues. Real systems do both.

## The rubber-stamp anti-pattern

The most common failure mode of a custom reviewer is that it always returns PASS. You can predict this from the prompt:

- Description starts with "Reviews code for issues" — too vague to give the reviewer a posture.
- System prompt says "be helpful" or "be thorough" — neither is a posture; both encourage agreement.
- No explicit failure criteria. The reviewer is told what to look for but not what to *fail* on.
- Tools include `Edit` or `Bash` — the reviewer ends up trying to fix things instead of reporting them.

A non-rubber-stamp reviewer prompt has three things:

1. **A specific posture**: "You read code adversarially and assume the worst about untrusted input."
2. **Explicit FAIL criteria**: enumerate what counts as a failure. The list should be short and concrete.
3. **A FAIL-default**: "If you are unsure whether something is safe, return FAIL with the uncertainty as the reason." A reviewer that is biased toward FAIL on uncertainty surfaces real issues; a reviewer biased toward PASS on uncertainty is rubber-stamping.

Test the reviewer by feeding it a known-bad diff and seeing whether it catches it. If it doesn't, tighten the prompt before you trust it on real PRs.

## When the reviewer is genuinely wrong

It will happen. The reviewer flags something that is fine. The implementer is told to fix it and ends up breaking real code. Two failure modes here:

- **The implementer trusts the reviewer too much.** A good implementer prompt should treat the reviewer's findings as input, not as commands. "Address the following review feedback, but if any item is incorrect, push back with reasoning instead of complying."
- **The orchestrator does not surface disagreements to the human.** If the implementer and reviewer disagree across multiple rounds, that is the signal to stop and let a person decide. Burying that disagreement under another iteration is how you ship bad code.

## Iteration budgets are not optional

A reviewer loop with no iteration cap is a way to quietly burn tokens and time. Cap at 2 or 3 rounds. After the cap:

- Surface the implementer's last diff and the reviewer's last findings to the human.
- Do not auto-merge. Do not auto-close. Stop.

This is non-negotiable. The point of the loop is to catch issues before a human sees them; it is not to replace the human's judgement when the agents cannot agree.

## A short test for "do I have a reviewer or a rubber stamp?"

Take three real diffs from your repo: one good, one with a real issue you remember catching, one with a real issue that *shipped*. Run the reviewer on all three.

- The good diff should PASS.
- The known-bad diff should FAIL with an articulable reason.
- The shipped-bad diff (the embarrassing one) should FAIL too. If it does not, your reviewer is missing the class of issue you actually need it for.

This is the same TDD-for-docs methodology from [Lecture 5, topic 8](../../05/08-testing-skills/), applied to reviewer subagents. It catches rubber-stamps before they catch you.

## Resources

- [Claude Code: built-in `/review` command documentation](https://docs.claude.com/en/docs/claude-code) — the off-the-shelf reviewer
- [Anthropic Engineering: Building effective agents](https://www.anthropic.com/research/building-effective-agents) — the evaluator–optimizer pattern
- [Topic 4: orchestration patterns](../04-orchestration-patterns/) — pattern 2 (evaluator–optimizer) in context
- [Lecture 5, topic 8: testing skills](../../05/08-testing-skills/) — the TDD-for-docs method, applied here to reviewers
