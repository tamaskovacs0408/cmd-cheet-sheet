# Agentic AI Software Engineering Foundations 2026

## Course Goal

This course helps software engineers learn how to work effectively with modern coding agents in real projects and real workflows. The emphasis is not just on generating code, but on engineering judgment: planning, context design, tool usage, delegation, review loops, and production governance.

By the end of the course, participants should be able to:

- understand how modern coding agents differ from traditional LLM assistants
- choose the right agentic workflow for a given engineering task
- design reliable agent architectures with planning, execution, and review loops
- structure project context, memory, and rules for better outcomes
- build and compose skills, tools, MCP integrations, and multi-agent systems
- apply safety, governance, and quality controls to autonomous coding workflows

## Lecture Roadmap

| # | Date | Title | Focus |
|---|---|---|---|
| 1 | 2026-04-15 | [From LLMs to Agentic Thinking](01/README.md) | LLM fundamentals, reasoning models, prompt vs. context engineering, model ecosystem, pricing, and cross-model prompting practice |
| 2 | 2026-04-20 | [From Text Completion to Agents](02/README.md) | Tool calling, structured outputs, the agentic loop, planning vs. execution, task decomposition, error handling, and human-in-the-loop development |
| 3 | 2026-04-22 | [Agentic Tooling Landscape (IDE vs CLI)](03/README.md) | Claude Code, Codex, OpenCode, IDE-native vs. CLI-native workflows, context handling, and tool selection strategy |
| 4 | 2026-04-27 | [Context Engineering and Project Memory Design](04/README.md) | Project instructions, layered rules, context density, deterministic behavior from emergent models, and making an existing codebase agent-ready |
| 5 | 2026-04-29 | [Agent Skills: Structured Domain Intelligence](05/README.md) | Skills as behavior modules, activation conditions, progressive disclosure, coding skill types, and designing a custom skill for a real development problem |
| 6 | 2026-05-04 | [MCP: Capability Layer and External Integration](06/README.md) | Model Context Protocol fundamentals, host-client-server architecture, external tools, permissions, sandboxing, and end-to-end workflow integration |
| 7 | 2026-05-06 | [Multi-Agent Architecture and Skill Composition](07/README.md) | Subagents, role-based agents, quality gates, reviewer loops, and multi-role pipelines for complex tasks |
| 8 | 2026-05-11 | [Autonomous Coding Systems and Production Governance](08/README.md) | Headless agents, CI/CD integration, continuous agent loops, sandboxing, security risks, and issue-to-PR automation pipelines |

## Instructors

The course is taught by:

- [Péter Megyesi](https://github.com/Megzo)
- [Márk Sági-Kazár](https://github.com/sagikazarmark)
